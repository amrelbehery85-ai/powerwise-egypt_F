/**
 * ==============================================================================
 * PowerWise Egypt - Centralized API Service (Vanilla JS)
 * إدارة الاتصال بكافة مسارات الـ REST API الخلفية
 * معهد طيبة العالي للتكنولوجيا والمعلومات — مشروع تخرج
 * ==============================================================================
 */

const API = {
  baseUrl: window.location.origin + '/api',

  // ترويسات الطلبات الافتراضية
  getHeaders() {
    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
    const storedUser = localStorage.getItem('powerwise_user');
    if (storedUser) {
      try {
        const u = JSON.parse(storedUser);
        headers['X-User-Id'] = u.id || '2';
        headers['X-User-Role'] = u.role || 'user';
      } catch (e) {}
    } else {
      headers['X-User-Id'] = '2'; // المستخدم التجريبي الافتراضي (طالب معهد طيبة)
      headers['X-User-Role'] = 'user';
    }
    return headers;
  },

  async request(endpoint, options = {}) {
    const url = `${this.baseUrl}${endpoint}`;
    const defaultOptions = {
      headers: this.getHeaders(),
      credentials: 'include'
    };
    const merged = { ...defaultOptions, ...options };
    if (options.headers) {
      merged.headers = { ...defaultOptions.headers, ...options.headers };
    }

    try {
      const response = await fetch(url, merged);
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || `خطأ في الخادم (${response.status})`);
      }
      return data;
    } catch (err) {
      console.error(`API Error [${endpoint}]:`, err);
      throw err;
    }
  },

  // --------------------------------------------------------------------------
  // 1. مسارات المصادقة والمستخدمين (Auth)
  // --------------------------------------------------------------------------
  login(email, password) {
    return this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });
  },

  register(userData) {
    return this.request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData)
    });
  },

  getCurrentUser() {
    return this.request('/auth/me');
  },

  logout() {
    return this.request('/auth/logout', { method: 'POST' });
  },

  // --------------------------------------------------------------------------
  // 2. مسارات التعرفة والشرائح (Tariffs)
  // --------------------------------------------------------------------------
  getTariffs() {
    return this.request('/tariffs');
  },

  calculateBill(kwh) {
    return this.request('/tariffs/calculate', {
      method: 'POST',
      body: JSON.stringify({ kwh: parseFloat(kwh) })
    });
  },

  calculateInverseTariff(budget) {
    return this.request('/tariffs/inverse', {
      method: 'POST',
      body: JSON.stringify({ budget: parseFloat(budget) })
    });
  },

  adminUpdateTariff(tariffId, updateData) {
    return this.request(`/tariffs/admin/update/${tariffId}`, {
      method: 'PUT',
      body: JSON.stringify(updateData)
    });
  },

  // --------------------------------------------------------------------------
  // 3. مسارات الأجهزة المنزلية (Devices)
  // --------------------------------------------------------------------------
  getDeviceTypes() {
    return this.request('/device-types');
  },

  getDevices() {
    return this.request('/devices');
  },

  addDevice(deviceData) {
    return this.request('/devices', {
      method: 'POST',
      body: JSON.stringify(deviceData)
    });
  },

  updateDevice(deviceId, deviceData) {
    return this.request(`/devices/${deviceId}`, {
      method: 'PUT',
      body: JSON.stringify(deviceData)
    });
  },

  toggleDevice(deviceId) {
    return this.request(`/devices/${deviceId}/toggle`, {
      method: 'PATCH'
    });
  },

  deleteDevice(deviceId) {
    return this.request(`/devices/${deviceId}`, {
      method: 'DELETE'
    });
  },

  getLiveSummary() {
    return this.request('/devices/live-summary');
  },

  // --------------------------------------------------------------------------
  // 4. مسارات الذكاء الاصطناعي والتوقع والشحن (Predictions)
  // --------------------------------------------------------------------------
  getForecast(days = 7) {
    return this.request(`/predictions/forecast?days=${days}`);
  },

  recommendRecharge(periodDays = 7, confidence = 0.80) {
    return this.request('/predictions/recommend-recharge', {
      method: 'POST',
      body: JSON.stringify({ period_days: periodDays, confidence })
    });
  },

  getChartsData() {
    return this.request('/predictions/charts');
  },

  getModelMetrics() {
    return this.request('/predictions/metrics');
  },

  retrainModel() {
    return this.request('/predictions/retrain', { method: 'POST' });
  },

  // --------------------------------------------------------------------------
  // 5. مسارات الشات بوت الذكي (Chatbot)
  // --------------------------------------------------------------------------
  sendChatMessage(message) {
    return this.request('/chat', {
      method: 'POST',
      body: JSON.stringify({ message })
    });
  },

  getChatHistory() {
    return this.request('/chat/history');
  },

  getChatSuggestions() {
    return this.request('/chat/faq-suggestions');
  },

  // --------------------------------------------------------------------------
  // 6. مسارات معلومات المعهد والتوثيق (Meta)
  // --------------------------------------------------------------------------
  getMetaInfo() {
    return this.request('/meta/info');
  }
};
