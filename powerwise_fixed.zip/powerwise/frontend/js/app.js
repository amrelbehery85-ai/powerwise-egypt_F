/**
 * ==============================================================================
 * PowerWise Egypt - Single Page Application Core Controller (Vanilla JS)
 * إدارة الشاشات، تبديل اللغة، الوضع الليلي، إدارة الأجهزة، وتوصية الشحن
 * معهد طيبة العالي للتكنولوجيا والمعلومات — مشروع تخرج
 * ==============================================================================
 */

const App = {
  currentScreen: 'dashboard',
  currentLang: localStorage.getItem('powerwise_lang') || 'ar',
  isDarkMode: localStorage.getItem('powerwise_dark') === 'true',
  currentUser: null,
  deviceTypes: [],
  userDevices: [],
  tariffs: [],

  async init() {
    console.log('⚡ PowerWise Egypt initializing...');
    
    // 1. تطبيق اللغة والوضع الليلي المحفوظ
    this.applyTheme(this.isDarkMode);
    this.applyLanguage(this.currentLang);

    // 2. ربط أزرار التنقل والأحداث العامة
    this.bindNavigationEvents();
    this.bindHeaderActions();
    this.bindModalEvents();

    // 3. محاولة استرجاع المستخدم الحالي
    await this.initCurrentUser();

    // 4. تحميل البيانات الأولية
    await this.loadInitialData();

    // 5. تهيئة المساعد الذكي
    if (window.ChatbotUI) {
      ChatbotUI.init();
    }

    // 6. إخفاء شاشة الـ Splash بسلاسة
    setTimeout(() => {
      const splash = document.getElementById('splash-screen');
      if (splash) splash.classList.add('fade-out');
    }, 750);
  },

  // --------------------------------------------------------------------------
  // إدارة الجلسة والمستخدم
  // --------------------------------------------------------------------------
  async initCurrentUser() {
    try {
      const res = await API.getCurrentUser();
      if (res.success && res.data) {
        this.currentUser = res.data.user;
        this.currentMeter = res.data.meter;
        localStorage.setItem('powerwise_user', JSON.stringify(this.currentUser));
      }
    } catch (e) {
      // مستخدم تجريبي افتراضي
      this.currentUser = {
        id: 2,
        full_name: "م. عمرو ضياء الدين (طالب معهد طيبة)",
        email: "student@powerwise.eg",
        role: "user"
      };
      this.currentMeter = {
        meter_number: "MTR-THEBES-2025-01",
        current_balance: 145.75
      };
    }
    this.updateUserUI();
  },

  updateUserUI() {
    const nameEl = document.getElementById('header-user-name');
    const avatarEl = document.getElementById('header-user-avatar');
    if (nameEl && this.currentUser) {
      nameEl.textContent = this.currentUser.full_name;
      if (avatarEl) {
        avatarEl.textContent = this.currentUser.full_name.charAt(0).toUpperCase();
      }
    }
  },

  // --------------------------------------------------------------------------
  // التنقل بين الشاشات (Screen Router)
  // --------------------------------------------------------------------------
  navigate(screenId) {
    if (this.currentScreen === screenId) return;

    // إخفاء كافة الشاشات
    document.querySelectorAll('.screen-section').forEach(el => el.classList.remove('active'));
    document.querySelectorAll('.nav-item button').forEach(el => el.classList.remove('active'));

    // إظهار الشاشة المطلوبة
    const target = document.getElementById(`screen-${screenId}`);
    if (target) {
      target.classList.add('active');
      this.currentScreen = screenId;
    }

    // تنشيط زر التنقل
    const navBtn = document.querySelector(`.nav-item button[data-screen="${screenId}"]`);
    if (navBtn) navBtn.classList.add('active');

    // تحميل بيانات الشاشة الخاصة
    this.onScreenEnter(screenId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },

  onScreenEnter(screenId) {
    switch (screenId) {
      case 'dashboard':
        this.renderDashboard();
        break;
      case 'devices':
        this.renderDevicesScreen();
        break;
      case 'predictions':
        this.renderPredictionsScreen();
        break;
      case 'analytics':
        this.renderAnalyticsScreen();
        break;
      case 'tariffs':
        this.renderTariffsScreen();
        break;
    }
  },

  // --------------------------------------------------------------------------
  // تحميل وعرض الشاشات
  // --------------------------------------------------------------------------
  async loadInitialData() {
    try {
      const [typesRes, devicesRes, summaryRes, tariffsRes] = await Promise.all([
        API.getDeviceTypes(),
        API.getDevices(),
        API.getLiveSummary(),
        API.getTariffs()
      ]);

      if (typesRes.success) this.deviceTypes = typesRes.data;
      if (devicesRes.success) this.userDevices = devicesRes.data;
      if (tariffsRes.success) this.tariffs = tariffsRes.data;
      this.liveSummary = summaryRes.success ? summaryRes.data : null;

      this.renderDashboard();
    } catch (err) {
      console.warn('استخدام البيانات المحلية الافتراضية:', err);
    }
  },

  renderDashboard() {
    // 1. تحديث بطاقة الرصيد
    const balanceVal = this.currentMeter ? this.currentMeter.current_balance : 145.75;
    this.animateCounter('dash-balance-val', 0, balanceVal, 600, 2);

    // 2. تحديث ملخص الأحمال والقدرة اللحظية
    if (this.liveSummary) {
      this.animateCounter('dash-active-watts', 0, this.liveSummary.total_active_watts, 500, 0);
      this.animateCounter('dash-daily-kwh', 0, this.liveSummary.daily_kwh, 500, 2);
      this.animateCounter('dash-monthly-cost', 0, this.liveSummary.monthly_cost_egp, 600, 2);

      const tierBadge = document.getElementById('dash-tier-badge');
      if (tierBadge) {
        tierBadge.textContent = `الشريحة ${this.liveSummary.current_tier}`;
      }
    }

    // 3. حساب الأيام المتبقية التقديرية
    const dailyCost = this.liveSummary && this.liveSummary.daily_cost_egp > 0 ? this.liveSummary.daily_cost_egp : 25.0;
    const daysLeft = Math.max(0, (balanceVal / dailyCost)).toFixed(1);
    const daysEl = document.getElementById('dash-days-left');
    if (daysEl) daysEl.textContent = `${daysLeft} يوم تقريباً`;
  },

  async renderDevicesScreen() {
    try {
      const res = await API.getDevices();
      if (res.success) this.userDevices = res.data;
    } catch (e) {}

    const container = document.getElementById('devices-list-container');
    if (!container) return;

    if (this.userDevices.length === 0) {
      container.innerHTML = `
        <div class="empty-state" style="grid-column: 1/-1; text-align: center; padding: 50px;">
          <svg style="width: 64px; height: 64px; color: var(--text-muted);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M13 10V3L4 14h7v7l9-11h-7z"/>
          </svg>
          <h3 style="margin-top: 14px;">لا توجد أجهزة مسجلة بعد</h3>
          <p style="color: var(--text-muted);">أضف أجهزتك الكهربائية لمراقبة استهلاكها اللحظي والتنبؤ بتكلفتها.</p>
          <button class="btn btn-primary" onclick="App.openAddDeviceModal()" style="margin-top: 10px;">إضافة أول جهاز</button>
        </div>
      `;
      return;
    }

    container.innerHTML = this.userDevices.map(dev => `
      <div class="device-card ${dev.is_active ? 'active-state' : ''}" id="device-card-${dev.id}">
        <div class="device-top">
          <div class="device-info-header">
            <div class="device-icon-box">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
              </svg>
            </div>
            <div>
              <h4 class="device-name">${dev.custom_name}</h4>
              <span class="device-type-label">${dev.type_info ? dev.type_info.name_ar : 'جهاز منزلي'}</span>
            </div>
          </div>
          <label class="switch-control">
            <input type="checkbox" ${dev.is_active ? 'checked' : ''} onchange="App.handleToggleDevice(${dev.id})">
            <span class="slider-knob"></span>
          </label>
        </div>

        <div class="device-metrics">
          <div class="device-metric-item">
            <span>القدرة الكلية</span>
            <b>${dev.total_watts} وات</b>
          </div>
          <div class="device-metric-item">
            <span>التشغيل اليومي</span>
            <b>${dev.daily_hours} س / يوم</b>
          </div>
          <div class="device-metric-item">
            <span>الاستهلاك اليومي</span>
            <b>${dev.daily_kwh} ك.و.س</b>
          </div>
          <div class="device-metric-item">
            <span>الاستهلاك الشهري</span>
            <b>${dev.monthly_kwh} ك.و.س</b>
          </div>
        </div>

        <div class="device-actions">
          <button class="btn btn-outline" style="padding: 6px 12px; font-size: 0.8rem;" onclick="App.openEditDeviceModal(${dev.id})">تعديل</button>
          <button class="btn btn-danger" style="padding: 6px 12px; font-size: 0.8rem;" onclick="App.handleDeleteDevice(${dev.id})">حذف</button>
        </div>
      </div>
    `).join('');
  },

  async handleToggleDevice(deviceId) {
    try {
      const res = await API.toggleDevice(deviceId);
      if (res.success) {
        this.showToast(res.message, 'success');
        const card = document.getElementById(`device-card-${deviceId}`);
        if (card) {
          card.classList.toggle('active-state', res.data.is_active);
        }
        // تحديث ملخص الأحمال والعداد في الخلفية
        const sumRes = await API.getLiveSummary();
        if (sumRes.success) {
          this.liveSummary = sumRes.data;
          this.renderDashboard();
        }
      }
    } catch (err) {
      this.showToast('تعذر تغيير حالة الجهاز: ' + err.message, 'error');
    }
  },

  async handleDeleteDevice(deviceId) {
    if (!confirm('هل أنت متأكد من رغبتك في حذف هذا الجهاز؟')) return;
    try {
      const res = await API.deleteDevice(deviceId);
      if (res.success) {
        this.showToast(res.message, 'success');
        this.userDevices = this.userDevices.filter(d => d.id !== deviceId);
        this.renderDevicesScreen();
        const sumRes = await API.getLiveSummary();
        if (sumRes.success) {
          this.liveSummary = sumRes.data;
          this.renderDashboard();
        }
      }
    } catch (err) {
      this.showToast('فشل حذف الجهاز.', 'error');
    }
  },

  async renderPredictionsScreen() {
    const daysSelect = document.getElementById('forecast-period-select');
    const days = daysSelect ? parseInt(daysSelect.value) : 7;

    try {
      const [forecastRes, recRes] = await Promise.all([
        API.getForecast(days),
        API.recommendRecharge(days, 0.80)
      ]);

      if (forecastRes.success && forecastRes.data) {
        const f = forecastRes.data;
        document.getElementById('pred-total-kwh').textContent = `${f.total_predicted_kwh} ك.و.س`;
        document.getElementById('pred-range-kwh').textContent = `${f.lower_bound_kwh} إلى ${f.upper_bound_kwh} ك.و.س`;
        document.getElementById('pred-total-cost').textContent = `${f.total_cost_egp} ج.م`;

        // رسم المخطط الخطي مع نطاق الثقة
        if (window.PowerCharts) {
          const chartData = {
            labels: f.daily_forecasts.map(d => d.day_name_ar),
            predicted: f.daily_forecasts.map(d => d.predicted_kwh),
            lower_bound: f.daily_forecasts.map(d => d.lower_bound_kwh),
            upper_bound: f.daily_forecasts.map(d => d.upper_bound_kwh)
          };
          PowerCharts.drawLineChart('prediction-line-canvas', chartData, this.isDarkMode);
        }
      }

      if (recRes.success && recRes.data) {
        const r = recRes.data;
        document.getElementById('rec-recharge-amount').textContent = `${r.recommended_recharge_egp.toFixed(2)} ج.م`;
        document.getElementById('rec-min-amount').textContent = `${r.min_recharge_egp.toFixed(2)} ج.م`;
        document.getElementById('rec-max-amount').textContent = `${r.max_recharge_egp.toFixed(2)} ج.م`;
        document.getElementById('rec-status-msg').textContent = r.status_message_ar;
        document.getElementById('rec-days-remaining').textContent = `${r.days_remaining_estimate} يوم`;
      }
    } catch (err) {
      console.error('خطأ في تحميل التوقعات:', err);
    }
  },

  async renderAnalyticsScreen() {
    try {
      const res = await API.getChartsData();
      if (res.success && res.data && window.PowerCharts) {
        PowerCharts.drawBarChart('analytics-bar-canvas', res.data.bar_chart, this.isDarkMode);
        PowerCharts.drawDonutChart('analytics-donut-canvas', res.data.donut_chart, this.isDarkMode);
      }
    } catch (err) {
      console.error('خطأ في تحميل التحليلات:', err);
    }
  },

  async renderTariffsScreen() {
    try {
      const res = await API.getTariffs();
      if (res.success) this.tariffs = res.data;
    } catch (e) {}

    const tableBody = document.getElementById('tariffs-table-body');
    if (!tableBody) return;

    tableBody.innerHTML = this.tariffs.map(t => `
      <tr>
        <td><b>الشريحة ${t.tier_number}</b></td>
        <td>${t.tier_name_ar}</td>
        <td>${t.min_kwh} - ${t.max_kwh >= 999999 ? 'فأكثر' : t.max_kwh} ك.و.س</td>
        <td><span class="tag-badge blue">${(t.price_per_kwh * 100).toFixed(0)} قرش (${t.price_per_kwh.toFixed(2)} ج.م)</span></td>
        <td>${t.service_fee.toFixed(2)} ج.م</td>
        <td>
          <button class="btn btn-outline" style="padding: 4px 10px; font-size: 0.78rem;" onclick="App.openEditTariffModal(${t.id}, ${t.price_per_kwh}, ${t.service_fee}, '${t.tier_name_ar}')">تعديل (Admin)</button>
        </td>
      </tr>
    `).join('');
  },

  // --------------------------------------------------------------------------
  // إدارة النوافذ المنبثقة (Modals)
  // --------------------------------------------------------------------------
  openAddDeviceModal() {
    const modal = document.getElementById('add-device-modal');
    if (!modal) return;

    document.getElementById('modal-title-text').textContent = 'إضافة جهاز كهربائي جديد';
    document.getElementById('device-form-id').value = '';
    document.getElementById('modal-device-name').value = '';
    document.getElementById('modal-device-count').value = 1;
    document.getElementById('modal-device-hours').value = 4.0;
    document.getElementById('modal-device-watts').value = 100;
    document.getElementById('modal-watts-slider').value = 100;
    document.getElementById('modal-watts-badge').textContent = '100 وات';

    modal.classList.add('open');
  },

  openEditDeviceModal(deviceId) {
    const dev = this.userDevices.find(d => d.id === deviceId);
    if (!dev) return;

    this.openAddDeviceModal();
    document.getElementById('modal-title-text').textContent = 'تعديل بيانات الجهاز';
    document.getElementById('device-form-id').value = dev.id;
    document.getElementById('modal-device-name').value = dev.custom_name;
    document.getElementById('modal-device-count').value = dev.count;
    document.getElementById('modal-device-hours').value = dev.daily_hours;
    document.getElementById('modal-device-watts').value = dev.rated_watts;
    document.getElementById('modal-watts-slider').value = dev.rated_watts;
    document.getElementById('modal-watts-badge').textContent = `${dev.rated_watts} وات`;
  },

  closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.classList.remove('open');
  },

  bindModalEvents() {
    const wattsInput = document.getElementById('modal-device-watts');
    const wattsSlider = document.getElementById('modal-watts-slider');
    const wattsBadge = document.getElementById('modal-watts-badge');

    if (wattsSlider && wattsInput) {
      wattsSlider.addEventListener('input', () => {
        wattsInput.value = wattsSlider.value;
        wattsBadge.textContent = `${wattsSlider.value} وات`;
      });

      wattsInput.addEventListener('input', () => {
        wattsSlider.value = wattsInput.value;
        wattsBadge.textContent = `${wattsInput.value} وات`;
      });
    }

    const deviceForm = document.getElementById('device-form');
    if (deviceForm) {
      deviceForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const id = document.getElementById('device-form-id').value;
        const payload = {
          custom_name: document.getElementById('modal-device-name').value.trim(),
          rated_watts: parseInt(document.getElementById('modal-device-watts').value),
          count: parseInt(document.getElementById('modal-device-count').value),
          daily_hours: parseFloat(document.getElementById('modal-device-hours').value),
          is_active: true
        };

        try {
          if (id) {
            await API.updateDevice(id, payload);
            this.showToast('تم تعديل الجهاز بنجاح!', 'success');
          } else {
            await API.addDevice(payload);
            this.showToast('تمت إضافة الجهاز بنجاح!', 'success');
          }
          this.closeModal('add-device-modal');
          await this.loadInitialData();
          this.renderDevicesScreen();
        } catch (err) {
          this.showToast(err.message, 'error');
        }
      });
    }

    // مودال تعديل التعرفة للأدمن
    const tariffForm = document.getElementById('admin-tariff-form');
    if (tariffForm) {
      tariffForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const tId = document.getElementById('admin-tariff-id').value;
        const payload = {
          price_per_kwh: parseFloat(document.getElementById('admin-tariff-price').value),
          service_fee: parseFloat(document.getElementById('admin-tariff-fee').value)
        };
        try {
          const res = await API.adminUpdateTariff(tId, payload);
          if (res.success) {
            this.showToast('تم تحديث التعرفة بنجاح!', 'success');
            this.closeModal('admin-tariff-modal');
            this.renderTariffsScreen();
          }
        } catch (err) {
          this.showToast('فشل تحديث الشريحة: ' + err.message, 'error');
        }
      });
    }
  },

  openEditTariffModal(tariffId, price, fee, tierName) {
    document.getElementById('admin-tariff-id').value = tariffId;
    document.getElementById('admin-tariff-title').textContent = `تعديل أسعار ${tierName}`;
    document.getElementById('admin-tariff-price').value = price;
    document.getElementById('admin-tariff-fee').value = fee;
    document.getElementById('admin-tariff-modal').classList.add('open');
  },

  // --------------------------------------------------------------------------
  // التحكم بالهيدر والتنقل والسمات
  // --------------------------------------------------------------------------
  bindNavigationEvents() {
    document.querySelectorAll('.nav-item button').forEach(btn => {
      btn.addEventListener('click', () => {
        const scr = btn.dataset.screen;
        if (scr) this.navigate(scr);
      });
    });
  },

  bindHeaderActions() {
    const themeBtn = document.getElementById('theme-toggle-btn');
    if (themeBtn) {
      themeBtn.addEventListener('click', () => {
        this.isDarkMode = !this.isDarkMode;
        this.applyTheme(this.isDarkMode);
      });
    }

    const langBtn = document.getElementById('lang-toggle-btn');
    if (langBtn) {
      langBtn.addEventListener('click', () => {
        const newLang = this.currentLang === 'ar' ? 'en' : 'ar';
        this.applyLanguage(newLang);
      });
    }
  },

  applyTheme(isDark) {
    if (isDark) {
      document.body.classList.add('dark-mode');
    } else {
      document.body.classList.remove('dark-mode');
    }
    localStorage.setItem('powerwise_dark', isDark);
    if (this.currentScreen === 'analytics' || this.currentScreen === 'predictions') {
      this.onScreenEnter(this.currentScreen);
    }
  },

  applyLanguage(lang) {
    this.currentLang = lang;
    localStorage.setItem('powerwise_lang', lang);
    if (lang === 'en') {
      document.body.classList.add('lang-en');
      document.documentElement.lang = 'en';
      document.documentElement.dir = 'ltr';
      document.getElementById('lang-toggle-text').textContent = 'عربي';
    } else {
      document.body.classList.remove('lang-en');
      document.documentElement.lang = 'ar';
      document.documentElement.dir = 'rtl';
      document.getElementById('lang-toggle-text').textContent = 'English';
    }
  },

  // --------------------------------------------------------------------------
  // مساعدة الحركات والتنبيهات
  // --------------------------------------------------------------------------
  animateCounter(elemId, start, end, duration = 600, decimals = 2) {
    const el = document.getElementById(elemId);
    if (!el) return;

    const range = end - start;
    const minTimer = 20;
    let stepTime = Math.abs(Math.floor(duration / 30));
    stepTime = Math.max(stepTime, minTimer);

    const startTime = performance.now();

    function update(now) {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // منحنى حركة ناعم (Ease-out cubic)
      const ease = 1 - Math.pow(1 - progress, 3);
      const current = start + range * ease;
      el.textContent = current.toFixed(decimals);

      if (progress < 1) {
        requestAnimationFrame(update);
      } else {
        el.textContent = end.toFixed(decimals);
      }
    }
    requestAnimationFrame(update);
  },

  showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }
};

document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
