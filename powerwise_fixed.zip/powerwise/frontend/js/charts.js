/**
 * ==============================================================================
 * PowerWise Egypt - Pure Vanilla HTML5 Canvas Charts Engine
 * محرك رسوم بيانية خفيف ومتحرك ومستقل 100% بدون أي مكتبات خارجية
 * معهد طيبة العالي للتكنولوجيا والمعلومات — مشروع تخرج
 * ==============================================================================
 */

const PowerCharts = {
  // ألوان المنظومة المعتمدة
  colors: {
    primary: '#0066FF',
    primaryLight: 'rgba(0, 102, 255, 0.18)',
    secondary: '#10B981',
    secondaryLight: 'rgba(16, 185, 129, 0.2)',
    accent: '#F59E0B',
    accentLight: 'rgba(245, 158, 11, 0.2)',
    danger: '#DC2626',
    palette: ['#0066FF', '#10B981', '#F59E0B', '#0284C7', '#84CC16', '#EA580C', '#6366F1', '#14B8A6']
  },

  /**
   * رسم مخطط خطي مع نطاق الثقة (Line Chart with Confidence Interval Band)
   */
  drawLineChart(canvasId, data, isDark = false) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const width = canvas.width = canvas.parentElement.clientWidth || 600;
    const height = canvas.height = canvas.parentElement.clientHeight || 300;

    const labels = data.labels || [];
    const predicted = data.predicted || [];
    const lower = data.lower_bound || [];
    const upper = data.upper_bound || [];

    if (predicted.length === 0) return;

    ctx.clearRect(0, 0, width, height);

    const padding = { top: 30, right: 30, bottom: 40, left: 50 };
    const chartW = width - padding.left - padding.right;
    const chartH = height - padding.top - padding.bottom;

    const maxVal = Math.max(...upper, ...predicted) * 1.15 || 20;
    const minVal = Math.max(0, Math.min(...lower, ...predicted) * 0.85);

    const getX = (i) => padding.left + (i * chartW) / (labels.length - 1 || 1);
    const getY = (val) => padding.top + chartH - ((val - minVal) / (maxVal - minVal || 1)) * chartH;

    // 1. رسم خطوط الشبكة الأفقية
    ctx.strokeStyle = isDark ? 'rgba(255, 255, 255, 0.08)' : 'rgba(0, 0, 0, 0.06)';
    ctx.lineWidth = 1;
    ctx.fillStyle = isDark ? '#94A3B8' : '#64748B';
    ctx.font = '11px Cairo, sans-serif';
    ctx.textAlign = 'right';

    const gridLines = 4;
    for (let i = 0; i <= gridLines; i++) {
      const v = minVal + ((maxVal - minVal) / gridLines) * i;
      const y = padding.top + chartH - (i * chartH) / gridLines;
      ctx.beginPath();
      ctx.moveTo(padding.left, y);
      ctx.lineTo(width - padding.right, y);
      ctx.stroke();
      ctx.fillText(v.toFixed(1) + ' ك.و.س', padding.left - 8, y + 4);
    }

    // 2. رسم نطاق الثقة (Confidence Interval Band: 10% to 90%)
    ctx.beginPath();
    ctx.moveTo(getX(0), getY(upper[0]));
    for (let i = 1; i < labels.length; i++) {
      ctx.lineTo(getX(i), getY(upper[i]));
    }
    for (let i = labels.length - 1; i >= 0; i--) {
      ctx.lineTo(getX(i), getY(lower[i]));
    }
    ctx.closePath();
    ctx.fillStyle = this.colors.primaryLight;
    ctx.fill();

    // 3. رسم خط التوقع الأساسي (Predicted Line)
    ctx.beginPath();
    ctx.strokeStyle = this.colors.primary;
    ctx.lineWidth = 3;
    for (let i = 0; i < labels.length; i++) {
      const x = getX(i);
      const y = getY(predicted[i]);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // 4. رسم نقاط البيانات والتسميات
    ctx.textAlign = 'center';
    for (let i = 0; i < labels.length; i++) {
      const x = getX(i);
      const y = getY(predicted[i]);

      // دائرة النقطة
      ctx.beginPath();
      ctx.arc(x, y, 5, 0, Math.PI * 2);
      ctx.fillStyle = '#FFFFFF';
      ctx.fill();
      ctx.strokeStyle = this.colors.primary;
      ctx.lineWidth = 2.5;
      ctx.stroke();

      // تسمية اليوم بالأسفل
      ctx.fillStyle = isDark ? '#94A3B8' : '#64748B';
      ctx.fillText(labels[i], x, height - 12);
    }
  },

  /**
   * رسم مخطط أعمدة أفقي أو رأسي لمقارنة استهلاك الأجهزة (Bar Chart)
   */
  drawBarChart(canvasId, data, isDark = false) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const width = canvas.width = canvas.parentElement.clientWidth || 600;
    const height = canvas.height = canvas.parentElement.clientHeight || 300;

    const labels = data.labels || [];
    const values = data.values || [];
    if (labels.length === 0) return;

    ctx.clearRect(0, 0, width, height);

    const padding = { top: 20, right: 30, bottom: 45, left: 55 };
    const chartW = width - padding.left - padding.right;
    const chartH = height - padding.top - padding.bottom;

    const maxVal = Math.max(...values) * 1.2 || 10;
    const barWidth = Math.min(45, (chartW / labels.length) * 0.6);
    const step = chartW / labels.length;

    // خطوط الشبكة
    ctx.strokeStyle = isDark ? 'rgba(255, 255, 255, 0.08)' : 'rgba(0, 0, 0, 0.06)';
    ctx.lineWidth = 1;
    ctx.fillStyle = isDark ? '#94A3B8' : '#64748B';
    ctx.font = '11px Cairo, sans-serif';
    ctx.textAlign = 'right';

    for (let i = 0; i <= 4; i++) {
      const v = (maxVal / 4) * i;
      const y = padding.top + chartH - (i * chartH) / 4;
      ctx.beginPath();
      ctx.moveTo(padding.left, y);
      ctx.lineTo(width - padding.right, y);
      ctx.stroke();
      ctx.fillText(v.toFixed(1), padding.left - 8, y + 4);
    }

    // رسم الأعمدة
    ctx.textAlign = 'center';
    for (let i = 0; i < labels.length; i++) {
      const x = padding.left + (i * step) + (step - barWidth) / 2;
      const h = (values[i] / maxVal) * chartH;
      const y = padding.top + chartH - h;

      // تدرج لوني جميل للعمود
      const grad = ctx.createLinearGradient(0, y, 0, y + h);
      grad.addColorStop(0, this.colors.palette[i % this.colors.palette.length]);
      grad.addColorStop(1, 'rgba(0, 102, 255, 0.5)');

      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.roundRect ? ctx.roundRect(x, y, barWidth, h, [6, 6, 0, 0]) : ctx.rect(x, y, barWidth, h);
      ctx.fill();

      // قيمة العمود أعلى العمود
      ctx.fillStyle = isDark ? '#F1F5F9' : '#0F172A';
      ctx.font = 'bold 11px Cairo, sans-serif';
      ctx.fillText(values[i] + ' ك.و.س', x + barWidth / 2, y - 6);

      // اسم الجهاز بالأسفل
      ctx.fillStyle = isDark ? '#94A3B8' : '#64748B';
      ctx.font = '11px Cairo, sans-serif';
      const labelShort = labels[i].length > 10 ? labels[i].substring(0, 9) + '..' : labels[i];
      ctx.fillText(labelShort, x + barWidth / 2, height - 14);
    }
  },

  /**
   * رسم مخطط دائري مجوف (Donut Chart) لتوزيع الفئات
   */
  drawDonutChart(canvasId, data, isDark = false) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const width = canvas.width = canvas.parentElement.clientWidth || 300;
    const height = canvas.height = canvas.parentElement.clientHeight || 300;

    const labels = data.labels || [];
    const values = data.values || [];
    const total = values.reduce((a, b) => a + b, 0);

    if (total === 0) return;

    ctx.clearRect(0, 0, width, height);

    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(centerX, centerY) * 0.75;
    const innerRadius = radius * 0.55;

    let startAngle = -Math.PI / 2;

    for (let i = 0; i < values.length; i++) {
      const sliceAngle = (values[i] / total) * Math.PI * 2;
      const color = this.colors.palette[i % this.colors.palette.length];

      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, startAngle, startAngle + sliceAngle);
      ctx.arc(centerX, centerY, innerRadius, startAngle + sliceAngle, startAngle, true);
      ctx.closePath();
      ctx.fillStyle = color;
      ctx.fill();

      startAngle += sliceAngle;
    }

    // نص المركز
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = isDark ? '#F1F5F9' : '#0F172A';
    ctx.font = 'bold 16px Cairo, sans-serif';
    ctx.fillText(total.toFixed(1), centerX, centerY - 8);
    ctx.font = '11px Cairo, sans-serif';
    ctx.fillStyle = isDark ? '#94A3B8' : '#64748B';
    ctx.fillText('ك.و.س / يوم', centerX, centerY + 12);
  }
};
