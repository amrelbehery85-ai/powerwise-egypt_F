/**
 * ==============================================================================
 * PowerWise Egypt - Smart Chatbot UI Controller (Vanilla JS)
 * إدارة واجهة المساعد الذكي، إرسال الأسئلة، عرض الإجابات والمقترحات
 * معهد طيبة العالي للتكنولوجيا والمعلومات — مشروع تخرج
 * ==============================================================================
 */

const ChatbotUI = {
  isOpen: false,

  init() {
    this.fabBtn = document.getElementById('chatbot-fab-btn');
    this.panel = document.getElementById('chatbot-panel');
    this.closeBtn = document.getElementById('chatbot-close-btn');
    this.messagesContainer = document.getElementById('chat-messages');
    this.inputField = document.getElementById('chat-input-text');
    this.sendBtn = document.getElementById('chat-send-btn');
    this.suggestionsContainer = document.getElementById('chat-suggestions');

    if (!this.fabBtn || !this.panel) return;

    this.bindEvents();
    this.loadInitialSuggestions();
  },

  bindEvents() {
    this.fabBtn.addEventListener('click', () => this.togglePanel());
    this.closeBtn.addEventListener('click', () => this.togglePanel(false));

    this.sendBtn.addEventListener('click', () => this.handleSendMessage());
    this.inputField.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        this.handleSendMessage();
      }
    });
  },

  togglePanel(forceState) {
    this.isOpen = forceState !== undefined ? forceState : !this.isOpen;
    if (this.isOpen) {
      this.panel.classList.add('open');
      this.inputField.focus();
    } else {
      this.panel.classList.remove('open');
    }
  },

  async loadInitialSuggestions() {
    try {
      const res = await API.getChatSuggestions();
      if (res.success && res.suggestions) {
        this.renderSuggestions(res.suggestions);
      }
    } catch (e) {
      // مقترحات افتراضية
      this.renderSuggestions([
        "ما هي شرائح الكهرباء في مصر؟",
        "كم رصيدي المتبقي في العداد؟",
        "ما هو أكثر جهاز يستهلك كهرباء في بيتي؟",
        "كام أشحن في العداد؟"
      ]);
    }
  },

  renderSuggestions(suggestions) {
    if (!this.suggestionsContainer) return;
    this.suggestionsContainer.innerHTML = '';
    suggestions.forEach(q => {
      const pill = document.createElement('button');
      pill.className = 'suggestion-pill';
      pill.textContent = q;
      pill.addEventListener('click', () => {
        this.inputField.value = q;
        this.handleSendMessage();
      });
      this.suggestionsContainer.appendChild(pill);
    });
  },

  async handleSendMessage() {
    const text = this.inputField.value.trim();
    if (!text) return;

    // 1. إضافة رسالة المستخدم في الشات
    this.appendMessage(text, 'user');
    this.inputField.value = '';

    // 2. مؤشر الكتابة التفاعلي (Typing Indicator)
    const typingId = this.showTypingIndicator();

    try {
      const res = await API.sendChatMessage(text);
      this.removeTypingIndicator(typingId);

      if (res.success && res.data) {
        this.appendMessage(res.data.reply, 'bot');
        if (res.data.suggestions && res.data.suggestions.length > 0) {
          this.renderSuggestions(res.data.suggestions);
        }
      } else {
        this.appendMessage('عذراً، حدث خطأ أثناء معالجة السؤال.', 'bot');
      }
    } catch (err) {
      this.removeTypingIndicator(typingId);
      this.appendMessage('تعذر الاتصال بالمساعد الذكي حالياً. يرجى التأكد من تشغيل السيرفر.', 'bot');
    }
  },

  appendMessage(text, sender = 'bot') {
    const msgDiv = document.createElement('div');
    msgDiv.className = `message ${sender}`;

    // تحويل الـ Markdown البسيط (Bold)
    const formatted = text
      .replace(/\*\*(.*?)\*\*/g, '<b>$1</b>')
      .replace(/\n/g, '<br>');

    msgDiv.innerHTML = formatted;
    this.messagesContainer.appendChild(msgDiv);
    this.scrollToBottom();
  },

  showTypingIndicator() {
    const id = 'typing-' + Date.now();
    const ind = document.createElement('div');
    ind.id = id;
    ind.className = 'message bot typing-indicator';
    ind.innerHTML = '<span>جاري التفكير والتحليل... ⚡</span>';
    this.messagesContainer.appendChild(ind);
    this.scrollToBottom();
    return id;
  },

  removeTypingIndicator(id) {
    const el = document.getElementById(id);
    if (el) el.remove();
  },

  scrollToBottom() {
    this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
  }
};
