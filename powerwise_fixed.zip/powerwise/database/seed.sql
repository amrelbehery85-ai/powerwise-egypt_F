-- ==============================================================================
-- PowerWise Egypt - Database Seed Data (MySQL)
-- مراقب ذكي لاستهلاك الكهرباء للعدادات مسبقة الدفع في مصر
-- مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
-- الترميز: UTF-8 Unicode (utf8mb4)
-- ==============================================================================

USE `powerwise_db`;

-- إيقاف فحص المفاتيح لتفريغ الجداول وإعادة إدخال البيانات النظيفة
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE `chat_logs`;
TRUNCATE TABLE `notifications`;
TRUNCATE TABLE `predictions`;
TRUNCATE TABLE `usage_logs`;
TRUNCATE TABLE `recharges`;
TRUNCATE TABLE `devices`;
TRUNCATE TABLE `device_types`;
TRUNCATE TABLE `tariffs`;
TRUNCATE TABLE `meters`;
TRUNCATE TABLE `users`;
TRUNCATE TABLE `faq`;
SET FOREIGN_KEY_CHECKS = 1;

-- ------------------------------------------------------------------------------
-- 1. جدول شرائح التعرفة المصرية الرسمية (tariffs)
-- ملاحظة تقديرية: مبنية على آخر تحديث معلن لشرائح الكهرباء السكنية من جهاز
-- تنظيم مرفق الكهرباء وحماية المستهلك (EgyptERA) لعام 2024/2025.
-- ------------------------------------------------------------------------------
INSERT INTO `tariffs` (`id`, `tier_number`, `tier_name_ar`, `tier_name_en`, `min_kwh`, `max_kwh`, `price_per_kwh`, `service_fee`, `bracket_group`, `effective_date`, `source`, `is_active`) VALUES
(1, 1, 'الشريحة الأولى (من 0 إلى 50 ك.و.س)', 'Tier 1 (0 to 50 kWh)', 0.00, 50.00, 0.6800, 1.00, 1, '2024-08-01', 'EgyptERA - قرار أسعار الكهرباء السكنية 2024/2025 (تقديري)', 1),
(2, 2, 'الشريحة الثانية (من 51 إلى 100 ك.و.س)', 'Tier 2 (51 to 100 kWh)', 51.00, 100.00, 0.7800, 2.00, 1, '2024-08-01', 'EgyptERA - قرار أسعار الكهرباء السكنية 2024/2025 (تقديري)', 1),
(3, 3, 'الشريحة الثالثة (من 0 إلى 200 ك.و.س بديل الأولى والثانية)', 'Tier 3 (0 to 200 kWh)', 0.00, 200.00, 0.9500, 6.00, 2, '2024-08-01', 'EgyptERA - قرار أسعار الكهرباء السكنية 2024/2025 (تقديري)', 1),
(4, 4, 'الشريحة الرابعة (من 201 إلى 350 ك.و.س)', 'Tier 4 (201 to 350 kWh)', 201.00, 350.00, 1.5500, 11.00, 2, '2024-08-01', 'EgyptERA - قرار أسعار الكهرباء السكنية 2024/2025 (تقديري)', 1),
(5, 5, 'الشريحة الخامسة (من 351 إلى 650 ك.و.س)', 'Tier 5 (351 to 650 kWh)', 351.00, 650.00, 1.9500, 15.00, 2, '2024-08-01', 'EgyptERA - قرار أسعار الكهرباء السكنية 2024/2025 (تقديري)', 1),
(6, 6, 'الشريحة السادسة (من 0 إلى 1000 ك.و.س دون دعم)', 'Tier 6 (0 to 1000 kWh)', 0.00, 1000.00, 2.1000, 25.00, 3, '2024-08-01', 'EgyptERA - قرار أسعار الكهرباء السكنية 2024/2025 (تقديري)', 1),
(7, 7, 'الشريحة السابعة (أكثر من 1000 ك.و.س)', 'Tier 7 (More than 1000 kWh)', 1001.00, 999999.00, 2.2300, 40.00, 4, '2024-08-01', 'EgyptERA - قرار أسعار الكهرباء السكنية 2024/2025 (تقديري)', 1);

-- ------------------------------------------------------------------------------
-- 2. جدول أنواع الأجهزة الكهربائية المنزلية القياسية (device_types)
-- القيم الفنية (min/max/typical watts) مأخوذة من الكتيبات الفنية للأجهزة المنزلية
-- ------------------------------------------------------------------------------
INSERT INTO `device_types` (`id`, `name_ar`, `name_en`, `min_watts`, `max_watts`, `typical_watts`, `category`, `icon_svg_name`, `is_custom`) VALUES
(1, 'لمبة LED موفرة', 'LED Bulb', 5, 20, 9, 'lighting', 'lightbulb', 0),
(2, 'لمبة عادية متوهجة', 'Incandescent Bulb', 40, 100, 60, 'lighting', 'bulb-vintage', 0),
(3, 'شاحن هاتف محمول', 'Phone Charger', 5, 25, 15, 'electronics', 'smartphone', 0),
(4, 'شاحن لابتوب', 'Laptop Charger', 45, 120, 65, 'electronics', 'laptop', 0),
(5, 'مروحة سقف / مكتب', 'Fan', 40, 100, 60, 'cooling', 'fan', 0),
(6, 'شاشة تلفزيون (LED/LCD)', 'Television', 50, 250, 100, 'entertainment', 'tv', 0),
(7, 'ثلاجة منزلية (نوفروست)', 'Refrigerator', 100, 400, 200, 'kitchen', 'fridge', 0),
(8, 'غسالة ملابس أوتوماتيك', 'Washing Machine', 300, 2500, 800, 'laundry', 'washer', 0),
(9, 'تكييف سبليت (1.5 حصان)', 'Air Conditioner (1.5 HP)', 1000, 2200, 1400, 'cooling', 'ac', 0),
(10, 'سخان مياه كهربائي', 'Electric Water Heater', 1200, 3000, 1800, 'heating', 'heater', 0),
(11, 'مكواة ملابس بخار', 'Steam Iron', 1000, 2400, 1500, 'laundry', 'iron', 0),
(12, 'ميكروويف', 'Microwave', 700, 1500, 1000, 'kitchen', 'microwave', 0),
(13, 'غلاية مياه (كاتيل)', 'Electric Kettle', 1200, 2400, 1800, 'kitchen', 'kettle', 0),
(14, 'راوتر واي فاي منزلي', 'WiFi Router', 6, 15, 10, 'network', 'wifi', 0),
(15, 'كمبيوتر مكتبي (Desktop PC)', 'Desktop PC', 150, 600, 300, 'electronics', 'pc', 0),
(16, 'جهاز لابتوب للعمل', 'Laptop Computer', 40, 100, 60, 'electronics', 'laptop', 0),
(17, 'طلمبة مياه (موتور مياه)', 'Water Pump', 500, 1500, 750, 'utility', 'pump', 0),
(18, 'فرن كهربائي منزلي', 'Electric Oven', 1500, 3500, 2000, 'kitchen', 'oven', 0),
(19, 'بوتاجاز مسطح كهربائي', 'Electric Cooktop', 1200, 4000, 2200, 'kitchen', 'cooktop', 0),
(20, 'جهاز آخر (مخصص)', 'Other Device (Custom)', 1, 5000, 100, 'other', 'custom-plug', 1);

-- ------------------------------------------------------------------------------
-- 3. المستخدمون المبدئيون (users)
-- كلمات المرور:
-- Admin: Admin@123456
-- Student: Student@123456
-- ------------------------------------------------------------------------------
INSERT INTO `users` (`id`, `full_name`, `email`, `password_hash`, `role`) VALUES
(1, 'مسؤول النظام (Admin PowerWise)', 'admin@powerwise.eg', 'scrypt:32768:8:1$MDwakH00l6yFPGdg$ac422294828d96a12739a58a522b6e83c580d22b8078e8ac7c2aef0e657097e2abfc36dad7f140266ac23839c1de2a3b0cb0f0b126222d5905e3b4d56b7744fa', 'admin'),
(2, 'م. عمرو ضياء الدين حسن (طالب معهد طيبة)', 'student@powerwise.eg', 'scrypt:32768:8:1$zGR56Bb2QEtFhQQy$b6557a469ef822ea139ac44281ebc5434bc83173a821e0227a516a301afe52a8df7668e42c1bde99b3a1814c3cd801b8d748d38c5d64518705e8e7696331e73f', 'user');

-- ------------------------------------------------------------------------------
-- 4. عداد المستخدم (meters)
-- ------------------------------------------------------------------------------
INSERT INTO `meters` (`id`, `user_id`, `meter_number`, `current_balance`, `tariff_category`) VALUES
(1, 2, 'MTR-THEBES-2025-01', 145.75, 'residential');

-- ------------------------------------------------------------------------------
-- 5. الأجهزة المنزلية التجريبية للمستخدم (devices)
-- ------------------------------------------------------------------------------
INSERT INTO `devices` (`id`, `user_id`, `device_type_id`, `custom_name`, `rated_watts`, `count`, `daily_hours`, `is_active`) VALUES
(1, 2, 7, 'ثلاجة المطبخ (نوفروست 16 قدم)', 200, 1, 24.00, 1),
(2, 2, 9, 'تكييف غرفة المعيشة 1.5 حصان', 1400, 1, 6.00, 1),
(3, 2, 1, 'إضاءة الصالة (لمبات ليد موفرة)', 9, 5, 7.00, 1),
(4, 2, 14, 'راوتر الإنترنت المنزلي', 10, 1, 24.00, 1),
(5, 2, 6, 'تلفزيون الريسبشن 50 بوصة', 100, 1, 5.00, 1),
(6, 2, 8, 'غسالة الملابس الأوتوماتيك', 800, 1, 1.50, 0),
(7, 2, 13, 'غلاية المياه (الكاتيل)', 1800, 1, 0.40, 0);

-- ------------------------------------------------------------------------------
-- 6. سجلات شحن سابقة للعداد (recharges)
-- ------------------------------------------------------------------------------
INSERT INTO `recharges` (`id`, `meter_id`, `amount_egp`, `kwh_purchased`, `balance_after`, `recharge_date`, `notes`) VALUES
(1, 1, 100.00, 115.50, 112.40, DATE_SUB(NOW(), INTERVAL 45 DAY), 'شحن عبر فوري - بداية الشهر السابق'),
(2, 1, 150.00, 168.00, 172.10, DATE_SUB(NOW(), INTERVAL 20 DAY), 'شحن عبر تطبيق سهل بكارت NFC'),
(3, 1, 100.00, 105.00, 145.75, DATE_SUB(NOW(), INTERVAL 4 DAY), 'شحن طوارئ منتصف الشهر');

-- ------------------------------------------------------------------------------
-- 7. تنبيهات أولية للمستخدم (notifications)
-- ------------------------------------------------------------------------------
INSERT INTO `notifications` (`id`, `user_id`, `title_ar`, `title_en`, `message_ar`, `message_en`, `type`, `is_read`) VALUES
(1, 2, 'مرحباً بك في PowerWise Egypt!', 'Welcome to PowerWise Egypt!', 'تم تفعيل حسابك بنجاح وربط عداد الكهرباء رقم MTR-THEBES-2025-01. يمكنك الآن مراقبة استهلاك أجهزتك لحظياً.', 'Your account is active and linked to meter MTR-THEBES-2025-01. You can now monitor your devices.', 'info', 1),
(2, 2, 'تنبيه استهلاك التكييف', 'AC Consumption Notice', 'تكييف الصالة يعمل بمعدل مرتفع اليوم. ضبط الترموستات على 24 أو 25 درجة يوفر حتى 20% من الاستهلاك.', 'Living room AC consumption is high today. Setting thermostat to 24C saves up to 20%.', 'warning', 0),
(3, 2, 'الرصيد كافي لمدة 6 أيام', 'Balance Sufficient for 6 Days', 'بناءً على نمط استهلاكك الحالي، من المتوقع أن يكفي رصيدك الحالي (145.75 ج.م) لمدة 6 أيام قادمة.', 'Based on current consumption, your balance (145.75 EGP) is estimated to last 6 days.', 'success', 0);

-- ------------------------------------------------------------------------------
-- 8. قاعدة المعرفة والأسئلة الشائعة للشات بوت الذكي (faq - 42 سؤال وجواب)
-- مصنفة بدقة لدعم محرك TF-IDF والمطابقة بالكلمات المفتاحية
-- ------------------------------------------------------------------------------
INSERT INTO `faq` (`id`, `category`, `question_ar`, `question_en`, `keywords`, `answer_ar`, `answer_en`) VALUES
-- محور 1: الشرائح والتعرفة المصرية
(1, 'tariffs', 'ما هي شرائح الكهرباء في مصر وكيف تُحسب؟', 'What are electricity tiers in Egypt and how are they calculated?', 'شرائح, تعرفة, حساب, فاتورة, كيلوواط, استهلاك, مصر, اسعار', 'تنقسم شرائح الكهرباء المنزلية في مصر إلى 7 شرائح تصاعدية: الشريحة 1 (0-50 ك.و.س) بسعر 68 قرشاً، الشريحة 2 (51-100 ك.و.س) بسعر 78 قرشاً، وإذا تجاوزت 100 ك.و.س تلغى الأولى والثانية وتحسب من الصفر حتى 200 ك.و.س بسعر 95 قرشاً للشريحة 3، ثم الشريحة 4 (201-350 ك.و.س) بـ 155 قرشاً، الشريحة 5 (351-650 ك.و.س) بـ 195 قرشاً، ثم الشريحة 6 (حتى 1000 ك.و.س) بـ 210 قروش دون دعم، والشريحة 7 (أكثر من 1000 ك.و.س) بـ 223 قرشاً.', 'Egypt residential electricity is divided into 7 cumulative tiers starting from 68 piasters up to 223 piasters depending on monthly kWh volume.'),
(2, 'tariffs', 'كم سعر الكيلوواط ساعة الآن؟', 'How much does one kWh cost right now?', 'سعر الكيلوواط, تكلفة الكيلو, قرش, جنيه, الشريحة الحالية', 'سعر الكيلوواط غير ثابت في مصر، بل يتحدد حسب شريحة استهلاكك التراكمية في الشهر الحالي، ويبدأ من 68 قرشاً في الشريحة الأولى ويصل إلى 223 قرشاً في الشريحة السابعة عند الاستهلاك العالي.', 'The cost per kWh in Egypt varies by your cumulative monthly tier, starting at 0.68 EGP up to 2.23 EGP.'),
(3, 'tariffs', 'لماذا يتم خصم مبالغ كبيرة عند الانتقال للشريحة الثالثة؟', 'Why is a large amount deducted when moving to Tier 3?', 'خصم, فرق شريحة, قفزة, الشريحة الثالثة, 100 كيلو, خصم رصيد', 'عندما يتجاوز استهلاكك 100 كيلوواط ساعة خلال الشهر، يتم إسقاط الدعم الممنوح للشريحتين الأولى والثانية، ويعاد احتساب كامل الـ 100 كيلو السابقة بسعر الشريحة الثالثة (95 قرشاً)، مما يؤدي لخصم فرق السعر مباشرة من رصيد الكارت (حوالي 22 إلى 28 جنيهاً بالإضافة لمقابل خدمة العملاء).', 'When you exceed 100 kWh, tiers 1 & 2 subsidies are revoked and recalculated at tier 3 rate, creating an automatic balance deduction adjustment.'),
(4, 'tariffs', 'ما هي خدمة العملاء المضافة على الفاتورة؟', 'What is the customer service fee added to the bill?', 'خدمة عملاء, رسوم, مصاريف, دمغة, مبالغ اضافية', 'مقابل خدمة العملاء هو رسم شهري إلزامي يحدده جهاز تنظيم مرفق الكهرباء، ويتدرج من 1 جنيه للشريحة الأولى وحتى 40 جنيهاً للشريحة السابعة، ويخصم تلقائياً من الرصيد شهرياً.', 'Customer service fee is a statutory monthly charge ranging from 1 EGP for Tier 1 up to 40 EGP for Tier 7.'),
(5, 'tariffs', 'متى يعود العداد للشريحة الأولى؟', 'When does the meter reset back to Tier 1?', 'تصفير, اول الشهر, شريحة اولى, عودة للشريحة, بداية الشهر', 'يعود العداد مسبق الدفع برمجياً إلى الشريحة الأولى تلقائياً في تمام الساعة 00:00 (منتصف الليل) من أول دقيقة في بداية كل شهر ميلادي.', 'The prepaid meter resets back to Tier 1 automatically at midnight (00:00) on the 1st of every calendar month.'),
(6, 'tariffs', 'ما هو السعر الحدي (Marginal Price)؟', 'What is the marginal electricity price?', 'سعر حدي, marginal, تكلفة الجهاز الاضافي, سعر الكيلو القادم', 'السعر الحدي هو سعر الكيلوواط ساعة القادم الذي ستستهلكه الآن بناءً على شريحتك الحالية. يفيدك في معرفة كم سيكلفك تشغيل جهاز إضافي في الوقت الراهن بدقة.', 'Marginal price is the cost per additional kWh in your active monthly bracket.'),
(7, 'tariffs', 'هل تختلف أسعار الكهرباء للعداد الكارت عن العداد القديم؟', 'Are prepaid meter rates different from old mechanical meters?', 'كارت, عداد قديم, فاتورة, مقارنة, فرق سعر', 'لا، أسعار شرائح الكهرباء واحدة وموحدة رسمياً لكافة العدادات المنزلية سواء كانت عدادات كارت مسبقة الدفع أو عدادات ميكانيكية قديمة بالفاتورة.', 'No, tariff rates per kWh are identical for both prepaid card meters and old postpaid meters under Egyptian law.'),
(8, 'tariffs', 'كيف أحسب كم كيلوواط سأحصل عليه بمبلغ معين (التعرفة العكسية)؟', 'How to calculate kWh obtained from a specific amount (Inverse Tariff)?', 'تعرفة عكسية, كام كيلو, شحن, تحويل الجنيه لكيلو, ك.و.س', 'تعتمد دالة التعرفة العكسية على طرح رسوم خدمة العملاء والدمغات، ثم قسمة المبلغ الصافي على سعر شرائح الاستهلاك تصاعدياً لمعرفة عدد الكيلوواط الدقيق المتاح لك.', 'Inverse tariff deducts fixed fees then computes the piecewise kWh obtainable across sequential tiers.'),
(9, 'tariffs', 'هل توجد غرامات على التأخر في الشحن؟', 'Are there penalties for late recharging?', 'غرامة, قطع, تاخر, فصل الكهرباء, شحن كارت', 'العدادات مسبقة الدفع لا تفرض غرامات تأخير، ولكن في حال نفاد الرصيد بالكامل ولم يتم الشحن يُفصل التيار الكهربائي تلقائياً خارج أوقات الصديق والأعياد.', 'Prepaid meters do not levy late fines, but electricity cuts off when balance drops below zero outside friendly hours.'),
(10, 'tariffs', 'ما هي ساعات الصديق أو عدم فصل الكهرباء في العداد الكارت؟', 'What are friendly hours where power won’t cut off?', 'ساعات الصديق, صديق, الجمعة, العطلات, فصل العداد, المساء', 'ساعات الصديق هي فترات مبرمجة في العداد لا ينقطع فيها التيار حتى لو نفد الرصيد، وتبدأ عادة من الساعة 5 مساءً حتى 10 صباح اليوم التالي، وكذلك أيام الجمع والعطلات الرسمية.', 'Friendly hours prevent cutoff during nights (5 PM to 10 AM), Fridays, and official national holidays even if balance runs out.'),

-- محور 2: شحن الرصيد والعداد مسبق الدفع
(11, 'recharge', 'كام أشحن في العداد؟', 'How much should I recharge my meter?', 'كام اشحن, توصية الشحن, مبلغ الشحن, شحن كافي, اقتراح', 'يوفر لك تطبيق PowerWise أداة التوقع الذكي، حيث تحلل أجهزتك ومعدل استهلاكك التاريخي وتقترح عليك الشحن بمبلغ يضمن استمرار التيار بنسبة ثقة 80% للمدة التي تختارها (يوم، أسبوع، شهر).', 'Use PowerWise recharge recommendation feature which calculates your optimal amount with 80% statistical confidence.'),
(12, 'recharge', 'كيف أشحن كارت الكهرباء من الموبايل؟', 'How do I recharge electricity card from mobile?', 'شحن موبايل, nfc, سهل, فوري, جيبلي, شحن بالكارت', 'يمكنك شحن الكارت فوراً من الهاتف إذا كان هاتفك يدعم خاصية NFC عن طريق تطبيقات مثل: تطبيق (سهل)، (فوري)، أو (خالص)، بوضع الكارت خلف الهاتف والدفع بالبطاقة البنكية.', 'You can recharge via NFC-enabled smartphone using apps like Sahl, Fawry, or Khales anytime 24/7.'),
(13, 'recharge', 'لماذا يخصم العداد مبالغ فور وضع الكارت بعد الشحن؟', 'Why does the meter deduct money immediately after inserting card?', 'خصم فوري, رسوم شحن, خصم الرصيد, سلفني شكرا, فرق الشريحة', 'يرجع ذلك لأحد الأسباب التالية: سداد استهلاك فترة السلف (عند نفاد الرصيد سابقاً)، أو خصم مقابل خدمة العملاء الشهري المتأخر، أو فرق الترقية بين الشرائح.', 'Immediate deductions are usually due to repaying emergency borrowed power, monthly service fees, or bracket jump adjustments.'),
(14, 'recharge', 'ماذا أفعل لو لمبة التنبيه في العداد تومض باللون الأحمر؟', 'What should I do if the meter warning light blinks red?', 'لمبة حمرا, تلاعب, انذار, وميض, رصيد منخفض', 'الوميض السريع للمبة التنبيه يعني انخفاض الرصيد لأقل من 10 جنيهات كإنذار للشحن، أو أن هناك تلاعباً أو اهتزازاً في غطاء العداد، وينصح بإدخال الكارت في العداد لقراءة الرسالة.', 'A blinking red alarm indicates low credit (< 10 EGP) or a cover tamper event; insert card to read message code.'),
(15, 'recharge', 'كيف أعرف كم يوماً سيكفي الرصيد الحالي؟', 'How do I know how many days current balance will last?', 'كم يوم, الرصيد هيكفي, ايام متبقية, نفاذ الرصيد', 'يقسم التطبيق رصيدك المالي المتبقي على متوسط تكلفتك اليومية المحسوبة من أجهزتك المشغلة ونموذج التنبؤ بالذكاء الاصطناعي ليعطيك عدد الأيام المتبقية بدقة.', 'The app divides your live balance by predicted daily cost from your active appliances to display remaining days.'),
(16, 'recharge', 'هل رصيد الشحن له تاريخ صلاحية وينتهي؟', 'Does recharged balance expire if not used?', 'انتهاء الرصيد, صلاحية الشحن, هل الرصيد يضيع', 'لا، رصيد كارت الكهرباء لا تنتهي صلاحيته بالوقت، ويظل محفوظاً بالعداد ويُستهلك فقط حسب تشغيلك الفعلي للأجهزة.', 'No, prepaid credit has no expiry date and remains stored until consumed by your active appliances.'),
(17, 'recharge', 'هل كارت العداد يعمل في أي عداد آخر؟', 'Can one meter card be used on another meter?', 'كارت اخر, تبديل الكارت, عداد الجار, استخدام الكارت', 'لا، كل كارت مشفر ومبرمج برقم مسلسل فريد يرتبط بعداد واحد محدد ولا يمكن استخدامه مع أي عداد آخر على الإطلاق.', 'No, each meter card is cryptographically locked to its specific meter serial number.'),
(18, 'recharge', 'ماذا يحدث إذا انقطع التيار بسبب نفاد الرصيد في وقت متأخر؟', 'What happens if power cuts off late at night due to zero credit?', 'قطع الكهرباء, سلف, طوارئ, استلاف, كارت فاضي', 'يمكنك وضع كارت الكهرباء في العداد وهو فارغ لإعادة تشغيل التيار مؤقتاً لساعات إضافية كمهلة طوارئ حتى تتمكن من الشحن في الصباح.', 'Inserting the empty card into the meter often unlocks temporary emergency credit until morning.'),

-- محور 3: الأجهزة المنزلية ومعدلات استهلاكها
(19, 'devices', 'ما هو أكثر جهاز يستهلك كهرباء في المنزل؟', 'Which home appliance consumes the most electricity?', 'اكتر جهاز, استهلاك عالي, التكييف, السخان, الغلاية', 'التكييفات وسخانات المياه وغلاية الشاي (الكاتيل) والمكواة هي أكثر الأجهزة استهلاكاً لأنها تحول الطاقة إلى حرارة أو تبريد بقدرات تتراوح بين 1000 و3000 وات.', 'Air conditioners, water heaters, electric kettles, and irons consume the most electricity due to high thermal power (1-3 kW).'),
(20, 'devices', 'كم يستهلك التكييف 1.5 حصان في الساعة؟', 'How much does a 1.5 HP AC consume per hour?', 'تكييف, 1.5 حصان, تبريد, استهلاك التكييف', 'يستهلك التكييف بقدرة 1.5 حصان ما بين 1.0 إلى 1.4 كيلوواط ساعة في الساعة في المتوسط، ويزداد الاستهلاك عند ضبط درجة الحرارة أقل من 24 درجة مئوية.', 'A 1.5 HP AC consumes roughly 1.0 to 1.4 kWh per operating hour depending on thermostat setting.'),
(21, 'devices', 'كم تستهلك الثلاجة يومياً؟', 'How much electricity does a refrigerator consume per day?', 'ثلاجة, نوفروست, استهلاك الثلاجة, تبريد المطبخ', 'تستهلك الثلاجة الحديثة (نوفروست 16 قدم) حوالي 1.5 إلى 2.5 كيلوواط ساعة يومياً، حيث يفصل الموتور ويعمل وفقاً لدرجة الحرارة المختارة.', 'A standard no-frost refrigerator consumes around 1.5 to 2.5 kWh per day with intermittent compressor cycles.'),
(22, 'devices', 'هل شاحن الموبايل في المقبس يستهلك كهرباء بدون هاتف؟', 'Does a phone charger consume electricity when plugged without phone?', 'شاحن, مقبس, فيشة, شاحن موبايل, سحب كهرباء', 'نعم، يستهلك الشاحن المتروك في الكهرباء طاقة ضائعة خفية (Phantom Load) تتراوح بين 0.1 إلى 0.5 وات، وينصح دائماً بنزعه لتوفير الكهرباء والسلامة.', 'Yes, plugged chargers draw phantom standby power (0.1 - 0.5W); unplugging them saves energy and ensures safety.'),
(23, 'devices', 'كم تستهلك لمبة LED مقارنة باللمبة العادية؟', 'How much does an LED bulb consume compared to incandescent?', 'لمبة ليد, لمبة عادية, انارة, فرق اللمبات', 'توفر لمبة LED حوالي 85% من الطاقة؛ كلمبة LED بقدرة 9 وات تعطي نفس شدة إضاءة اللمبة المتوهجة القديمة ذات الـ 60 وات.', 'LED bulbs save ~85% energy: a 9W LED provides equivalent illumination to a 60W incandescent bulb.'),
(24, 'devices', 'كم تستهلك غلاية المياه (الكاتيل)؟', 'How much does an electric kettle consume?', 'كاتيل, غلاية مياه, شاي, تسخين مياه', 'تتراوح قدرة غلاية المياه بين 1500 و2200 وات، وعلى الرغم من سرعة غليانها إلا أن الاستخدام المتكرر يومياً يرفع الاستهلاك الشهري بعدة كيلوواطات.', 'Electric kettles run between 1500W-2200W; frequent daily use adds significant monthly kWh consumption.'),
(25, 'devices', 'كم يستهلك راوتر الواي فاي شهرياً؟', 'How much does a WiFi router consume per month?', 'راوتر, نت, انترنت, استهلاك شهري', 'يستهلك الراوتر حوالي 10 وات، وبما أنه يعمل 24 ساعة يومياً فإن استهلاكه الشهري يبلغ حوالي 7.2 كيلوواط ساعة (حوالي 5 إلى 7 جنيهات فقط شهرياً).', 'A 10W router running 24/7 consumes ~7.2 kWh per month (~5 to 7 EGP).'),
(26, 'devices', 'كيف أحسب استهلاك أي جهاز بالكيلوواط ساعة؟', 'How to calculate any device consumption in kWh?', 'معادلة, حساب الاستهلاك, قانون الوات, ك.و.س', 'المعادلة بسيطة: (قدرة الجهاز بالوات × عدد ساعات التشغيل) ÷ 1000 = الاستهلاك بالكيلوواط ساعة. مثال: مكواة 1500 وات لمدة ساعتين = (1500 × 2) ÷ 1000 = 3 ك.و.س.', 'Equation: (Device Watts x Operating Hours) / 1000 = kWh.'),

-- محور 4: نصائح التوفير وترشيد الاستهلاك
(27, 'saving', 'كيف أقلل فاتورة الكهرباء شهرياً؟', 'How can I reduce my monthly electricity bill?', 'توفير, ترشيد, تقليل الفاتورة, نصائح, وفر', '1. اضبط التكييف على 24 أو 25 درجة.\n2. افصل شواحن الأجهزة والأجهزة في وضع الاستعداد.\n3. استخدم لمبات LED.\n4. شغل السخان الكهربائي قبل الاستحمام بنصف ساعة فقط ثم افصله.\n5. تجنب فتح الثلاجة بشكل متكرر دون داعٍ.', 'Top tips: Set AC to 24C, unplug idle chargers, use LED bulbs, turn water heater on only 30 min before use, and avoid opening fridge unnecessarily.'),
(28, 'saving', 'ما هي أفضل درجة حرارة لضبط التكييف لتوفير الكهرباء؟', 'What is the best AC temperature to save power?', 'درجة التكييف, 24 درجة, ترشيد التكييف, تبريد اقتصادي', 'أفضل درجة اقتصادية ومريحة هي 24 أو 25 درجة مئوية؛ فكل درجة أقل تزيد من استهلاك الكهرباء بنسبة تصل إلى 6% إلى 8%.', '24C to 25C is optimal; each degree lower increases power consumption by roughly 6% to 8%.'),
(29, 'saving', 'كيف أوفر في استهلاك سخان المياه الكهربائي؟', 'How to save on electric water heater consumption?', 'سخان كهربائي, توفير السخان, حرارة السخان', 'اضبط ثرموستات السخان على 50 إلى 60 درجة مئوية كحد أقصى، ولا تتركه يعمل طوال اليوم، بل شغله قبل الاستخدام بـ 30 دقيقة.', 'Set heater thermostat to 50C-60C max and turn it on only 30 minutes before usage rather than leaving it on 24/7.'),
(30, 'saving', 'هل إطفاء النور وتشغيله يستهلك كهرباء أكثر؟', 'Does turning lights off and on consume more electricity?', 'اطفاء النور, تشغيل اللمبة, ترشيد الاضاءة', 'هذه معلومة شائعة خاطئة؛ فإطفاء لمبات LED حتى لو لدقائق قليلة يوفر الطاقة دائماً ولا يستهلك زيادة عند إعادة التشغيل.', 'This is a myth for modern LED lighting; turning lights off always saves net electricity.'),
(31, 'saving', 'كيف يساعدني تطبيق PowerWise في تقليل الشريحة؟', 'How does PowerWise help keep me in lower tiers?', 'حماية الشريحة, تحذير, مراقبة, ترشيد ذكي', 'يقوم PowerWise بمراقبة استهلاكك التراكمي ويرسل تنبيهات مبكرة قبل تجاوز حد 100 ك.و.س أو 650 ك.و.س لمنع القفز إلى شرائح أعلى وأغلى.', 'PowerWise monitors cumulative kWh and dispatches proactive alerts before you cross critical 100 or 650 kWh thresholds.'),
(32, 'saving', 'هل تشغيل الغسالة بحمولة كاملة يوفر كهرباء؟', 'Does running the washing machine with full loads save power?', 'غسالة, حمولة, توفير الغسيل, دورة الغسيل', 'نعم، تشغيل الغسالة بحمولتها المقررة يوفر المياه والكهرباء معاً مقارنة بتشغيل عدة دورات صغيرة، ويفضل الغسيل بالماء البارد عند الإمكان.', 'Yes, washing with full rated loads reduces total cycle runs and electricity, especially when using cold wash settings.'),
(33, 'saving', 'ما هي الأحمال الخفية (Phantom Loads)؟', 'What are phantom loads and vampire power?', 'احمال خفية, استهلاك خفي, وضع الاستعداد, ستاند باي', 'هي الطاقة التي تستهلكها الأجهزة الكهربائية وهي مطفأة ولكن ما زالت متصلة بالقابس، مثل التلفزيون في وضع الاستعداد والشواحن ورسيفر التلفزيون، وتمثل حتى 10% من الفاتورة.', 'Standby vampire power consumed by plugged inactive devices like standby TVs, set-top boxes, and chargers (up to 10% of total bill).'),
(34, 'saving', 'كيف يؤثر تراكم الثلج في الفريزر على استهلاك الكهرباء؟', 'How does frost buildup in freezer affect consumption?', 'ثلج الفريزر, ثلاجة, تجميد, صيانة', 'تراكم الثلج بسماكة تزيد عن 5 ملم يعمل كعازل حراري يجبر الموتور على العمل لفترات أطول، مما يزيد استهلاك الثلاجة بنسبة تصل إلى 20%.', 'Frost buildup greater than 5mm insulates cooling coils, forcing the compressor to run longer and consuming up to 20% more power.'),

-- محور 5: استخدام وتطبيق PowerWise والميزات الذكية
(35, 'app', 'ما هو تطبيق PowerWise Egypt؟', 'What is PowerWise Egypt application?', 'تطبيق, باور وايز, مشروع تخرج, معهد طيبة, فكرة التطبيق', 'هو منصة ويب ذكية متكاملة مصممة لمساعدة مستخدمي العدادات مسبقة الدفع (الكارت) في مصر على مراقبة استهلاكهم لحظياً، والتنبؤ باستهلاك الأيام القادمة بالذكاء الاصطناعي، وتوصية بمبالغ الشحن المناسبة لتفادي انقطاع التيار.', 'PowerWise Egypt is a smart web platform for Egyptian prepaid electricity meters, tracking live appliance usage and predicting recharge needs using AI.'),
(36, 'app', 'من قام بتطوير مشروع PowerWise Egypt؟', 'Who developed PowerWise Egypt project?', 'معهد طيبة, المطورين, الطلاب, مشروع التخرج, فريق العمل', 'تم تطوير هذا المشروع كـ "مشروع تخرج" متميز لطلبة قسم علوم الحاسب ونظم المعلومات بـ "معهد طيبة العالي للتكنولوجيا والمعلومات" بإشراف أعضاء هيئة التدريس.', 'Developed as a graduation project by students of Thebes Higher Institute for Technology and Information under faculty supervision.'),
(37, 'app', 'كيف يحدد التطبيق توصية الشحن الذكي؟', 'How does the smart recharge recommendation work?', 'توصية الشحن, خوارزمية الشحن, كمية الشحن, ذكاء اصطناعي', 'يستخدم التطبيق نموذج انحدار إحصائي وتعلم آلة مع تحليل نطاقات الثقة (Quantile Confidence Interval بنسبة 80%) ليحسب المبلغ بالجنيه الذي يكفيك بأمان للأيام المختارة مع مراعاة الشرائح الحالية.', 'The app applies Quantile Regression / Bootstrap confidence intervals (80% level) to recommend a financial amount guaranteeing uninterrupted power.'),
(38, 'app', 'كيف أضيف جهازاً كهربائياً جديداً في حسابي؟', 'How do I add a new device to my account?', 'اضافة جهاز, جهاز جديد, تسجيل جهاز, وات', 'من صفحة "الأجهزة"، اضغط على زر "إضافة جهاز"، واختر نوع الجهاز أو "جهاز آخر"، ثم حدد القدرة بالوات وعدد الوحدات وساعات التشغيل المتوقعة واحفظ.', 'Navigate to Devices page, click Add Device, select appliance type or Custom, specify watts, quantity, and daily hours, then save.'),
(39, 'app', 'هل بيانات استهلاكي في التطبيق دقيقة 100%؟', 'Is my consumption data in the app 100% exact?', 'دقة البيانات, نتائج تقديرية, هل هي مؤكدة, صحة التقديرات', 'البيانات المعروضة هي نتائج تقديرية ذكية مبنية على المواصفات القياسية لأجهزتك ومعدل تشغيلك، لمساعدتك في التخطيط والترشيد، وليست بديلاً قانونياً عن قراءة العداد الرسمية.', 'Data and predictions are high-accuracy engineering estimates meant for guidance and planning, not legal replacements for official billing meters.'),
(40, 'app', 'هل يعمل التطبيق باللغتين العربية والإنجليزية؟', 'Does the app support both Arabic and English?', 'لغة, عربي, انجليزي, تحويل اللغة, rtl', 'نعم، التطبيق يدعم الواجهة العربية (RTL) بشكل أصلي، بالإضافة إلى خيار التبديل الفوري للغة الإنجليزية (LTR) ودعم الوضعين الفاتح والليلي (Dark Mode).', 'Yes, PowerWise offers full bidirectional support: Arabic RTL by default, instantaneous English LTR switch, and Dark Mode.'),
(41, 'app', 'كيف يعمل الشات بوت الذكي بدون اتصال بـ API خارجي مدفوع؟', 'How does the chatbot operate locally without external paid APIs?', 'شات بوت محلي, ذكاء اصطناعي, tf-idf, معالجة لغة عربية, محلي', 'يعمل الشات بوت محلياً بالكامل عبر تقنيات معالجة اللغات الطبيعية (NLP) بمكتبة Scikit-Learn، من خلال تنظيف النص العربي وتوحيد الحروف وحساب مصفوفة TF-IDF ومقياس التشابه Cosine Similarity مع قاعدة المعرفة، بالإضافة للربط المباشر مع بيانات أجهزة المستخدم.', 'The chatbot runs 100% locally using Arabic NLP normalization, TF-IDF vectorization, Cosine Similarity, and live database metric inspection.'),
(42, 'app', 'كيف يمكن تعديل أسعار شرائح الكهرباء في التطبيق؟', 'How can electricity tariffs be updated in the system?', 'تعديل الاسعار, لوحة الادارة, admin, تحديث التعرفة', 'يمكن لمدير النظام (Admin) الدخول إلى لوحة إدارة التعرفة وتعديل أسعار الكيلوواط ورسوم خدمة العملاء لكل شريحة فور صدور أي قرار رسمي جديد من وزارة الكهرباء.', 'The Admin user can update kWh rates and service fees dynamically through the Admin Tariff Management panel upon official updates.');
