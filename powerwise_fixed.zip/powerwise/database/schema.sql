-- ==============================================================================
-- PowerWise Egypt - Database Schema (MySQL)
-- مراقب ذكي لاستهلاك الكهرباء للعدادات مسبقة الدفع في مصر
-- مشروع تخرج لطلبة معهد طيبة العالي للتكنولوجيا والمعلومات
-- الترميز: UTF-8 Unicode (utf8mb4) لدعم كامل ودقيق للغة العربية
-- ==============================================================================

-- إنشاء قاعدة البيانات إذا لم تكن موجودة
CREATE DATABASE IF NOT EXISTS `powerwise_db`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `powerwise_db`;

-- تعطيل فحص المفاتيح الأجنبية مؤقتاً أثناء التهيئة
SET FOREIGN_KEY_CHECKS = 0;

-- ------------------------------------------------------------------------------
-- 1. جدول المستخدمين (users)
-- يحفظ بيانات المستخدمين، كلمات المرور المشفرة، وأدوار الوصول (admin/user)
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `full_name` VARCHAR(100) NOT NULL COMMENT 'الاسم بالكامل',
  `email` VARCHAR(150) NOT NULL UNIQUE COMMENT 'البريد الإلكتروني لتسجيل الدخول',
  `password_hash` VARCHAR(255) NOT NULL COMMENT 'كلمة المرور المشفرة بخوارزمية آمنة (scrypt/bcrypt)',
  `role` ENUM('user', 'admin') NOT NULL DEFAULT 'user' COMMENT 'نوع الصلاحية: مستخدم عادي أو مدير نظام',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'تاريخ إنشاء الحساب',
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'تاريخ آخر تحديث للبيانات',
  INDEX `idx_users_email` (`email`),
  INDEX `idx_users_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='جدول المستخدمين';

-- ------------------------------------------------------------------------------
-- 2. جدول العدادات (meters)
-- يحفظ معلومات العداد مسبق الدفع (كارت) المرتبط بكل مستخدم، والرصيد الحالي
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `meters`;
CREATE TABLE `meters` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL COMMENT 'معرف المستخدم المالك للعداد',
  `meter_number` VARCHAR(50) NOT NULL UNIQUE COMMENT 'رقم العداد المطبوع على العداد أو الكارت',
  `current_balance` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT 'الرصيد المالي الحالي بالجنيه المصري',
  `tariff_category` VARCHAR(50) NOT NULL DEFAULT 'residential' COMMENT 'نوع النشاط: سكني، تجاري..',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'تاريخ إضافة العداد',
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'تاريخ آخر تحديث للرصيد',
  CONSTRAINT `fk_meters_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  INDEX `idx_meters_user` (`user_id`),
  INDEX `idx_meters_number` (`meter_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='جدول العدادات الكهربائية';

-- ------------------------------------------------------------------------------
-- 3. جدول أنواع الأجهزة القياسية (device_types)
-- يحتوي على الأجهزة المنزلية الشائعة مع حدود القدرة بالوات لكل نوع
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `device_types`;
CREATE TABLE `device_types` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name_ar` VARCHAR(100) NOT NULL COMMENT 'اسم نوع الجهاز بالعربية',
  `name_en` VARCHAR(100) NOT NULL COMMENT 'اسم نوع الجهاز بالإنجليزية',
  `min_watts` INT NOT NULL COMMENT 'الحد الأدنى للقدرة بالوات',
  `max_watts` INT NOT NULL COMMENT 'الحد الأقصى للقدرة بالوات',
  `typical_watts` INT NOT NULL COMMENT 'القدرة الشائعة المعتادة بالوات',
  `category` VARCHAR(50) NOT NULL DEFAULT 'general' COMMENT 'تصنيف الجهاز (إضاءة، تبريد، مطبخ...)',
  `icon_svg_name` VARCHAR(50) NOT NULL DEFAULT 'device-default' COMMENT 'اسم معرف أيقونة SVG',
  `is_custom` BOOLEAN NOT NULL DEFAULT FALSE COMMENT 'هل هو نوع مخصص يحدده المستخدم بحرية',
  INDEX `idx_dev_types_category` (`category`),
  INDEX `idx_dev_types_custom` (`is_custom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='أنواع الأجهزة الكهربائية القياسية والحدود';

-- ------------------------------------------------------------------------------
-- 4. جدول أجهزة المستخدمين (devices)
-- الأجهزة الفعلية التي يضيفها المستخدم في شقته مع القدرة والعدد وساعات التشغيل
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `devices`;
CREATE TABLE `devices` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL COMMENT 'معرف المستخدم المالك',
  `device_type_id` INT NOT NULL COMMENT 'معرف نوع الجهاز القياسي',
  `custom_name` VARCHAR(100) NOT NULL COMMENT 'اسم مخصص للجهاز مثل: تكييف الصالة، تلفزيون الغرفة',
  `rated_watts` INT NOT NULL COMMENT 'القدرة المختارة للجهاز بالوات',
  `count` INT NOT NULL DEFAULT 1 COMMENT 'عدد الوحدات المتماثلة',
  `daily_hours` DECIMAL(4,2) NOT NULL DEFAULT 1.00 COMMENT 'متوسط ساعات التشغيل اليومية المتوقعة',
  `is_active` BOOLEAN NOT NULL DEFAULT TRUE COMMENT 'حالة تشغيل الجهاز لحظياً (ON / OFF)',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'تاريخ الإضافة',
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'تاريخ التحديث',
  CONSTRAINT `fk_devices_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_devices_type` FOREIGN KEY (`device_type_id`) REFERENCES `device_types` (`id`) ON DELETE RESTRICT,
  INDEX `idx_devices_user` (`user_id`),
  INDEX `idx_devices_active` (`user_id`, `is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='أجهزة المستخدمين المسجلة';

-- ------------------------------------------------------------------------------
-- 5. جدول سجلات الاستهلاك (usage_logs)
-- يسجل قراءات الاستهلاك المحسوبة بالساعة واليوم للأجهزة وحساب التكلفة
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `usage_logs`;
CREATE TABLE `usage_logs` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL COMMENT 'معرف المستخدم',
  `device_id` INT NULL COMMENT 'معرف الجهاز (يمكن أن يكون NULL للاستهلاك الإجمالي المجمع)',
  `timestamp` DATETIME NOT NULL COMMENT 'وقت وتاريخ الاستهلاك',
  `duration_hours` DECIMAL(4,2) NOT NULL DEFAULT 1.00 COMMENT 'مدة التشغيل بالساعات',
  `energy_kwh` DECIMAL(10,4) NOT NULL COMMENT 'الطاقة المستهلكة بالكيلوواط ساعة',
  `calculated_cost` DECIMAL(10,4) NOT NULL DEFAULT 0.0000 COMMENT 'التكلفة المحسوبة بالجنيه المصري وقت التسجيل',
  CONSTRAINT `fk_usage_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_usage_device` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE SET NULL,
  INDEX `idx_usage_user_timestamp` (`user_id`, `timestamp`),
  INDEX `idx_usage_device` (`device_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='سجلات استهلاك الطاقة التاريخية';

-- ------------------------------------------------------------------------------
-- 6. جدول عمليات الشحن (recharges)
-- يسجل كل عملية شحن كارت بالجنيه المصري وما يقابلها من كيلوواط ساعة
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `recharges`;
CREATE TABLE `recharges` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `meter_id` INT NOT NULL COMMENT 'معرف العداد المشحون',
  `amount_egp` DECIMAL(10,2) NOT NULL COMMENT 'قيمة الشحن بالجنيه المصري',
  `kwh_purchased` DECIMAL(10,2) NOT NULL COMMENT 'كمية الكيلوواط ساعة المشتراة تقريبياً',
  `balance_after` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT 'الرصيد المتبقي بعد إضافة الشحن',
  `recharge_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'تاريخ ووقت عملية الشحن',
  `notes` VARCHAR(255) NULL COMMENT 'ملاحظات إضافية (مثل: منفذ فوري، أمان، تطبيق سهل)',
  CONSTRAINT `fk_recharges_meter` FOREIGN KEY (`meter_id`) REFERENCES `meters` (`id`) ON DELETE CASCADE,
  INDEX `idx_recharges_meter_date` (`meter_id`, `recharge_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='سجل عمليات شحن كروت الكهرباء';

-- ------------------------------------------------------------------------------
-- 7. جدول شرائح التعرفة المصرية (tariffs)
-- يحفظ هيكل شرائح استهلاك الكهرباء السكنية في مصر (EgyptERA)
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `tariffs`;
CREATE TABLE `tariffs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `tier_number` INT NOT NULL COMMENT 'رقم الشريحة (1 إلى 7)',
  `tier_name_ar` VARCHAR(100) NOT NULL COMMENT 'اسم الشريحة بالعربية (مثال: الشريحة الأولى)',
  `tier_name_en` VARCHAR(100) NOT NULL COMMENT 'اسم الشريحة بالإنجليزية (Tier 1)',
  `min_kwh` DECIMAL(10,2) NOT NULL COMMENT 'الحد الأدنى للكيلوواط ساعة شهرياً',
  `max_kwh` DECIMAL(10,2) NOT NULL COMMENT 'الحد الأقصى للكيلوواط ساعة شهرياً (999999 لأعلى شريحة)',
  `price_per_kwh` DECIMAL(10,4) NOT NULL COMMENT 'سعر الكيلوواط ساعة بالجنيه المصري',
  `service_fee` DECIMAL(10,2) NOT NULL DEFAULT 0.00 COMMENT 'مقابل خدمة العملاء بالجنيه المصري',
  `bracket_group` INT NOT NULL DEFAULT 1 COMMENT 'مجموعة الشرائح للتعامل مع قفزة الاستهلاك عند تجاوز 100 و 650 ك.و.س',
  `effective_date` DATE NOT NULL COMMENT 'تاريخ بدء سريان هذه التعرفة',
  `source` VARCHAR(255) NOT NULL COMMENT 'المصدر والقرار الوزاري المعتمد',
  `is_active` BOOLEAN NOT NULL DEFAULT TRUE COMMENT 'هل الشريحة مفعلة حالياً',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_tariffs_active_tier` (`is_active`, `tier_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='تعرفة شرائح الكهرباء المصرية';

-- ------------------------------------------------------------------------------
-- 8. جدول التوقعات والتنبؤ الذكي (predictions)
-- يخزن نتائج تنبؤ نموذج الـ Machine Learning للاستهلاك القادم مع نطاقات الثقة
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `predictions`;
CREATE TABLE `predictions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL COMMENT 'معرف المستخدم',
  `prediction_date` DATE NOT NULL COMMENT 'تاريخ إصدار التوقع',
  `target_period_days` INT NOT NULL COMMENT 'الفترة المستهدفة بالأيام (1، 7، 30 يوم)',
  `predicted_kwh` DECIMAL(10,3) NOT NULL COMMENT 'الاستهلاك المتوقع بالكيلوواط ساعة',
  `lower_bound_kwh` DECIMAL(10,3) NOT NULL COMMENT 'الحد الأدنى لنطاق الثقة (10%)',
  `upper_bound_kwh` DECIMAL(10,3) NOT NULL COMMENT 'الحد الأقصى لنطاق الثقة (90%)',
  `predicted_cost_egp` DECIMAL(10,2) NOT NULL COMMENT 'التكلفة المالية التقديرية بالجنيه',
  `model_version` VARCHAR(50) NOT NULL DEFAULT 'v1.0-rf' COMMENT 'إصدار النموذج والخوارزمية',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_predictions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  INDEX `idx_pred_user_date` (`user_id`, `prediction_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='توقعات نماذج تعلم الآلة للاستهلاك';

-- ------------------------------------------------------------------------------
-- 9. جدول الإشعارات والتنبيهات (notifications)
-- تنبيهات انخفاض الرصيد وقرب انتهاء الشريحة والقفز لشرائح أعلى
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL COMMENT 'معرف المستخدم المستلم للإشعار',
  `title_ar` VARCHAR(150) NOT NULL COMMENT 'عنوان التنبيه بالعربية',
  `title_en` VARCHAR(150) NOT NULL COMMENT 'عنوان التنبيه بالإنجليزية',
  `message_ar` TEXT NOT NULL COMMENT 'نص التنبيه بالعربية',
  `message_en` TEXT NOT NULL COMMENT 'نص التنبيه بالإنجليزية',
  `type` ENUM('warning', 'danger', 'info', 'success') NOT NULL DEFAULT 'info' COMMENT 'درجة خطورة أو نوع التنبيه',
  `is_read` BOOLEAN NOT NULL DEFAULT FALSE COMMENT 'هل قرأ المستخدم التنبيه',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  INDEX `idx_notif_user_read` (`user_id`, `is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='إشعارات وتنبيهات النظام للمستخدمين';

-- ------------------------------------------------------------------------------
-- 10. جدول قاعدة المعرفة والأسئلة الشائعة للشات بوت (faq)
-- يحتوي على الأسئلة والأجوبة المصنفة مع الكلمات المفتاحية لمطابقة TF-IDF
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `faq`;
CREATE TABLE `faq` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `category` VARCHAR(50) NOT NULL COMMENT 'التصنيف (شرائح، أجهزة، ترشيد، شحن، عام)',
  `question_ar` VARCHAR(255) NOT NULL COMMENT 'نص السؤال بالعربية',
  `question_en` VARCHAR(255) NOT NULL COMMENT 'نص السؤال بالإنجليزية',
  `keywords` TEXT NOT NULL COMMENT 'الكلمات المفتاحية والمترادفات المفصولة بفواصل',
  `answer_ar` TEXT NOT NULL COMMENT 'الإجابة التفصيلية بالعربية',
  `answer_en` TEXT NOT NULL COMMENT 'الإجابة بالإنجليزية',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_faq_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='قاعدة المعرفة والأسئلة الشائعة للشات بوت الذكي';

-- ------------------------------------------------------------------------------
-- 11. جدول سجلات محادثات الشات بوت (chat_logs)
-- يسجل رسائل المستخدم وإجابات الشات بوت ونسبة الثقة لتطوير الخدمة
-- ------------------------------------------------------------------------------
DROP TABLE IF EXISTS `chat_logs`;
CREATE TABLE `chat_logs` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NULL COMMENT 'معرف المستخدم المتحدث (أو NULL للزوار)',
  `user_message` TEXT NOT NULL COMMENT 'رسالة واستفسار المستخدم',
  `bot_response` TEXT NOT NULL COMMENT 'رد المساعد الذكي',
  `matched_faq_id` INT NULL COMMENT 'معرف السؤال المتطابق من جدول faq إن وجد',
  `confidence_score` DECIMAL(5,4) NOT NULL DEFAULT 0.0000 COMMENT 'درجة التشابه والتطابق (Cosine Similarity)',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_chat_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_chat_faq` FOREIGN KEY (`matched_faq_id`) REFERENCES `faq` (`id`) ON DELETE SET NULL,
  INDEX `idx_chat_user` (`user_id`),
  INDEX `idx_chat_matched_faq` (`matched_faq_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='سجلات استفسارات ومحادثات المساعد الذكي';

-- إعادة تفعيل فحص المفاتيح الأجنبية
SET FOREIGN_KEY_CHECKS = 1;
