# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Database Initializer Script
سكريبت تهيئة وتغذية قاعدة بيانات MySQL تلقائياً
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

import sys
import os
from pathlib import Path

# إضافة مسار المشروع لتضمين ملف config
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

import pymysql
from backend.config import Config

def run_sql_file(cursor, file_path: Path):
    """قراءة وتنفيذ ملف SQL يحتوي على عدة استعلامات مفصولة بفواصل منقوطة"""
    print(f"[*] جاري قراءة وتنفيذ الملف: {file_path.name}...")
    with open(file_path, "r", encoding="utf-8") as f:
        sql_content = f.read()

    # تقسيم الاستعلامات بناءً على الفاصلة المنقوطة مع استبعاد السطور الفارغة والتعليقات
    statements = sql_content.split(";")
    executed_count = 0

    for raw_stmt in statements:
        stmt = raw_stmt.strip()
        if not stmt:
            continue
        try:
            cursor.execute(stmt)
            executed_count += 1
        except Exception as ex:
            # تجاهل تحذيرات الجداول إن لم تكن موجودة عند DROP
            if "Unknown table" not in str(ex):
                print(f"[!] تنبيه أثناء تنفيذ جملة SQL: {ex}")

    print(f"[+] تم تنفيذ {executed_count} استعلام من ملف {file_path.name} بنجاح.")

def main():
    print("=" * 65)
    print(" PowerWise Egypt - تهيئة قاعدة بيانات MySQL")
    print(f" {Config.INSTITUTE_NAME_AR} — مشروع تخرج")
    print("=" * 65)
    print(f"المضيف (Host): {Config.DB_HOST}:{Config.DB_PORT}")
    print(f"المستخدم (User): {Config.DB_USER}")
    print(f"اسم القاعدة (Database): {Config.DB_NAME}")
    print("-" * 65)

    try:
        # 1. الاتصال المبدئي بخادم MySQL لإنشاء القاعدة إن لم تكن موجودة
        print("[1/3] محاولة الاتصال بخادم MySQL...")
        conn = pymysql.connect(
            host=Config.DB_HOST,
            user=Config.DB_USER,
            password=Config.DB_PASS,
            port=int(Config.DB_PORT),
            charset="utf8mb4",
            autocommit=True
        )
        cursor = conn.cursor()

        print(f"[2/3] فحص/إنشاء قاعدة البيانات `{Config.DB_NAME}`...")
        cursor.execute(
            f"CREATE DATABASE IF NOT EXISTS `{Config.DB_NAME}` "
            f"CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
        )
        cursor.execute(f"USE `{Config.DB_NAME}`;")

        # 2. قراءة وتنفيذ schema.sql
        db_dir = Path(__file__).resolve().parent
        schema_file = db_dir / "schema.sql"
        seed_file = db_dir / "seed.sql"

        if not schema_file.exists():
            print(f"[X] خطأ: لم يتم العثور على ملف المخطط: {schema_file}")
            return

        print("[3/3] إنشاء الجداول والقيود (Schema)...")
        run_sql_file(cursor, schema_file)

        # 3. قراءة وتنفيذ seed.sql
        if seed_file.exists():
            print("[+] إدخال البيانات المبدئية والتجريبية (Seed Data)...")
            run_sql_file(cursor, seed_file)
        else:
            print("[!] تنبيه: ملف seed.sql غير موجود، تم الاكتفاء بالمخطط.")

        cursor.close()
        conn.close()

        print("=" * 65)
        print(" تهيئة قاعدة البيانات تمت بنجاح تام!")
        print(" الحسابات الجاهزة للتجربة:")
        print(" 1. حساب الإدارة (Admin): admin@powerwise.eg | كلمة السر: Admin@123456")
        print(" 2. حساب الطالب التجريبي: student@powerwise.eg | كلمة السر: Student@123456")
        print("=" * 65)

    except pymysql.MySQLError as err:
        print(f"\n[X] حدث خطأ أثناء الاتصال بقاعدة MySQL:\n{err}")
        print("\nيرجى التأكد من:")
        print(" 1. تشغيل خادم MySQL (مثل XAMPP / WampServer / MySQL Service).")
        print(" 2. ضبط كلمة مرور المستخدم root في ملف .env أو backend/config.py إن كانت موجودة.")

if __name__ == "__main__":
    main()
