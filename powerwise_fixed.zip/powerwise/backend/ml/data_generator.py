# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Synthetic Energy Data Generator
مولد بيانات استهلاك واقعية وسريعة لمدة 12 شهراً تراعي مواسم مصر وساعات الذروة
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, Any, Tuple, Optional

# متوسط درجات الحرارة الشهرية التقديرية في مصر (°C)
EGYPT_MONTHLY_AVG_TEMPS = {
    1: 14.0,  # يناير (شتاء)
    2: 15.5,  # فبراير
    3: 18.5,  # مارس (ربيع)
    4: 22.5,  # أبريل
    5: 27.0,  # مايو
    6: 31.0,  # يونيو (صيف حار)
    7: 34.5,  # يوليو (ذروة الصيف والتكييف)
    8: 34.0,  # أغسطس (ذروة الصيف)
    9: 30.5,  # سبتمبر
    10: 26.0, # أكتوبر (خريف)
    11: 20.5, # نوفمبر
    12: 15.5  # ديسمبر (شتاء)
}

def generate_daily_synthetic_dataset(
    days: int = 365,
    random_state: int = 42
) -> pd.DataFrame:
    """
    توليد مصفوفة بيانات يومية واقعية فائقة السرعة لمدة عام كامل (365 يوماً):
    - الفروق الموسمية (الصيف أعلى استهلاكاً بفضل التكييف)
    - عطلات نهاية الأسبوع (الجمعة والسبت استهلاك أعلى)
    - درجات الحرارة ومتوسطاتها
    - ميزات الـ Lag والـ Rolling لتغذية خوارزميات ML
    """
    np.random.seed(random_state)
    end_date = datetime.now().date()
    dates = pd.date_range(end=end_date, periods=days, freq='D')

    df = pd.DataFrame({"date": dates})
    df["month"] = df["date"].dt.month
    df["day_of_week"] = df["date"].dt.dayofweek  # 0=Mon, 4=Fri, 5=Sat
    df["is_weekend"] = np.where(df["day_of_week"].isin([4, 5]), 1, 0)

    # 1. درجات الحرارة
    base_temps = np.array([EGYPT_MONTHLY_AVG_TEMPS[m] for m in df["month"].values])
    temp_noise = np.random.normal(0, 1.2, days)
    df["avg_temp"] = np.round(base_temps + temp_noise, 1)
    df["max_temp"] = np.round(df["avg_temp"] + 4.5, 1)
    df["min_temp"] = np.round(df["avg_temp"] - 4.5, 1)

    # 2. الاستهلاك الأساسي للشقة المصرية (متوسط 11 إلى 14 ك.و.س يومياً)
    base_kwh = 11.5
    weekend_factor = np.where(df["is_weekend"].values == 1, 1.22, 1.0)
    
    # 3. معامل الصيف (التكييف عند حرارة أعلى من 28 مئوية) والشتاء (سخان أقل من 16)
    temps = df["avg_temp"].values
    climate_factor = np.where(
        temps > 28.0,
        1.0 + 0.08 * (temps - 28.0),
        np.where(temps < 16.0, 1.12, 1.0)
    )

    noise = np.random.normal(0, 0.6, days)
    df["total_kwh"] = np.round((base_kwh * weekend_factor * climate_factor) + noise, 2)
    df["total_kwh"] = df["total_kwh"].clip(lower=4.0, upper=35.0)

    # 4. ميزات الـ Lag والـ Rolling
    df["lag_1_day_kwh"] = df["total_kwh"].shift(1).bfill()
    df["lag_2_day_kwh"] = df["total_kwh"].shift(2).bfill()
    df["rolling_7day_kwh"] = df["total_kwh"].rolling(7, min_periods=1).mean().round(2)
    df["is_synthetic"] = 1

    return df


def generate_hourly_synthetic_dataset(
    days: int = 30,
    random_state: int = 42
) -> pd.DataFrame:
    """
    توليد بيانات ساعية للشهر الأخير لأغراض المحاكاة ورسم المنحنيات اللحظية
    """
    np.random.seed(random_state)
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    hours_count = days * 24

    timestamps = pd.date_range(start=start_date, periods=hours_count, freq='h')
    df = pd.DataFrame({"timestamp": timestamps})

    df["hour"] = df["timestamp"].dt.hour
    df["day_of_week"] = df["timestamp"].dt.dayofweek
    df["is_weekend"] = np.where(df["day_of_week"].isin([4, 5]), 1, 0)
    df["month"] = df["timestamp"].dt.month

    # منحنى الحمل الساعي المتجهي
    h = df["hour"].values
    weights = np.where(
        h <= 6,
        0.35 + 0.1 * np.sin(h * np.pi / 6.0),
        np.where(
            h <= 12,
            0.65 + 0.15 * np.cos((h - 9.0) * np.pi / 6.0),
            np.where(
                h <= 17,
                0.85 + 0.15 * np.sin((h - 13.0) * np.pi / 4.0),
                1.25 + 0.35 * np.sin((h - 18.0) * np.pi / 5.0)
            )
        )
    )
    df["hourly_weight"] = weights

    base_temps = np.array([EGYPT_MONTHLY_AVG_TEMPS[m] for m in df["month"].values])
    diurnal = 4.0 * np.sin((h - 8.0) * np.pi / 12.0)
    df["temperature_c"] = np.round(base_temps + diurnal + np.random.normal(0, 0.8, hours_count), 1)

    weekend_factor = np.where(df["is_weekend"].values == 1, 1.20, 1.0)
    climate_load = np.where(
        df["temperature_c"].values > 28.0,
        0.7 + 0.1 * (df["temperature_c"].values - 28.0),
        0.2
    )

    noise = np.random.normal(0, 0.05, hours_count)
    df["energy_kwh"] = np.round(
        (0.45 * df["hourly_weight"].values * weekend_factor) + climate_load + noise,
        3
    ).clip(0.15, 4.5)

    return df


def aggregate_daily_dataset(hourly_df: pd.DataFrame) -> pd.DataFrame:
    """تجميع البيانات الساعية إلى يومية إن لزم"""
    hourly_df["date_only"] = hourly_df["timestamp"].dt.date
    daily = hourly_df.groupby("date_only").agg(
        total_kwh=("energy_kwh", "sum"),
        avg_temp=("temperature_c", "mean"),
        max_temp=("temperature_c", "max"),
        min_temp=("temperature_c", "min"),
        month=("month", "first"),
        day_of_week=("day_of_week", "first"),
        is_weekend=("is_weekend", "first")
    ).reset_index()

    daily.rename(columns={"date_only": "date"}, inplace=True)
    daily["lag_1_day_kwh"] = daily["total_kwh"].shift(1).bfill()
    daily["lag_2_day_kwh"] = daily["total_kwh"].shift(2).bfill()
    daily["rolling_7day_kwh"] = daily["total_kwh"].rolling(7, min_periods=1).mean().round(2)
    return daily


def blend_with_real_user_logs(user_id: int, base_daily_df: pd.DataFrame) -> Tuple[pd.DataFrame, bool]:
    """دمج قراءات المستخدم الحقيقية إن وجدت"""
    try:
        from backend.models import UsageLog
        logs = UsageLog.query.filter_by(user_id=user_id).order_by(UsageLog.timestamp.asc()).all()
        if len(logs) >= 14:
            user_data = [{"timestamp": l.timestamp, "energy_kwh": float(l.energy_kwh)} for l in logs]
            user_df = pd.DataFrame(user_data)
            user_df["date_only"] = user_df["timestamp"].dt.date
            user_daily = user_df.groupby("date_only").agg(total_kwh=("energy_kwh", "sum")).reset_index()
            user_daily.rename(columns={"date_only": "date"}, inplace=True)
            combined = pd.concat([base_daily_df.iloc[:-len(user_daily)], user_daily], ignore_index=True)
            return combined, True
    except Exception:
        pass
    return base_daily_df, False
