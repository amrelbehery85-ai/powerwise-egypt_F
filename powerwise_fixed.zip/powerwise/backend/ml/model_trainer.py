# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Machine Learning Model Trainer
تدريب نماذج التنبؤ بالاستهلاك وحساب نطاقات الثقة (Quantile Regression)
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

import os
import sys
from pathlib import Path

# ضمان تواجد مسار المشروع في sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
from typing import Dict, Any, Tuple
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from backend.ml.data_generator import (
    generate_daily_synthetic_dataset,
    generate_hourly_synthetic_dataset,
    aggregate_daily_dataset
)

MODELS_DIR = Path(__file__).resolve().parent / "saved_models"
FEATURE_COLUMNS = [
    "month",
    "day_of_week",
    "is_weekend",
    "avg_temp",
    "max_temp",
    "min_temp",
    "lag_1_day_kwh",
    "lag_2_day_kwh",
    "rolling_7day_kwh"
]

def train_and_save_energy_models(
    daily_df: pd.DataFrame = None,
    random_state: int = 42
) -> Dict[str, Any]:
    """
    تدريب وتقييم نماذج التنبؤ بالاستهلاك اليومي ونطاقات الثقة:
    1. RandomForestRegressor: للتنبؤ بالنقطة الأساسية وحساب مقاييس الدقة (MAE, RMSE, R²).
    2. HistGradientBoostingRegressor (Quantile Loss):
       - quantile=0.10 لحساب الحد الأدنى للثقة (10th percentile).
       - quantile=0.80 لحساب توصية الشحن بنسبة أمان 80% (80th percentile).
       - quantile=0.90 لحساب الحد الأقصى المتوقع (90th percentile).
    3. Cross-Validation بنظام 5-Fold.
    4. حفظ النماذج في مجلد saved_models.
    """
    if daily_df is None:
        daily_df = generate_daily_synthetic_dataset(days=365, random_state=random_state)

    X = daily_df[FEATURE_COLUMNS]
    y = daily_df["total_kwh"]

    # تقسيم البيانات (80% تدريب - 20% اختبار)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=random_state, shuffle=False
    )

    # 1. تدريب نموذج الغابات العشوائية الأساسي (Random Forest)
    rf_model = RandomForestRegressor(
        n_estimators=35,
        max_depth=8,
        min_samples_split=4,
        random_state=random_state,
        n_jobs=1
    )
    rf_model.fit(X_train, y_train)
    y_pred = rf_model.predict(X_test)

    # حساب مقاييس التقييم
    mae = float(mean_absolute_error(y_test, y_pred))
    mse = float(mean_squared_error(y_test, y_pred))
    rmse = float(np.sqrt(mse))
    r2 = float(r2_score(y_test, y_pred))

    # التحقق المتقاطع 5-Fold Cross Validation
    cv_scores = cross_val_score(rf_model, X, y, cv=5, scoring='r2', n_jobs=1)
    cv_mean = float(np.mean(cv_scores))
    cv_std = float(np.std(cv_scores))

    # 2. تدريب نماذج الانحدار الشريحي (Quantile Regression) لنطاقات الثقة
    # الحد الأدنى (10%)
    q10_model = HistGradientBoostingRegressor(
        loss='quantile', quantile=0.10, max_iter=35, random_state=random_state
    )
    q10_model.fit(X_train, y_train)

    # نسبة الأمان لتوصية الشحن (80%)
    q80_model = HistGradientBoostingRegressor(
        loss='quantile', quantile=0.80, max_iter=35, random_state=random_state
    )
    q80_model.fit(X_train, y_train)

    # الحد الأقصى (90%)
    q90_model = HistGradientBoostingRegressor(
        loss='quantile', quantile=0.90, max_iter=35, random_state=random_state
    )
    q90_model.fit(X_train, y_train)

    # 3. حفظ النماذج على القرص
    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(rf_model, MODELS_DIR / "rf_daily_model.pkl")
    joblib.dump(q10_model, MODELS_DIR / "q10_model.pkl")
    joblib.dump(q80_model, MODELS_DIR / "q80_model.pkl")
    joblib.dump(q90_model, MODELS_DIR / "q90_model.pkl")

    metrics = {
        "model_name": "RandomForestRegressor + Quantile HistGradientBoosting",
        "features": FEATURE_COLUMNS,
        "sample_count": len(daily_df),
        "mae": round(mae, 3),
        "rmse": round(rmse, 3),
        "r2": round(r2, 4),
        "cv_r2_mean": round(cv_mean, 4),
        "cv_r2_std": round(cv_std, 4),
        "status": "trained_successfully",
        "confidence_levels": ["10%", "50%", "80%", "90%"],
        "disclaimer": "ملاحظة: النماذج مدربة على بيانات تاريخية تجريبية واقعية تحاكي نمط المنازل المصرية."
    }

    joblib.dump(metrics, MODELS_DIR / "model_metrics.pkl")
    return metrics


def load_energy_models() -> Tuple[Any, Any, Any, Any, Dict[str, Any]]:
    """
    تحميل النماذج المحفوظة من القرص، وإن لم تكن مدربة يتم تدريبها تلقائياً
    """
    rf_path = MODELS_DIR / "rf_daily_model.pkl"
    q10_path = MODELS_DIR / "q10_model.pkl"
    q80_path = MODELS_DIR / "q80_model.pkl"
    q90_path = MODELS_DIR / "q90_model.pkl"
    metrics_path = MODELS_DIR / "model_metrics.pkl"

    if not all(p.exists() for p in [rf_path, q10_path, q80_path, q90_path, metrics_path]):
        train_and_save_energy_models()

    rf_model = joblib.load(rf_path)
    q10_model = joblib.load(q10_path)
    q80_model = joblib.load(q80_path)
    q90_model = joblib.load(q90_path)
    metrics = joblib.load(metrics_path)

    return rf_model, q10_model, q80_model, q90_model, metrics
