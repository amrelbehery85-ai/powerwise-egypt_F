import os
from pathlib import Path
from dotenv import load_dotenv

# تحديد المسار الأساسي للمشروع وتحميل ملف .env إن وجد
BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

def get_database_uri_and_options():
    custom_url = os.getenv("DATABASE_URL")
    if custom_url:
        if "sqlite" in custom_url:
            return custom_url, {}
        return custom_url, {
            "pool_recycle": 280,
            "pool_pre_ping": True,
            "connect_args": {"charset": "utf8mb4"}
        }

    db_user = os.getenv("DB_USER", "root")
    db_pass = os.getenv("DB_PASS", "")
    db_host = os.getenv("DB_HOST", "localhost")
    db_port = os.getenv("DB_PORT", "3306")
    db_name = os.getenv("DB_NAME", "powerwise_db")

    # فحص إمكانية الوصول إلى خادم MySQL
    import socket
    is_mysql_running = False
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.3)
        sock.connect((db_host, int(db_port)))
        sock.close()
        is_mysql_running = True
    except Exception:
        is_mysql_running = False

    if is_mysql_running:
        mysql_uri = f"mysql+pymysql://{db_user}:{db_pass}@{db_host}:{db_port}/{db_name}?charset=utf8mb4"
        engine_opts = {
            "pool_recycle": 280,
            "pool_pre_ping": True,
            "connect_args": {"charset": "utf8mb4"}
        }
        return mysql_uri, engine_opts
    else:
        # التحويل التلقائي الذكي لقاعدة SQLite محلية داخل مجلد database ليعمل المشروع فورياً
        sqlite_file = BASE_DIR / "database" / "powerwise.db"
        return f"sqlite:///{sqlite_file}", {}


class Config:
    """
    إعدادات مشروع PowerWise Egypt
    مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
    """

    # -------------------------------------------------------------
    # 1. إعدادات التعريف بالمشروع والمعهد (قابلة للتعديل بسهولة)
    # -------------------------------------------------------------
    INSTITUTE_NAME_AR = os.getenv("INSTITUTE_NAME_AR", "معهد طيبة العالي للتكنولوجيا والمعلومات")
    INSTITUTE_NAME_EN = os.getenv("INSTITUTE_NAME_EN", "Thebes Higher Institute for Technology and Information")
    DEPARTMENT_NAME_AR = os.getenv("DEPARTMENT_NAME_AR", "قسم علوم الحاسب ونظم المعلومات")
    DEPARTMENT_NAME_EN = os.getenv("DEPARTMENT_NAME_EN", "Computer Science & Information Systems Dept.")
    
    PROJECT_NAME_AR = os.getenv("PROJECT_NAME_AR", "PowerWise Egypt — مراقب ذكي لاستهلاك الكهرباء للعدادات مسبقة الدفع")
    PROJECT_NAME_EN = os.getenv("PROJECT_NAME_EN", "PowerWise Egypt — Smart Electricity Monitor for Prepaid Meters")
    ACADEMIC_YEAR = os.getenv("ACADEMIC_YEAR", "2024 / 2025")

    # أسماء فريق العمل والمشرف الأكاديمي
    SUPERVISOR_NAME_AR = os.getenv("SUPERVISOR_NAME_AR", "أ.د. / المشرف الأكاديمي")
    SUPERVISOR_NAME_EN = os.getenv("SUPERVISOR_NAME_EN", "Prof. / Academic Supervisor")
    STUDENT_NAMES_AR = [
        "عمرو ضياء الدين حسن",
        "طالب مساهم 1",
        "طالب مساهم 2",
        "طالب مساهم 3"
    ]

    # تنويهات هامة بشأن دقة الأسعار والتقديرات
    DATA_DISCLAIMER_AR = (
        "تنبيه: جميع البيانات، الحسابات، وتوقعات الشحن هي نتائج تقديرية لغرض التوجيه والتخطيط الذكي "
        "ولا تُعد بديلاً رسمياً عن الفاتورة أو شاشة العداد مسبق الدفع التابع للشركة القابضة لكهرباء مصر."
    )
    DATA_DISCLAIMER_EN = (
        "Notice: All calculations and predictions are smart estimates for planning and do not substitute "
        "official readings from prepaid meters or the Egyptian Electricity Holding Company (EEHC)."
    )
    TARIFF_OFFICIAL_NOTICE = (
        "تحقق من التعرفة الرسمية الحالية الصادرة عن جهاز تنظيم مرفق الكهرباء وحماية المستهلك (EgyptERA). "
        "يمكن لمسؤول النظام تحديث الأسعار والشرائح مباشرة من لوحة الإدارة."
    )

    # -------------------------------------------------------------
    # 2. إعدادات الأمان والتطبيق (Security & Flask)
    # -------------------------------------------------------------
    SECRET_KEY = os.getenv("SECRET_KEY", "powerwise-egypt-thebes-institute-secret-key-2025")
    DEBUG = os.getenv("FLASK_DEBUG", "True").lower() in ("true", "1", "yes")
    JSON_AS_ASCII = False  # لدعم إرجاع النصوص العربية في JSON بشكل سليم ومقروء
    JSON_SORT_KEYS = False

    # -------------------------------------------------------------
    # 3. إعدادات قاعدة البيانات (MySQL Database مع دعم التحويل التلقائي لـ SQLite)
    # -------------------------------------------------------------
    DB_USER = os.getenv("DB_USER", "root")
    DB_PASS = os.getenv("DB_PASS", "")  # كلمة مرور خادم MySQL على جهاز المستخدم
    DB_HOST = os.getenv("DB_HOST", "localhost")
    DB_PORT = os.getenv("DB_PORT", "3306")
    DB_NAME = os.getenv("DB_NAME", "powerwise_db")

    _default_uri, _default_opts = get_database_uri_and_options()
    SQLALCHEMY_DATABASE_URI = _default_uri
    SQLALCHEMY_ENGINE_OPTIONS = _default_opts
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # -------------------------------------------------------------
    # 4. إعدادات الذكاء الاصطناعي وتعلم الآلة (ML Config)
    # -------------------------------------------------------------
    ML_MODELS_DIR = BASE_DIR / "backend" / "ml" / "saved_models"
    ML_RANDOM_STATE = 42
    DEFAULT_CONFIDENCE_LEVEL = 0.80  # نطاق الثقة 80% لتوصية الشحن


class DevelopmentConfig(Config):
    DEBUG = True


class TestingConfig(Config):
    TESTING = True
    DEBUG = True
    # استخدام SQLite في الذاكرة لتشغيل اختبارات Unit Tests بسرعة دون الحاجة لخادم MySQL مباشر
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    SQLALCHEMY_ENGINE_OPTIONS = {}
    WTF_CSRF_ENABLED = False


class ProductionConfig(Config):
    DEBUG = False


config_by_name = {
    "development": DevelopmentConfig,
    "testing": TestingConfig,
    "production": ProductionConfig,
    "default": DevelopmentConfig
}
