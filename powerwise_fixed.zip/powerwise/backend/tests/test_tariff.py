# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Unit Tests for Tariff Calculations (pytest)
اختبارات دالة حساب التعرفة التراكمية والتعرفة العكسية مع أمثلة رقمية موثقة
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

import pytest
from backend.services.tariff_service import calculate_bill, calculate_inverse_tariff

class TestTariffCalculations:
    """
    مجموعة اختبارات دالة حساب الفاتورة وفق الشرائح المصرية
    """

    def test_tier_1_calculation(self):
        """
        مثال رقمي 1: استهلاك 40 كيلوواط ساعة (الشريحة الأولى: 0 إلى 50 ك.و.س)
        الحساب الرياضي المتوقع:
        - تكلفة الطاقة = 40 × 0.68 = 27.20 ج.م
        - مقابل خدمة العملاء = 1.00 ج.م
        - الإجمالي = 28.20 ج.م
        - متوسط السعر الفعلي = 28.20 ÷ 40 = 0.7050 ج.م/ك.و.س
        - السعر الحدي = 0.68 ج.م
        """
        kwh = 40.0
        result = calculate_bill(kwh)

        assert result["total_kwh"] == 40.0
        assert result["total_cost"] == 28.20
        assert result["energy_cost"] == 27.20
        assert result["service_fee"] == 1.00
        assert result["current_tier"] == 1
        assert result["marginal_price"] == 0.68
        assert result["effective_avg_price"] == pytest.approx(0.7050, 0.001)
        assert len(result["breakdown"]) == 1
        assert result["breakdown"][0]["tier"] == 1
        assert result["breakdown"][0]["tier_cost"] == 27.20

    def test_tier_2_calculation(self):
        """
        مثال رقمي 2: استهلاك 80 كيلوواط ساعة (الشريحة الثانية: 51 إلى 100 ك.و.س)
        الحساب الرياضي المتوقع:
        - أول 50 كيلو (شريحة 1) = 50 × 0.68 = 34.00 ج.م
        - الـ 30 كيلو الباقية (شريحة 2) = 30 × 0.78 = 23.40 ج.م
        - تكلفة الطاقة = 34.00 + 23.40 = 57.40 ج.م
        - مقابل خدمة العملاء = 2.00 ج.م
        - الإجمالي = 59.40 ج.م
        - السعر الحدي = 0.78 ج.م
        """
        kwh = 80.0
        result = calculate_bill(kwh)

        assert result["total_kwh"] == 80.0
        assert result["total_cost"] == 59.40
        assert result["energy_cost"] == 57.40
        assert result["service_fee"] == 2.00
        assert result["current_tier"] == 2
        assert result["marginal_price"] == 0.78
        assert len(result["breakdown"]) == 2
        assert result["breakdown"][0]["tier"] == 1
        assert result["breakdown"][0]["kwh_used"] == 50.0
        assert result["breakdown"][1]["tier"] == 2
        assert result["breakdown"][1]["kwh_used"] == 30.0

    def test_tier_3_subsidy_revocation_jump(self):
        """
        مثال رقمي 3: استهلاك 150 كيلوواط ساعة (تخطي حد 100 ك.و.س - إسقاط الدعم!)
        الحساب الرياضي المتوقع:
        بمجرد تخطي 100 كيلو، تلغى الشريحة الأولى والثانية، ويحسب كامل الاستهلاك
        من الصفر بسعر الشريحة الثالثة (0.95 ج.م):
        - تكلفة الطاقة = 150 × 0.95 = 142.50 ج.م
        - مقابل خدمة العملاء = 6.00 ج.م
        - الإجمالي = 148.50 ج.م
        - متوسط السعر الفعلي = 148.50 ÷ 150 = 0.9900 ج.م/ك.و.س
        - السعر الحدي = 0.95 ج.م
        """
        kwh = 150.0
        result = calculate_bill(kwh)

        assert result["total_kwh"] == 150.0
        assert result["total_cost"] == 148.50
        assert result["energy_cost"] == 142.50
        assert result["service_fee"] == 6.00
        assert result["current_tier"] == 3
        assert result["marginal_price"] == 0.95
        assert len(result["breakdown"]) == 1
        assert result["breakdown"][0]["tier"] == 3
        assert result["breakdown"][0]["kwh_used"] == 150.0

    def test_tier_4_calculation(self):
        """
        مثال رقمي 4: استهلاك 250 كيلوواط ساعة (الشريحة الرابعة: 201 إلى 350 ك.و.س)
        الحساب الرياضي المتوقع:
        - أول 200 كيلو (شريحة 3) = 200 × 0.95 = 190.00 ج.م
        - الـ 50 كيلو التالية (شريحة 4) = 50 × 1.55 = 77.50 ج.م
        - تكلفة الطاقة = 190.00 + 77.50 = 267.50 ج.م
        - مقابل خدمة العملاء = 11.00 ج.م
        - الإجمالي = 278.50 ج.م
        - السعر الحدي = 1.55 ج.م
        """
        kwh = 250.0
        result = calculate_bill(kwh)

        assert result["total_kwh"] == 250.0
        assert result["total_cost"] == 278.50
        assert result["energy_cost"] == 267.50
        assert result["service_fee"] == 11.00
        assert result["current_tier"] == 4
        assert result["marginal_price"] == 1.55
        assert len(result["breakdown"]) == 2
        assert result["breakdown"][0]["tier"] == 3
        assert result["breakdown"][0]["kwh_used"] == 200.0
        assert result["breakdown"][1]["tier"] == 4
        assert result["breakdown"][1]["kwh_used"] == 50.0

    def test_zero_consumption(self):
        """فحص حالة الصفر (لا استهلاك)"""
        result = calculate_bill(0.0)
        assert result["total_kwh"] == 0.0
        assert result["total_cost"] == 0.0
        assert result["energy_cost"] == 0.0

    def test_negative_consumption_raises_error(self):
        """فحص اعتراض المدخلات السالبة"""
        with pytest.raises(ValueError):
            calculate_bill(-15.0)


class TestInverseTariffCalculations:
    """
    مجموعة اختبارات دالة التعرفة العكسية (Inverse Tariff)
    بمعلومية المبلغ بالجنيه، إيجاد عدد الكيلوواط ساعة المقابلة
    """

    def test_inverse_tier_1_budget(self):
        """
        مثال عكسي 1: شحن 28.20 جنيه
        يجب أن يعطي بدقة 40.0 كيلوواط ساعة (مقابل مثال 1)
        """
        result = calculate_inverse_tariff(28.20)
        assert result["kwh_obtained"] == pytest.approx(40.0, 0.01)
        assert result["current_tier"] == 1
        assert result["service_fee_deducted"] == 1.00

    def test_inverse_tier_2_budget(self):
        """
        مثال عكسي 2: شحن 59.40 جنيه
        يجب أن يعطي بدقة 80.0 كيلوواط ساعة (مقابل مثال 2)
        """
        result = calculate_inverse_tariff(59.40)
        assert result["kwh_obtained"] == pytest.approx(80.0, 0.01)
        assert result["current_tier"] == 2
        assert result["service_fee_deducted"] == 2.00

    def test_inverse_tier_3_budget(self):
        """
        مثال عكسي 3: شحن 148.50 جنيه
        يجب أن يعطي بدقة 150.0 كيلوواط ساعة (مقابل مثال 3)
        """
        result = calculate_inverse_tariff(148.50)
        assert result["kwh_obtained"] == pytest.approx(150.0, 0.01)
        assert result["current_tier"] == 3
        assert result["service_fee_deducted"] == 6.00

    def test_inverse_gap_protection(self):
        """
        فحص منطقة الفجوة الانتقالية:
        بين 75 ج.م (نهاية الشريحة 2) و 101.01 ج.م (بداية الشريحة 3)،
        لا يمكن للرصيد أن يشتري أكثر من 100 ك.و.س تجنباً لانقطاع التيار
        """
        result = calculate_inverse_tariff(85.00)
        assert result["kwh_obtained"] == 100.0
        assert result["current_tier"] == 2
