# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Pytest Configuration & Test Fixtures
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

import sys
from pathlib import Path
import pytest

# ضمان تواجد مسار المشروع في sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from backend.app import create_app
from backend.models import db, User, Meter, DeviceType, Device, Tariff

@pytest.fixture(scope='session')
def app():
    """تهيئة تطبيق فلاسك في بيئة الاختبار المستقلة في الذاكرة (SQLite :memory:)"""
    app = create_app('testing')
    with app.app_context():
        db.create_all()

        # إدخال أنواع الأجهزة القياسية للاختبار
        sample_types = [
            DeviceType(id=1, name_ar="لمبة LED موفرة", name_en="LED Bulb", min_watts=5, max_watts=20, typical_watts=9, category="lighting", icon_svg_name="lightbulb", is_custom=False),
            DeviceType(id=9, name_ar="تكييف سبليت 1.5 حصان", name_en="AC 1.5HP", min_watts=1000, max_watts=2200, typical_watts=1400, category="cooling", icon_svg_name="ac", is_custom=False),
            DeviceType(id=20, name_ar="جهاز آخر", name_en="Custom Device", min_watts=1, max_watts=5000, typical_watts=100, category="other", icon_svg_name="custom", is_custom=True)
        ]
        db.session.bulk_save_objects(sample_types)

        # إدخال مستخدم وعداد تجريبي للاختبارات
        test_user = User(id=1, full_name="طالب معهد طيبة", email="student_test@thebes.edu.eg", role="user")
        test_user.set_password("TestPass@123")
        db.session.add(test_user)

        test_meter = Meter(id=1, user_id=1, meter_number="MTR-TEST-001", current_balance=200.00, tariff_category="residential")
        db.session.add(test_meter)

        db.session.commit()

        yield app

        db.session.remove()
        db.drop_all()


@pytest.fixture
def client(app):
    """عميل الاختبار لمحاكاة طلبات الـ HTTP"""
    return app.test_client()
