# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Unit Tests for ML & Recharge Recommendation (pytest)
اختبارات خوارزميات تعلم الآلة ونطاقات الثقة وتوصية الشحن "كام أشحن؟"
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

import pytest
from backend.models import db, Meter
from backend.ml.data_generator import (
    generate_daily_synthetic_dataset,
    generate_hourly_synthetic_dataset,
    aggregate_daily_dataset
)
from backend.ml.model_trainer import train_and_save_energy_models
from backend.services.prediction_service import (
    predict_daily_consumption,
    recommend_recharge
)

class TestMachineLearningAndPredictions:
    """اختبارات مولد البيانات ونماذج تعلم الآلة"""

    def test_synthetic_data_generation_structure(self):
        """فحص سلامة توليد بيانات 12 شهراً التجريبية وأعمدتها"""
        hourly_df = generate_hourly_synthetic_dataset(days=30, random_state=42)
        assert len(hourly_df) == 30 * 24  # 720 ساعة
        assert "energy_kwh" in hourly_df.columns
        assert "temperature_c" in hourly_df.columns
        assert "hourly_weight" in hourly_df.columns
        assert (hourly_df["energy_kwh"] >= 0.1).all()

        daily_df = aggregate_daily_dataset(hourly_df)
        assert len(daily_df) in [30, 31]
        assert "total_kwh" in daily_df.columns
        assert "rolling_7day_kwh" in daily_df.columns

        full_year_df = generate_daily_synthetic_dataset(days=365)
        assert len(full_year_df) == 365
        assert "total_kwh" in full_year_df.columns
        assert "lag_1_day_kwh" in full_year_df.columns

    def test_model_training_and_metrics(self):
        """تدريب النماذج والتحقق من حساب MAE, RMSE, R² و Cross Validation"""
        metrics = train_and_save_energy_models(random_state=42)
        assert metrics["status"] == "trained_successfully"
        assert metrics["mae"] > 0
        assert metrics["rmse"] > 0
        assert "r2" in metrics
        assert "cv_r2_mean" in metrics
        assert metrics["sample_count"] >= 365

    def test_prediction_confidence_bounds(self, app):
        """
        التحقق من صحة الترتيب المنطقي لنطاقات الثقة:
        الحد الأدنى (10%) <= التوقع الأساسي <= الحد الأقصى (90%)
        """
        with app.app_context():
            res = predict_daily_consumption(user_id=1, period_days=7)
            assert res["period_days"] == 7
            assert len(res["daily_forecasts"]) == 7
            assert res["lower_bound_kwh"] <= res["total_predicted_kwh"]
            assert res["total_predicted_kwh"] <= res["upper_bound_kwh"]
            assert res["lower_cost_egp"] <= res["total_cost_egp"]
            assert res["total_cost_egp"] <= res["upper_cost_egp"]


class TestRechargeRecommendation:
    """
    اختبارات دالة توصية الشحن "كام أشحن؟" مع مثال رقمي محسوب وموثق
    """

    def test_recharge_recommendation_when_balance_insufficient(self, app):
        """
        مثال رقمي موثق 1: الرصيد غير كافٍ وتوصية بالشحن
        - رصيد العداد الحالي = 10.00 ج.م
        - الفترة المستهدفة = 7 أيام
        - الحساب المتوقع:
          إذا كانت تكلفة الـ 7 أيام بنسبة أمان 80% هي Cost_80
          فإن المبلغ المقترح = Cost_80 - 10.00 ج.م
          والحد الأدنى المقترح = Max(0, Cost_10 - 10.00)
          والحد الأقصى المقترح = Max(0, Cost_90 - 10.00)
        """
        with app.app_context():
            meter = db.session.get(Meter, 1)
            meter.current_balance = 10.00
            db.session.commit()

            rec = recommend_recharge(user_id=1, period_days=7, confidence=0.80)

            assert rec["period_days"] == 7
            assert rec["current_balance_egp"] == 10.00
            assert rec["recharge_status"] == "recharge_needed"
            assert rec["recommended_recharge_egp"] > 0

            # التحقق من أن المبلغ المقترح يقع بين الحدين الأدنى والأقصى
            assert rec["min_recharge_egp"] <= rec["recommended_recharge_egp"]
            assert rec["recommended_recharge_egp"] <= rec["max_recharge_egp"]
            assert rec["days_remaining_estimate"] >= 0

    def test_recharge_recommendation_when_balance_sufficient(self, app):
        """
        مثال رقمي موثق 2: الرصيد كافٍ جداً
        - رصيد العداد الحالي = 1000.00 ج.م
        - الفترة المستهدفة = 3 أيام
        - الحساب المتوقع:
          بما أن الرصيد الحالي 1000 ج.م يغطي تكلفة 3 أيام بالكامل،
          فإن المبلغ المقترح = 0.00 ج.م والحالة = sufficient
        """
        with app.app_context():
            meter = db.session.get(Meter, 1)
            meter.current_balance = 1000.00
            db.session.commit()

            rec = recommend_recharge(user_id=1, period_days=3, confidence=0.80)

            assert rec["current_balance_egp"] == 1000.00
            assert rec["recommended_recharge_egp"] == 0.0
            assert rec["min_recharge_egp"] == 0.0
            assert rec["recharge_status"] == "sufficient"
            assert rec["days_remaining_estimate"] > 30.0  # الرصيد يكفي لأكثر من شهر
