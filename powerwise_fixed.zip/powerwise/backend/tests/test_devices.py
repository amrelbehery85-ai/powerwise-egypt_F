# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Unit Tests for Devices & Load Calculation (pytest)
اختبارات صحة إدارة الأجهزة والتحقق من القدرة والأحمال اللحظية
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

import pytest
from backend.services.device_service import (
    add_user_device,
    update_user_device,
    toggle_device_state,
    calculate_live_power_summary
)

class TestDeviceManagement:
    """اختبارات إدارة الأجهزة والتحقق من قدرة الوات"""

    def test_add_standard_device_valid_watts(self, app):
        """إضافة لمبة LED بقدرة 9 وات (ضمن النطاق المسموح 5 - 20 وات)"""
        with app.app_context():
            payload = {
                "device_type_id": 1,
                "custom_name": "إضاءة غرفة المكتب LED",
                "rated_watts": 9,
                "count": 3,
                "daily_hours": 5.0,
                "is_active": True
            }
            device = add_user_device(user_id=1, data=payload)
            assert device["custom_name"] == "إضاءة غرفة المكتب LED"
            assert device["rated_watts"] == 9
            assert device["total_watts"] == 27  # 9 * 3
            # الاستهلاك اليومي = (27 * 5) / 1000 = 0.135 ك.و.س
            assert device["daily_kwh"] == 0.135

    def test_add_standard_device_invalid_watts_rejected(self, app):
        """إضافة لمبة LED بقدرة 100 وات (خارج النطاق 5-20) يجب أن تُرفض بخطأ واضح"""
        with app.app_context():
            payload = {
                "device_type_id": 1,
                "custom_name": "لمبة شاذة",
                "rated_watts": 100,
                "count": 1,
                "daily_hours": 2.0
            }
            with pytest.raises(ValueError) as excinfo:
                add_user_device(user_id=1, data=payload)
            assert "يجب أن تلتزم بالنطاق المسموح به" in str(excinfo.value)

    def test_add_custom_device_within_range(self, app):
        """إضافة جهاز مخصص بقدرة 3200 وات (ضمن نطاق 1 - 5000 وات)"""
        with app.app_context():
            payload = {
                "device_type_id": 20,
                "custom_name": "ماكينة لحام ورشة",
                "rated_watts": 3200,
                "count": 1,
                "daily_hours": 2.0,
                "is_active": True
            }
            dev = add_user_device(user_id=1, data=payload)
            assert dev["rated_watts"] == 3200
            assert dev["is_active"] is True

    def test_add_custom_device_exceeding_max_rejected(self, app):
        """إضافة جهاز مخصص بقدرة 7000 وات (أكبر من 5000 وات) يجب أن تُرفض"""
        with app.app_context():
            payload = {
                "device_type_id": 20,
                "custom_name": "محرك صناعي ضخم",
                "rated_watts": 7000,
                "count": 1,
                "daily_hours": 1.0
            }
            with pytest.raises(ValueError) as excinfo:
                add_user_device(user_id=1, data=payload)
            assert "قدرة الجهاز المخصص يجب أن تكون بين 1 و 5000 وات" in str(excinfo.value)

    def test_toggle_device_and_live_summary(self, app):
        """اختبار زر تشغيل/إيقاف الجهاز وتأثيره على مجموع الأحمال اللحظية"""
        with app.app_context():
            # إضافة تكييف
            ac_payload = {
                "device_type_id": 9,
                "custom_name": "تكييف غرفة النوم",
                "rated_watts": 1400,
                "count": 1,
                "daily_hours": 8.0,
                "is_active": True
            }
            ac = add_user_device(user_id=1, data=ac_payload)
            ac_id = ac["id"]

            summary_before = calculate_live_power_summary(user_id=1)
            watts_before = summary_before["total_active_watts"]
            assert watts_before >= 1400

            # إطفاء التكييف
            toggled = toggle_device_state(user_id=1, device_id=ac_id)
            assert toggled["is_active"] is False

            # فحص انخفاض الحمل بعد إطفائه
            summary_after = calculate_live_power_summary(user_id=1)
            assert summary_after["total_active_watts"] == watts_before - 1400
