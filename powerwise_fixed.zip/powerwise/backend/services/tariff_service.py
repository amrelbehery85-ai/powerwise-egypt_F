# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Tariff Service
خدمة حسابات شرائح الكهرباء المصرية والتعرفة العكسية
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

from typing import Dict, Any, List
from decimal import Decimal, ROUND_HALF_UP

# الأسعار التقديرية الرسمية المعتمدة لعام 2024/2025 (قابلة للتعديل من قاعدة البيانات)
DEFAULT_RESIDENTIAL_TARIFFS = [
    {"tier": 1, "name_ar": "الشريحة 1 (0 - 50 ك.و.س)", "min": 0.0, "max": 50.0, "price": 0.68, "fee": 1.00, "group": 1},
    {"tier": 2, "name_ar": "الشريحة 2 (51 - 100 ك.و.س)", "min": 51.0, "max": 100.0, "price": 0.78, "fee": 2.00, "group": 1},
    {"tier": 3, "name_ar": "الشريحة 3 (0 - 200 ك.و.س بديل)", "min": 0.0, "max": 200.0, "price": 0.95, "fee": 6.00, "group": 2},
    {"tier": 4, "name_ar": "الشريحة 4 (201 - 350 ك.و.س)", "min": 201.0, "max": 350.0, "price": 1.55, "fee": 11.00, "group": 2},
    {"tier": 5, "name_ar": "الشريحة 5 (351 - 650 ك.و.س)", "min": 351.0, "max": 650.0, "price": 1.95, "fee": 15.00, "group": 2},
    {"tier": 6, "name_ar": "الشريحة 6 (0 - 1000 ك.و.س)", "min": 0.0, "max": 1000.0, "price": 2.10, "fee": 25.00, "group": 3},
    {"tier": 7, "name_ar": "الشريحة 7 (أكثر من 1000 ك.و.س)", "min": 1001.0, "max": 999999.0, "price": 2.23, "fee": 40.00, "group": 4},
]

def get_active_tariffs_data() -> List[Dict[str, Any]]:
    """
    استرجاع بيانات الشرائح النشطة من قاعدة البيانات مع وجود بديل احتياطي فوري
    """
    try:
        from backend.models import Tariff
        records = Tariff.query.filter_by(is_active=True).order_by(Tariff.tier_number.asc()).all()
        if records and len(records) >= 7:
            return [
                {
                    "tier": r.tier_number,
                    "name_ar": r.tier_name_ar,
                    "min": float(r.min_kwh),
                    "max": float(r.max_kwh),
                    "price": float(r.price_per_kwh),
                    "fee": float(r.service_fee),
                    "group": r.bracket_group
                }
                for r in records
            ]
    except Exception:
        pass
    return DEFAULT_RESIDENTIAL_TARIFFS


def calculate_bill(kwh_month: float) -> Dict[str, Any]:
    """
    حساب التكلفة التراكمية الشهرية حسب الشرائح المصرية (Piecewise Cumulative Pricing)
    
    المخرجات:
    - total_cost: التكلفة الكلية بالجنيه متضمنة خدمة العملاء
    - energy_cost: تكلفة استهلاك الطاقة فقط
    - service_fee: مقابل خدمة العملاء
    - effective_avg_price: متوسط سعر الكيلوواط الفعلي = التكلفة الكلية ÷ إجمالي الكيلوواط
    - marginal_price: السعر الحدي للكيلوواط القادم في الشريحة الحالية
    - current_tier: رقم الشريحة الحالية (1 إلى 7)
    - breakdown: تفصيل الاستهلاك والتكلفة لكل شريحة
    """
    if kwh_month < 0:
        raise ValueError("كمية الاستهلاك لا يمكن أن تكون سالبة.")

    if kwh_month == 0:
        return {
            "total_kwh": 0.0,
            "total_cost": 0.0,
            "energy_cost": 0.0,
            "service_fee": 0.0,
            "effective_avg_price": 0.0,
            "marginal_price": 0.68,
            "current_tier": 1,
            "tier_name_ar": "الشريحة الأولى (من 0 إلى 50 ك.و.س)",
            "breakdown": [],
            "notice": "الاستهلاك صفر. تحقق من التعرفة الرسمية الحالية (جهاز تنظيم مرفق الكهرباء)."
        }

    kwh = float(kwh_month)
    tariffs = get_active_tariffs_data()
    t_map = {t["tier"]: t for t in tariffs}

    breakdown: List[Dict[str, Any]] = []
    energy_cost = 0.0
    service_fee = 0.0
    marginal_price = 0.0
    current_tier = 1
    tier_name_ar = ""

    # =========================================================================
    # الحالة 1: الاستهلاك من 0 إلى 100 ك.و.س (نطاق الشريحتين 1 و 2)
    # =========================================================================
    if kwh <= 100.0:
        if kwh <= 50.0:
            current_tier = 1
            tier_name_ar = t_map[1]["name_ar"]
            cost_tier_1 = kwh * t_map[1]["price"]
            breakdown.append({
                "tier": 1,
                "name_ar": t_map[1]["name_ar"],
                "kwh_used": round(kwh, 2),
                "price_per_kwh": t_map[1]["price"],
                "tier_cost": round(cost_tier_1, 2)
            })
            energy_cost = cost_tier_1
            service_fee = t_map[1]["fee"]
            marginal_price = t_map[1]["price"]
        else:
            current_tier = 2
            tier_name_ar = t_map[2]["name_ar"]
            cost_tier_1 = 50.0 * t_map[1]["price"]
            rem_kwh = kwh - 50.0
            cost_tier_2 = rem_kwh * t_map[2]["price"]

            breakdown.append({
                "tier": 1,
                "name_ar": t_map[1]["name_ar"],
                "kwh_used": 50.0,
                "price_per_kwh": t_map[1]["price"],
                "tier_cost": round(cost_tier_1, 2)
            })
            breakdown.append({
                "tier": 2,
                "name_ar": t_map[2]["name_ar"],
                "kwh_used": round(rem_kwh, 2),
                "price_per_kwh": t_map[2]["price"],
                "tier_cost": round(cost_tier_2, 2)
            })
            energy_cost = cost_tier_1 + cost_tier_2
            service_fee = t_map[2]["fee"]
            marginal_price = t_map[2]["price"]

    # =========================================================================
    # الحالة 2: الاستهلاك من 101 إلى 650 ك.و.س (إلغاء الأولى والثانية والبدء من 3)
    # =========================================================================
    elif kwh <= 650.0:
        if kwh <= 200.0:
            current_tier = 3
            tier_name_ar = t_map[3]["name_ar"]
            cost_tier_3 = kwh * t_map[3]["price"]
            breakdown.append({
                "tier": 3,
                "name_ar": t_map[3]["name_ar"],
                "kwh_used": round(kwh, 2),
                "price_per_kwh": t_map[3]["price"],
                "tier_cost": round(cost_tier_3, 2)
            })
            energy_cost = cost_tier_3
            service_fee = t_map[3]["fee"]
            marginal_price = t_map[3]["price"]
        elif kwh <= 350.0:
            current_tier = 4
            tier_name_ar = t_map[4]["name_ar"]
            cost_tier_3 = 200.0 * t_map[3]["price"]
            rem_kwh = kwh - 200.0
            cost_tier_4 = rem_kwh * t_map[4]["price"]

            breakdown.append({
                "tier": 3,
                "name_ar": t_map[3]["name_ar"],
                "kwh_used": 200.0,
                "price_per_kwh": t_map[3]["price"],
                "tier_cost": round(cost_tier_3, 2)
            })
            breakdown.append({
                "tier": 4,
                "name_ar": t_map[4]["name_ar"],
                "kwh_used": round(rem_kwh, 2),
                "price_per_kwh": t_map[4]["price"],
                "tier_cost": round(cost_tier_4, 2)
            })
            energy_cost = cost_tier_3 + cost_tier_4
            service_fee = t_map[4]["fee"]
            marginal_price = t_map[4]["price"]
        else:
            current_tier = 5
            tier_name_ar = t_map[5]["name_ar"]
            cost_tier_3 = 200.0 * t_map[3]["price"]
            cost_tier_4 = 150.0 * t_map[4]["price"]
            rem_kwh = kwh - 350.0
            cost_tier_5 = rem_kwh * t_map[5]["price"]

            breakdown.append({
                "tier": 3,
                "name_ar": t_map[3]["name_ar"],
                "kwh_used": 200.0,
                "price_per_kwh": t_map[3]["price"],
                "tier_cost": round(cost_tier_3, 2)
            })
            breakdown.append({
                "tier": 4,
                "name_ar": t_map[4]["name_ar"],
                "kwh_used": 150.0,
                "price_per_kwh": t_map[4]["price"],
                "tier_cost": round(cost_tier_4, 2)
            })
            breakdown.append({
                "tier": 5,
                "name_ar": t_map[5]["name_ar"],
                "kwh_used": round(rem_kwh, 2),
                "price_per_kwh": t_map[5]["price"],
                "tier_cost": round(cost_tier_5, 2)
            })
            energy_cost = cost_tier_3 + cost_tier_4 + cost_tier_5
            service_fee = t_map[5]["fee"]
            marginal_price = t_map[5]["price"]

    # =========================================================================
    # الحالة 3: الاستهلاك من 651 إلى 1000 ك.و.س (إلغاء الدعم السابق وحساب كامل بـ الشريحة 6)
    # =========================================================================
    elif kwh <= 1000.0:
        current_tier = 6
        tier_name_ar = t_map[6]["name_ar"]
        energy_cost = kwh * t_map[6]["price"]
        service_fee = t_map[6]["fee"]
        marginal_price = t_map[6]["price"]
        breakdown.append({
            "tier": 6,
            "name_ar": t_map[6]["name_ar"],
            "kwh_used": round(kwh, 2),
            "price_per_kwh": t_map[6]["price"],
            "tier_cost": round(energy_cost, 2)
        })

    # =========================================================================
    # الحالة 4: الاستهلاك أكثر من 1000 ك.و.س (الشريحة السابعة للأحمال المرتفعة)
    # =========================================================================
    else:
        current_tier = 7
        tier_name_ar = t_map[7]["name_ar"]
        energy_cost = kwh * t_map[7]["price"]
        service_fee = t_map[7]["fee"]
        marginal_price = t_map[7]["price"]
        breakdown.append({
            "tier": 7,
            "name_ar": t_map[7]["name_ar"],
            "kwh_used": round(kwh, 2),
            "price_per_kwh": t_map[7]["price"],
            "tier_cost": round(energy_cost, 2)
        })

    total_cost = energy_cost + service_fee
    effective_avg_price = (total_cost / kwh) if kwh > 0 else 0.0

    return {
        "total_kwh": round(kwh, 2),
        "total_cost": round(total_cost, 2),
        "energy_cost": round(energy_cost, 2),
        "service_fee": round(service_fee, 2),
        "effective_avg_price": round(effective_avg_price, 4),
        "marginal_price": round(marginal_price, 4),
        "current_tier": current_tier,
        "tier_name_ar": tier_name_ar,
        "breakdown": breakdown,
        "notice": "تحقق من التعرفة الرسمية الحالية (جهاز تنظيم مرفق الكهرباء - الأسعار تقديرية)."
    }


def calculate_inverse_tariff(budget_egp: float) -> Dict[str, Any]:
    """
    التعرفة العكسية (Inverse Tariff): بمعلومية مبلغ الشحن بالجنيه المصري،
    كم كيلوواط ساعة يحصل عليها المستخدم؟ مع مراعاة قفزات الشرائح وخصم خدمة العملاء.
    """
    if budget_egp < 0:
        raise ValueError("المبلغ المالي لا يمكن أن يكون سالباً.")

    if budget_egp == 0:
        return {
            "budget_egp": 0.0,
            "kwh_obtained": 0.0,
            "current_tier": 1,
            "tier_name_ar": "الشريحة الأولى",
            "effective_rate": 0.0,
            "service_fee_deducted": 0.0,
            "breakdown": [],
            "notice": "المبلغ صفر. تحقق من التعرفة الرسمية الحالية."
        }

    tariffs = get_active_tariffs_data()
    t_map = {t["tier"]: t for t in tariffs}

    # النقاط الحرجة للتكلفة عند حدود الشرائح:
    # 1. حد 50 ك.و.س: (50 * 0.68) + 1.00 = 35.00 ج.م
    cost_at_50 = (50.0 * t_map[1]["price"]) + t_map[1]["fee"]

    # 2. حد 100 ك.و.س: (50 * 0.68) + (50 * 0.78) + 2.00 = 34 + 39 + 2 = 75.00 ج.م
    cost_at_100 = (50.0 * t_map[1]["price"]) + (50.0 * t_map[2]["price"]) + t_map[2]["fee"]

    # 3. قفزة الشريحة الثالثة عند 100.01 ك.و.س:
    # 100.01 * 0.95 + 6.00 = 101.01 ج.م
    cost_at_100_tier3_entry = (100.0 * t_map[3]["price"]) + t_map[3]["fee"]

    # 4. حد 200 ك.و.س: 200 * 0.95 + 6.00 = 196.00 ج.م
    cost_at_200 = (200.0 * t_map[3]["price"]) + t_map[3]["fee"]

    # 5. حد 350 ك.و.س: (200 * 0.95) + (150 * 1.55) + 11.00 = 190 + 232.50 + 11.00 = 433.50 ج.م
    cost_at_350 = (200.0 * t_map[3]["price"]) + (150.0 * t_map[4]["price"]) + t_map[4]["fee"]

    # 6. حد 650 ك.و.س: 190 + 232.50 + (300 * 1.95) + 15.00 = 1022.50 ج.م
    cost_at_650 = (200.0 * t_map[3]["price"]) + (150.0 * t_map[4]["price"]) + (300.0 * t_map[5]["price"]) + t_map[5]["fee"]

    # 7. قفزة الشريحة السادسة عند 650 ك.و.س:
    # 650 * 2.10 + 25.00 = 1390.00 ج.م
    cost_at_650_tier6_entry = (650.0 * t_map[6]["price"]) + t_map[6]["fee"]

    # 8. حد 1000 ك.و.س: 1000 * 2.10 + 25.00 = 2125.00 ج.م
    cost_at_1000 = (1000.0 * t_map[6]["price"]) + t_map[6]["fee"]

    b = float(budget_egp)
    kwh = 0.0
    tier = 1
    fee = 0.0

    # النطاق 1: أقل من أو يساوي حد الشريحة الأولى (35 جنيه)
    if b <= cost_at_50:
        tier = 1
        fee = t_map[1]["fee"]
        net_budget = max(0.0, b - fee)
        kwh = net_budget / t_map[1]["price"]

    # النطاق 2: من 35 جنيه وحتى 75 جنيه (الشريحة الثانية)
    elif b <= cost_at_100:
        tier = 2
        fee = t_map[2]["fee"]
        cost_p1 = 50.0 * t_map[1]["price"]
        rem_money = b - fee - cost_p1
        kwh = 50.0 + (rem_money / t_map[2]["price"])

    # النطاق الانتقالي الخاص: بين 75 ج.م و 101 ج.م
    # المستخدم لا يستطيع تجاوز 100 ك.و.س لأن الانتقال يلغي الدعم ويرفع التكلفة لـ 101 ج.م
    elif b < cost_at_100_tier3_entry:
        tier = 2
        fee = t_map[2]["fee"]
        kwh = 100.0  # يصل بالضبط إلى نهاية الشريحة الثانية ويبقى الفائض في رصيده

    # النطاق 3: من 101 جنيه وحتى 196 جنيه (الشريحة الثالثة)
    elif b <= cost_at_200:
        tier = 3
        fee = t_map[3]["fee"]
        net_budget = b - fee
        kwh = net_budget / t_map[3]["price"]

    # النطاق 4: من 196 جنيه وحتى 433.5 جنيه (الشريحة الرابعة)
    elif b <= cost_at_350:
        tier = 4
        fee = t_map[4]["fee"]
        cost_t3 = 200.0 * t_map[3]["price"]
        rem_money = b - fee - cost_t3
        kwh = 200.0 + (rem_money / t_map[4]["price"])

    # النطاق 5: من 433.5 جنيه وحتى 1022.5 جنيه (الشريحة الخامسة)
    elif b <= cost_at_650:
        tier = 5
        fee = t_map[5]["fee"]
        cost_t3 = 200.0 * t_map[3]["price"]
        cost_t4 = 150.0 * t_map[4]["price"]
        rem_money = b - fee - cost_t3 - cost_t4
        kwh = 350.0 + (rem_money / t_map[5]["price"])

    # النطاق الانتقالي الثاني: بين 1022.5 ج.م و 1390 ج.م
    elif b < cost_at_650_tier6_entry:
        tier = 5
        fee = t_map[5]["fee"]
        kwh = 650.0

    # النطاق 6: من 1390 ج.م وحتى 2125 ج.م (الشريحة السادسة)
    elif b <= cost_at_1000:
        tier = 6
        fee = t_map[6]["fee"]
        net_budget = b - fee
        kwh = net_budget / t_map[6]["price"]

    # النطاق 7: أكثر من 2125 ج.م (الشريحة السابعة)
    else:
        tier = 7
        fee = t_map[7]["fee"]
        net_budget = b - fee
        kwh = net_budget / t_map[7]["price"]

    bill_verification = calculate_bill(kwh)

    return {
        "budget_egp": round(b, 2),
        "kwh_obtained": round(kwh, 2),
        "current_tier": tier,
        "tier_name_ar": t_map[tier]["name_ar"],
        "effective_rate": round(b / kwh, 4) if kwh > 0 else 0.0,
        "service_fee_deducted": fee,
        "breakdown": bill_verification["breakdown"],
        "notice": "تحقق من التعرفة الرسمية الحالية (جهاز تنظيم مرفق الكهرباء - النتائج تقديرية)."
    }
