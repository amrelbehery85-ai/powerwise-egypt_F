# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Smart Local Chatbot Service
المساعد الذكي المحلي لمعالجة استفسارات الكهرباء باللغة العربية (NLP & TF-IDF)
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

import re
from typing import Dict, Any, List, Optional, Tuple
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from backend.models import db, FAQ, ChatLog, Meter, Device
from backend.services.tariff_service import calculate_bill

def normalize_arabic_text(text: str) -> str:
    """
    تطبيع وتنظيف النص العربي:
    - إزالة التشكيل والحركات
    - توحيد صور الألف (أ، إ، آ -> ا)
    - توحيد الياء والياء المقصورة (ى -> ي)
    - توحيد التاء المربوطة والهاء (ة -> ه)
    - إزالة علامات الترقيم والرموز غير النصية
    """
    if not text:
        return ""
    text = str(text)

    # 1. إزالة التشكيل والمد
    text = re.sub(r'[\u064B-\u065F\u0670]', '', text)
    text = re.sub(r'ـ+', '', text)

    # 2. توحيد الحروف
    text = re.sub(r'[أإآ]', 'ا', text)
    text = re.sub(r'ى', 'ي', text)
    text = re.sub(r'ة', 'ه', text)
    text = re.sub(r'[گك]', 'ك', text)

    # 3. إزالة علامات الاستفهام والترقيم والمسافات الزائدة
    text = re.sub(r'[^\w\s]', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip().lower()

    return text


def build_faq_corpus() -> Tuple[List[Dict[str, Any]], TfidfVectorizer, Any]:
    """
    بناء مصفوفة TF-IDF لقاعدة المعرفة الـ 42 المسجلة في قاعدة البيانات
    """
    try:
        faq_records = FAQ.query.order_by(FAQ.id.asc()).all()
        faq_list = [f.to_dict() for f in faq_records]
    except Exception:
        faq_list = []

    if not faq_list:
        # بيانات احتياطية فورية في حال عدم توفر اتصال لحظي
        faq_list = [
            {"id": 1, "question_ar": "كيف تحسب شرائح الكهرباء في مصر؟", "keywords": "شرائح, تعرفة, حساب, فاتورة", "answer_ar": "تنقسم الشرائح السكنية في مصر إلى 7 شرائح تصاعدية تبدأ من 68 قرشاً للشريحة الأولى وحتى 2.23 جنيه للشريحة السابعة."},
            {"id": 2, "question_ar": "كم رصيدي المتبقي في العداد؟", "keywords": "رصيد, كارت, كم باقي, استعلام", "answer_ar": "يمكنك التحقق من رصيدك في لوحة التحكم العلوية."},
            {"id": 3, "question_ar": "ما هو أكثر جهاز يستهلك كهرباء في بيتي؟", "keywords": "اكتر جهاز, اعلى جهاز, تكييف, سخان", "answer_ar": "التكييفات وسخانات المياه هي أكثر الأجهزة استهلاكاً للطاقة."}
        ]

    # تجهيز النصوص الموحدة للتدريب
    corpus_texts = []
    for item in faq_list:
        combined = f"{item['question_ar']} {item.get('keywords', '')} {item.get('answer_ar', '')}"
        corpus_texts.append(normalize_arabic_text(combined))

    vectorizer = TfidfVectorizer(
        ngram_range=(1, 2),
        min_df=1,
        sublinear_tf=True
    )
    tfidf_matrix = vectorizer.fit_transform(corpus_texts)

    return faq_list, vectorizer, tfidf_matrix


def check_dynamic_user_queries(user_id: int, normalized_msg: str) -> Optional[str]:
    """
    فحص الأسئلة الحية التي تتطلب استرجاع أرقام فعلية من قاعدة بيانات المستخدم:
    - السؤال عن رصيد العداد الحالي
    - السؤال عن أعلى جهاز استهلاكاً لدى المستخدم
    - السؤال عن مجموع القدرة المشغلة حالياً
    """
    # 1. الاستفسار عن رصيد العداد الحالي
    if any(k in normalized_msg for k in ["رصيد", "رصيدي", "كام رصيد", "فلوسي", "باقي كام"]):
        meter = Meter.query.filter_by(user_id=user_id).first()
        if meter:
            balance = float(meter.current_balance)
            return (
                f"رصيدك المالي الحالي في العداد (كود: {meter.meter_number}) هو "
                f"**{balance:.2f} جنيه مصري**. يمكنك الانتقال لشاشة 'التوقع والشحن' "
                f"لحساب كم يوماً سيكفيك الرصيد بدقة."
            )

    # 2. الاستفسار عن أعلى جهاز استهلاكاً لدى المستخدم
    if any(k in normalized_msg for k in ["اعلي جهاز", "اكتر جهاز", "اكثر جهاز", "بيسحب كتير", "بيسحب اكتر"]):
        devices = Device.query.filter_by(user_id=user_id).all()
        if devices:
            # ترتيب الأجهزة حسب الاستهلاك اليومي
            sorted_devs = sorted(
                devices,
                key=lambda d: (int(d.rated_watts) * int(d.count) * float(d.daily_hours)),
                reverse=True
            )
            top = sorted_devs[0]
            top_watts = int(top.rated_watts) * int(top.count)
            top_kwh = (top_watts * float(top.daily_hours)) / 1000.0
            return (
                f"بناءً على قائمة أجهزتك المسجلة، أعلى جهاز استهلاكاً عندك هو: "
                f"**{top.custom_name}** بقدرة إجمالية **{top_watts} وات**، "
                f"ويستهلك حوالي **{top_kwh:.2f} ك.و.س يومياً** "
                f"(حوالي {top_kwh * 30:.1f} ك.و.س شهرياً). "
                f"ننصح بضبط تشغيله لتقليل الشريحة."
            )

    # 3. الاستفسار عن إجمالي الأجهزة المشغلة لحظياً
    if any(k in normalized_msg for k in ["شغال دلوقتي", "مشغل كام", "الحمل اللحظي", "الوات الحالي"]):
        active_devs = Device.query.filter_by(user_id=user_id, is_active=True).all()
        total_w = sum(int(d.rated_watts) * int(d.count) for d in active_devs)
        return (
            f"لديك حالياً **{len(active_devs)} أجهزة مشغلة (ON)**، "
            f"بإجمالي قدرة لحظية تسحب **{total_w} وات** "
            f"({total_w / 1000:.3f} ك.و.س في الساعة)."
        )

    return None


def process_chatbot_message(user_message: str, user_id: int = 2) -> Dict[str, Any]:
    """
    معالجة رسالة المستخدم وإرجاع الرد الذكي:
    1. التطبيع النصي للعربية
    2. فحص الأسئلة الحية من قاعدة بيانات المستخدم (رصيد، أجهزة)
    3. المطابقة بمصفوفة TF-IDF والـ Cosine Similarity
    4. اقتراح الأسئلة البديلة إذا انخفضت نسبة الثقة عن 0.20
    5. حفظ المحادثة في جدول chat_logs
    """
    clean_msg = normalize_arabic_text(user_message)
    if not clean_msg:
        return {
            "reply": "أهلاً بك! أنا مساعد PowerWise الذكي. كيف يمكنني مساعدتك في حساب فاتورتك أو ترشيد الكهرباء اليوم؟",
            "confidence": 1.0,
            "suggestions": [
                "ما هي شرائح الكهرباء في مصر؟",
                "كام أشحن في العداد؟",
                "ما هو أكثر جهاز يستهلك كهرباء في بيتي؟"
            ]
        }

    # 1. التحقق من الأسئلة الحية للمستخدم
    dynamic_reply = check_dynamic_user_queries(user_id, clean_msg)
    if dynamic_reply:
        # تسجيل المحادثة
        try:
            log = ChatLog(
                user_id=user_id,
                user_message=user_message,
                bot_response=dynamic_reply,
                confidence_score=0.99
            )
            db.session.add(log)
            db.session.commit()
        except Exception:
            db.session.rollback()

        return {
            "reply": dynamic_reply,
            "confidence": 0.99,
            "is_dynamic": True,
            "suggestions": ["كام أشحن في العداد؟", "كيف أقلل فاتورة الكهرباء؟"]
        }

    # 2. المطابقة عبر TF-IDF و Cosine Similarity
    faq_list, vectorizer, tfidf_matrix = build_faq_corpus()
    query_vec = vectorizer.transform([clean_msg])
    sim_scores = cosine_similarity(query_vec, tfidf_matrix).flatten()

    best_idx = int(np.argmax(sim_scores))
    best_score = float(sim_scores[best_idx])

    # استخراج أفضل 3 أسئلة مقترحة بديلة
    top_indices = np.argsort(sim_scores)[::-1][:3]
    suggestions = [faq_list[i]["question_ar"] for i in top_indices if i != best_idx]

    threshold = 0.18  # حد الثقة المقبول لمطابقة الأسئلة

    if best_score >= threshold:
        matched_item = faq_list[best_idx]
        bot_reply = matched_item["answer_ar"]
        matched_id = matched_item.get("id")
    else:
        bot_reply = (
            "عذراً، لم أستطع فهم سؤالك بدقة. هل تقصد أحد الاستفسارات الشائعة التالية؟ "
            "أو يمكنك كتابة استفسارك بصيغة أخرى."
        )
        matched_id = None
        suggestions = [
            "ما هي شرائح الكهرباء في مصر وكيف تُحسب؟",
            "كام أشحن في العداد؟",
            "كيف أقلل استهلاك التكييف؟"
        ]

    # حفظ السجل
    try:
        log = ChatLog(
            user_id=user_id,
            user_message=user_message,
            bot_response=bot_reply,
            matched_faq_id=matched_id,
            confidence_score=round(best_score, 4)
        )
        db.session.add(log)
        db.session.commit()
    except Exception:
        db.session.rollback()

    return {
        "reply": bot_reply,
        "confidence": round(best_score, 4),
        "matched_faq_id": matched_id,
        "suggestions": suggestions
    }
