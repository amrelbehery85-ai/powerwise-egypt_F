# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Prediction & Smart Recharge Recommendation Service
خدمة التنبؤ الذكي وحساب "كام أشحن؟" مع نطاقات الثقة ومخططات التحليلات
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
import numpy as np
import pandas as pd

from backend.models import db, Meter, Device, Prediction
from backend.services.tariff_service import calculate_bill
from backend.ml.model_trainer import (
    load_energy_models,
    FEATURE_COLUMNS
)
from backend.ml.data_generator import EGYPT_MONTHLY_AVG_TEMPS

def generate_forecast_features(start_date: datetime, days: int, base_daily_kwh: float = 12.5) -> pd.DataFrame:
    """
    تجهيز ميزات الأيام القادمة للتنبؤ بنماذج تعلم الآلة
    """
    future_dates = [start_date + timedelta(days=i) for i in range(days)]
    data = []

    current_lag1 = base_daily_kwh
    current_lag2 = base_daily_kwh * 0.98

    for d in future_dates:
        month = d.month
        day_of_week = d.weekday()  # 0=Monday, 4=Friday, 5=Saturday
        is_weekend = 1 if day_of_week in [4, 5] else 0
        base_temp = EGYPT_MONTHLY_AVG_TEMPS.get(month, 22.0)

        data.append({
            "date": d,
            "month": month,
            "day_of_week": day_of_week,
            "is_weekend": is_weekend,
            "avg_temp": base_temp,
            "max_temp": base_temp + 4.0,
            "min_temp": base_temp - 4.0,
            "lag_1_day_kwh": current_lag1,
            "lag_2_day_kwh": current_lag2,
            "rolling_7day_kwh": base_daily_kwh
        })
        # تحديث الميزات السابقة للأيام التالية
        current_lag2 = current_lag1
        current_lag1 = base_daily_kwh * (1.15 if is_weekend else 0.98)

    return pd.DataFrame(data)


def predict_daily_consumption(user_id: int, period_days: int = 7) -> Dict[str, Any]:
    """
    توليد التوقعات اليومية للفترة القادمة مع نطاق الثقة (10% إلى 90%):
    - الاستهلاك المتوقع (نقطة الأساس 50%)
    - الحد الأدنى للثقة (10%)
    - الحد الأقصى المتوقع (90%)
    - التكلفة التقديرية بالجنيه
    """
    period_days = max(1, min(period_days, 30))
    rf_model, q10_model, q80_model, q90_model, metrics = load_energy_models()

    # حساب الاستهلاك اليومي التقديري للأجهزة المشغلة لحساب المستخدم
    devices = Device.query.filter_by(user_id=user_id, is_active=True).all()
    if devices:
        user_active_daily_kwh = sum(
            (float(d.rated_watts) * int(d.count) * float(d.daily_hours)) / 1000.0
            for d in devices
        )
    else:
        user_active_daily_kwh = 12.0  # متوسط منزلي افتراضي

    start_date = datetime.now() + timedelta(days=1)
    feat_df = generate_forecast_features(start_date, period_days, base_daily_kwh=user_active_daily_kwh)

    X = feat_df[FEATURE_COLUMNS]

    # التنبؤ بالنقطة والحدود
    pred_point = rf_model.predict(X)
    pred_q10 = q10_model.predict(X)
    pred_q80 = q80_model.predict(X)
    pred_q90 = q90_model.predict(X)

    # ضبط التوافق مع نمط أجهزة المستخدم
    scale_factor = (user_active_daily_kwh / 12.5) if user_active_daily_kwh > 0 else 1.0
    pred_point = np.maximum(0.5, pred_point * scale_factor)
    pred_q10 = np.maximum(0.3, pred_q10 * scale_factor)
    pred_q80 = np.maximum(pred_point, pred_q80 * scale_factor)
    pred_q90 = np.maximum(pred_q80, pred_q90 * scale_factor)

    daily_forecasts = []
    total_kwh_point = 0.0
    total_kwh_q10 = 0.0
    total_kwh_q80 = 0.0
    total_kwh_q90 = 0.0

    for i in range(len(feat_df)):
        d_kwh = float(pred_point[i])
        d_q10 = float(pred_q10[i])
        d_q80 = float(pred_q80[i])
        d_q90 = float(pred_q90[i])

        total_kwh_point += d_kwh
        total_kwh_q10 += d_q10
        total_kwh_q80 += d_q80
        total_kwh_q90 += d_q90

        # حساب تكلفة اليوم التقديرية
        cost_info = calculate_bill(d_kwh)

        daily_forecasts.append({
            "date": feat_df.iloc[i]["date"].strftime("%Y-%m-%d"),
            "day_name_ar": ["الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد"][feat_df.iloc[i]["day_of_week"]],
            "is_weekend": bool(feat_df.iloc[i]["is_weekend"]),
            "predicted_kwh": round(d_kwh, 2),
            "lower_bound_kwh": round(d_q10, 2),
            "upper_bound_kwh": round(d_q90, 2),
            "estimated_cost_egp": cost_info["total_cost"]
        })

    # تكلفة إجمالي الفترة
    period_bill = calculate_bill(total_kwh_point)
    period_bill_q10 = calculate_bill(total_kwh_q10)
    period_bill_q80 = calculate_bill(total_kwh_q80)
    period_bill_q90 = calculate_bill(total_kwh_q90)

    # حفظ سجل التنبؤ في قاعدة البيانات
    try:
        new_pred = Prediction(
            user_id=user_id,
            prediction_date=datetime.now().date(),
            target_period_days=period_days,
            predicted_kwh=round(total_kwh_point, 3),
            lower_bound_kwh=round(total_kwh_q10, 3),
            upper_bound_kwh=round(total_kwh_q90, 3),
            predicted_cost_egp=round(period_bill["total_cost"], 2),
            model_version="v1.0-rf-quantile"
        )
        db.session.add(new_pred)
        db.session.commit()
    except Exception:
        db.session.rollback()

    return {
        "period_days": period_days,
        "total_predicted_kwh": round(total_kwh_point, 2),
        "lower_bound_kwh": round(total_kwh_q10, 2),
        "upper_bound_kwh": round(total_kwh_q90, 2),
        "q80_kwh": round(total_kwh_q80, 2),
        "total_cost_egp": round(period_bill["total_cost"], 2),
        "lower_cost_egp": round(period_bill_q10["total_cost"], 2),
        "recommended_cost_q80_egp": round(period_bill_q80["total_cost"], 2),
        "upper_cost_egp": round(period_bill_q90["total_cost"], 2),
        "current_tier": period_bill["current_tier"],
        "daily_forecasts": daily_forecasts,
        "metrics": metrics,
        "disclaimer": "تنبيه: التوقعات مبنية على نموذج تعلم الآلة وهي قيم استرشادية تقديرية وليست قراءة رسمية."
    }


def recommend_recharge(user_id: int, period_days: int = 7, confidence: float = 0.80) -> Dict[str, Any]:
    """
    خاصية "كام أشحن؟":
    - المستخدم يختار المدة (يوم، يومين، أسبوع، أسبوعين، شهر).
    - التطبيق يحسب المبلغ المقترح بالجنيه باحتمال ثقة 80% مع الحدين الأدنى والأقصى.
    - يراعي الرصيد الحالي للعداد والشريحة التراكمية.
    - يحسب كم يوماً سيكفي الرصيد الحالي.
    """
    forecast = predict_daily_consumption(user_id, period_days)

    # استرجاع رصيد العداد الحالي
    meter = Meter.query.filter_by(user_id=user_id).first()
    current_balance = float(meter.current_balance) if meter else 0.0

    cost_q80 = forecast["recommended_cost_q80_egp"]
    cost_min = forecast["lower_cost_egp"]
    cost_max = forecast["upper_cost_egp"]

    # المبلغ المقترح للشحن = تكلفة الفترة المطلوبة بنسبة أمان 80% مطروحاً منها الرصيد المتبقي
    if current_balance >= cost_q80:
        recommended_recharge = 0.0
        recharge_status = "sufficient"
        status_message_ar = f"رصيدك الحالي ({current_balance:.2f} ج.م) كافٍ لتغطية الـ {period_days} أيام القادمة بأمان!"
    else:
        recommended_recharge = round(cost_q80 - current_balance, 2)
        recharge_status = "recharge_needed"
        status_message_ar = f"يُنصح بشحن مبلغ {recommended_recharge:.2f} ج.م لتغطية الـ {period_days} أيام القادمة بنسبة ثقة 80%."

    min_recharge = round(max(0.0, cost_min - current_balance), 2)
    max_recharge = round(max(0.0, cost_max - current_balance), 2)

    # كم يوماً سيكفي الرصيد الحالي؟
    daily_cost_avg = forecast["total_cost_egp"] / period_days if period_days > 0 else 1.0
    if daily_cost_avg > 0:
        days_remaining = round(current_balance / daily_cost_avg, 1)
    else:
        days_remaining = 30.0

    return {
        "period_days": period_days,
        "confidence_level": f"{int(confidence * 100)}%",
        "current_balance_egp": round(current_balance, 2),
        "days_remaining_estimate": days_remaining,
        "recommended_recharge_egp": recommended_recharge,
        "min_recharge_egp": min_recharge,
        "max_recharge_egp": max_recharge,
        "recharge_status": recharge_status,
        "status_message_ar": status_message_ar,
        "period_cost_details": {
            "expected_kwh_q80": forecast["q80_kwh"],
            "expected_cost_q80_egp": cost_q80,
            "min_expected_cost_egp": cost_min,
            "max_expected_cost_egp": cost_max,
            "current_tier": forecast["current_tier"]
        },
        "disclaimer": "النتائج تقديرية ومحسوبة لتفادي نفاد الرصيد فجأة بناءً على نمط تشغيل الأجهزة."
    }


def get_visual_charts_data(user_id: int) -> Dict[str, Any]:
    """
    تجهيز بيانات الرسوم البيانية التفاعلية:
    1. Line Chart: التوقع الزمني للأيام القادمة مع نطاق الثقة (Lower & Upper Bounds).
    2. Bar Chart: مقارنة استهلاك كل جهاز يومياً بالكيلوواط ساعة.
    3. Donut Chart: التوزيع النسبي للاستهلاك حسب الفئات (تبريد، إضاءة، مطبخ، إلكترونيات).
    """
    # 1. بيانات التوقع الزمني (Line Chart)
    forecast = predict_daily_consumption(user_id, period_days=7)
    line_labels = [f["day_name_ar"] + " " + f["date"][5:] for f in forecast["daily_forecasts"]]
    line_predicted = [f["predicted_kwh"] for f in forecast["daily_forecasts"]]
    line_lower = [f["lower_bound_kwh"] for f in forecast["daily_forecasts"]]
    line_upper = [f["upper_bound_kwh"] for f in forecast["daily_forecasts"]]

    # 2. بيانات استهلاك الأجهزة (Bar Chart)
    devices = Device.query.filter_by(user_id=user_id).all()
    bar_labels = []
    bar_values = []
    category_map: Dict[str, float] = {}

    for d in devices:
        watts = int(d.rated_watts) * int(d.count)
        kwh = round((watts * float(d.daily_hours)) / 1000.0, 3)
        bar_labels.append(d.custom_name)
        bar_values.append(kwh)

        # التجميع للـ Donut Chart
        cat = d.device_type.category if d.device_type else "other"
        category_map[cat] = category_map.get(cat, 0.0) + kwh

    # ترجمة أسماء الفئات للعربية للـ Donut Chart
    cat_names_ar = {
        "cooling": "تكييف وتبريد",
        "heating": "تسخين مياه",
        "kitchen": "أجهزة المطبخ",
        "lighting": "الإضاءة",
        "entertainment": "ترفيه وشاشات",
        "laundry": "غسيل وكي",
        "electronics": "إلكترونيات وشواحن",
        "network": "إنترنت وشبكات",
        "utility": "طلمبات ومرافق",
        "other": "أجهزة أخرى"
    }

    donut_labels = [cat_names_ar.get(c, c) for c in category_map.keys()]
    donut_values = [round(v, 2) for v in category_map.values()]

    return {
        "line_chart": {
            "labels": line_labels,
            "predicted": line_predicted,
            "lower_bound": line_lower,
            "upper_bound": line_upper,
            "title_ar": "التنبؤ بالأسبوع القادم مع نطاق الثقة (10% - 90%)"
        },
        "bar_chart": {
            "labels": bar_labels,
            "values": bar_values,
            "unit": "ك.و.س / يوم",
            "title_ar": "مقارنة الاستهلاك اليومي لكل جهاز"
        },
        "donut_chart": {
            "labels": donut_labels,
            "values": donut_values,
            "title_ar": "توزيع الاستهلاك حسب فئات الأجهزة"
        }
    }
