# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Device Service
خدمة إدارة الأجهزة وحساب الأحمال اللحظية والتحقق من القدرة
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

from typing import Dict, Any, List, Optional
from decimal import Decimal
from backend.models import db, Device, DeviceType, User
from backend.services.tariff_service import calculate_bill

def get_all_device_types() -> List[Dict[str, Any]]:
    """استرجاع كافة أنواع الأجهزة القياسية الـ 20 مع النطاقات المسموحة بالوات"""
    types = DeviceType.query.order_by(DeviceType.id.asc()).all()
    return [t.to_dict() for t in types]


def get_user_devices(user_id: int) -> List[Dict[str, Any]]:
    """استرجاع قائمة أجهزة المستخدم مع تفاصيل القدرة والاستهلاك"""
    devices = Device.query.filter_by(user_id=user_id).order_by(Device.created_at.desc()).all()
    return [d.to_dict() for d in devices]


def add_user_device(user_id: int, data: Dict[str, Any]) -> Dict[str, Any]:
    """
    إضافة جهاز جديد مع التحقق الصارم من نطاق القدرة بالوات:
    - للأجهزة القياسية: الالتزام بنطاق min_watts و max_watts
    - للجهاز المخصص (جهاز آخر): القبول بين 1 و 5000 وات
    """
    device_type_id = data.get("device_type_id")
    custom_name = str(data.get("custom_name", "")).strip()
    rated_watts = data.get("rated_watts")
    count = data.get("count", 1)
    daily_hours = data.get("daily_hours", 1.0)
    is_active = data.get("is_active", True)

    if not custom_name:
        raise ValueError("يرجى إدخال اسم مميز للجهاز (مثال: تكييف الصالة، ثلاجة المطبخ).")

    # نوع الجهاز اختياري: لو لم يُرسل نستخدم النوع "المخصص" (يقبل 1 إلى 5000 وات)
    if device_type_id:
        dev_type = db.session.get(DeviceType, device_type_id)
        if not dev_type:
            raise ValueError("نوع الجهاز المختار غير صالح.")
    else:
        dev_type = DeviceType.query.filter_by(is_custom=True).first()
        if not dev_type:
            dev_type = DeviceType(name_ar="جهاز آخر", name_en="Custom Device", min_watts=1,
                                  max_watts=5000, typical_watts=100, category="other",
                                  icon_svg_name="plug", is_custom=True)
            db.session.add(dev_type)
            db.session.flush()
        device_type_id = dev_type.id

    try:
        rated_watts = int(rated_watts)
        count = int(count)
        daily_hours = float(daily_hours)
    except (ValueError, TypeError):
        raise ValueError("القيم المدخلة للقدرة أو العدد أو الساعات غير صحيحة.")

    if count < 1 or count > 100:
        raise ValueError("عدد الأجهزة يجب أن يكون بين 1 و 100.")

    if daily_hours <= 0.0 or daily_hours > 24.0:
        raise ValueError("ساعات التشغيل اليومية يجب أن تكون أكبر من 0 ولا تتعدى 24 ساعة.")

    # التحقق من نطاق القدرة بالوات
    if dev_type.is_custom:
        if rated_watts < 1 or rated_watts > 5000:
            raise ValueError("قدرة الجهاز المخصص يجب أن تكون بين 1 و 5000 وات.")
    else:
        if rated_watts < dev_type.min_watts or rated_watts > dev_type.max_watts:
            raise ValueError(
                f"قدرة {dev_type.name_ar} يجب أن تلتزم بالنطاق المسموح به لهذا النوع "
                f"من {dev_type.min_watts} إلى {dev_type.max_watts} وات. "
                f"(القيمة الشائعة هي {dev_type.typical_watts} وات)."
            )

    new_device = Device(
        user_id=user_id,
        device_type_id=device_type_id,
        custom_name=custom_name,
        rated_watts=rated_watts,
        count=count,
        daily_hours=daily_hours,
        is_active=bool(is_active)
    )

    db.session.add(new_device)
    db.session.commit()

    return new_device.to_dict()


def update_user_device(user_id: int, device_id: int, data: Dict[str, Any]) -> Dict[str, Any]:
    """تعديل بيانات جهاز مسجل مع الحفاظ على التحقق البرمجي"""
    device = Device.query.filter_by(id=device_id, user_id=user_id).first()
    if not device:
        raise ValueError("لم يتم العثور على الجهاز المطلوب.")

    if "custom_name" in data and str(data["custom_name"]).strip():
        device.custom_name = str(data["custom_name"]).strip()

    if "daily_hours" in data:
        hours = float(data["daily_hours"])
        if hours <= 0.0 or hours > 24.0:
            raise ValueError("ساعات التشغيل يجب أن تكون بين 0.1 و 24 ساعة.")
        device.daily_hours = hours

    if "count" in data:
        cnt = int(data["count"])
        if cnt < 1 or cnt > 100:
            raise ValueError("العدد يجب أن يكون بين 1 و 100.")
        device.count = cnt

    if "rated_watts" in data:
        watts = int(data["rated_watts"])
        dev_type = device.device_type
        if dev_type.is_custom:
            if watts < 1 or watts > 5000:
                raise ValueError("قدرة الجهاز المخصص يجب أن تكون بين 1 و 5000 وات.")
        else:
            if watts < dev_type.min_watts or watts > dev_type.max_watts:
                raise ValueError(
                    f"القدرة يجب أن تكون بين {dev_type.min_watts} و {dev_type.max_watts} وات."
                )
        device.rated_watts = watts

    if "is_active" in data:
        device.is_active = bool(data["is_active"])

    db.session.commit()
    return device.to_dict()


def toggle_device_state(user_id: int, device_id: int) -> Dict[str, Any]:
    """تبديل حالة تشغيل الجهاز لحظياً (ON / OFF)"""
    device = Device.query.filter_by(id=device_id, user_id=user_id).first()
    if not device:
        raise ValueError("لم يتم العثور على الجهاز.")

    device.is_active = not bool(device.is_active)
    db.session.commit()
    return device.to_dict()


def delete_user_device(user_id: int, device_id: int) -> bool:
    """حذف جهاز من حساب المستخدم"""
    device = Device.query.filter_by(id=device_id, user_id=user_id).first()
    if not device:
        raise ValueError("لم يتم العثور على الجهاز.")

    db.session.delete(device)
    db.session.commit()
    return True


def calculate_live_power_summary(user_id: int) -> Dict[str, Any]:
    """
    حساب ملخص الأحمال والقدرة اللحظية لكافة الأجهزة المشغلة (ON):
    - مجموع القدرة اللحظية (وات)
    - الاستهلاك في الساعة (ك.و.س)
    - الاستهلاك اليومي المتوقع (ك.و.س)
    - الاستهلاك الشهري المتوقع (ك.و.س)
    - التكلفة المتوقعة بالجنيه حسب شرائح الكهرباء المصرية
    """
    devices = Device.query.filter_by(user_id=user_id).all()

    total_devices_count = len(devices)
    active_devices_count = 0
    total_active_watts = 0
    total_daily_kwh = Decimal('0.0')

    active_devices_list = []

    for d in devices:
        if d.is_active:
            active_devices_count += 1
            device_watts = int(d.rated_watts) * int(d.count)
            total_active_watts += device_watts

            device_daily_kwh = (Decimal(str(device_watts)) * Decimal(str(d.daily_hours))) / Decimal('1000.0')
            total_daily_kwh += device_daily_kwh

            active_devices_list.append({
                "id": d.id,
                "name": d.custom_name,
                "watts": device_watts,
                "daily_hours": float(d.daily_hours),
                "daily_kwh": round(float(device_daily_kwh), 3)
            })

    # الاستهلاك بالساعة (kWh per hour) للأجهزة المشغلة حالياً
    hourly_kwh = Decimal(str(total_active_watts)) / Decimal('1000.0')
    # الاستهلاك الشهري التقديري (30 يوماً)
    monthly_kwh = total_daily_kwh * Decimal('30.0')

    # حساب التكلفة وفق منظومة الشرائح المصرية
    monthly_bill = calculate_bill(float(monthly_kwh))
    monthly_cost_egp = monthly_bill["total_cost"]
    current_tier = monthly_bill["current_tier"]
    marginal_price = monthly_bill["marginal_price"]

    # التكلفة اليومية التقديرية
    daily_cost_egp = round(monthly_cost_egp / 30.0, 2)
    # التكلفة اللحظية لكل ساعة تشغيل حالية بالسعر الحدي
    hourly_cost_egp = round(float(hourly_kwh) * marginal_price, 3)

    return {
        "total_devices_count": total_devices_count,
        "active_devices_count": active_devices_count,
        "total_active_watts": total_active_watts,
        "hourly_kwh": round(float(hourly_kwh), 4),
        "daily_kwh": round(float(total_daily_kwh), 3),
        "monthly_kwh": round(float(monthly_kwh), 2),
        "hourly_cost_egp": hourly_cost_egp,
        "daily_cost_egp": daily_cost_egp,
        "monthly_cost_egp": monthly_cost_egp,
        "current_tier": current_tier,
        "marginal_price": marginal_price,
        "active_devices": active_devices_list,
        "disclaimer": "تنويه: الاستهلاك والتكاليف تقديرية بناءً على الأجهزة المشغلة ومواصفاتها."
    }
