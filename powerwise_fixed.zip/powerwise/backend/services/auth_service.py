# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Authentication & User Service
خدمة تسجيل الدخول والمستخدمين وإدارة العداد
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

import re
import secrets
from typing import Dict, Any, Optional
from backend.models import db, User, Meter

# تعبير نمطي للتحقق من صحة صيغة البريد الإلكتروني
EMAIL_REGEX = re.compile(r"^[\w\.-]+@[\w\.-]+\.\w+$")

def register_user(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    تسجيل مستخدم جديد:
    - التحقق من البيانات والبريد الإلكتروني
    - تشفير كلمة المرور بـ werkzeug
    - إنشاء عداد كهرباء افتراضي جديد للمستخدم مع رصيد مبدئي
    """
    full_name = str(data.get("full_name", "")).strip()
    email = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", "")).strip()
    meter_number = str(data.get("meter_number", "")).strip()

    if not full_name or len(full_name) < 3:
        raise ValueError("يرجى إدخال اسم ثلاثي صالح لا يقل عن 3 أحرف.")

    if not email or not EMAIL_REGEX.match(email):
        raise ValueError("صيغة البريد الإلكتروني غير صالحة.")

    if not password or len(password) < 6:
        raise ValueError("كلمة المرور يجب أن لا تقل عن 6 خانات.")

    # فحص تكرار البريد الإلكتروني
    existing_user = User.query.filter_by(email=email).first()
    if existing_user:
        raise ValueError("البريد الإلكتروني مسجل بالفعل لمستخدم آخر.")

    # توليد رقم عداد إن لم يقدمه المستخدم
    if not meter_number:
        random_suffix = secrets.randbelow(900000) + 100000
        meter_number = f"MTR-EG-{random_suffix}"
    else:
        # التأكد من عدم تكرار رقم العداد
        existing_meter = Meter.query.filter_by(meter_number=meter_number).first()
        if existing_meter:
            raise ValueError("رقم العداد هذا مسجل بالفعل في النظام.")

    user = User(
        full_name=full_name,
        email=email,
        role='user'
    )
    user.set_password(password)
    db.session.add(user)
    db.session.flush()  # للحصول على معرف المستخدم الجديد user.id

    # إنشاء عداد كهرباء مرتبط بالمستخدم
    meter = Meter(
        user_id=user.id,
        meter_number=meter_number,
        current_balance=100.00,  # رصيد ترحيبي مبدئي 100 ج.م
        tariff_category='residential'
    )
    db.session.add(meter)
    db.session.commit()

    return {
        "user": user.to_dict(),
        "meter": meter.to_dict()
    }


def authenticate_user(email: str, password: str) -> Optional[Dict[str, Any]]:
    """التحقق من بيانات الدخول وإرجاع بيانات المستخدم والعداد"""
    email = str(email).strip().lower()
    user = User.query.filter_by(email=email).first()

    if not user or not user.check_password(password):
        return None

    meter = Meter.query.filter_by(user_id=user.id).first()

    return {
        "user": user.to_dict(),
        "meter": meter.to_dict() if meter else None
    }


def get_user_profile(user_id: int) -> Optional[Dict[str, Any]]:
    """استرجاع الملف الشخصي للمستخدم متضمناً تفاصيل العداد"""
    user = db.session.get(User, user_id)
    if not user:
        return None

    meter = Meter.query.filter_by(user_id=user.id).first()
    return {
        "user": user.to_dict(),
        "meter": meter.to_dict() if meter else None
    }
