# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Database Auto-Seeder
تغذية قاعدة البيانات تلقائياً عند التشغيل الأول (MySQL أو SQLite)
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

from datetime import datetime, date
from backend.models import db, User, Meter, DeviceType, Device, Tariff, FAQ, Notification

def seed_database_if_empty():
    """
    التحقق من وجود الجداول والبيانات الأساسية وتغذيتها تلقائياً عند أول تشغيل
    """
    try:
        db.create_all()

        # 1. التحقق من وجود الشرائح وتغذيتها
        if Tariff.query.count() == 0:
            print("[*] جاري تغذية شرائح الكهرباء المصرية الرسمية...")
            tariffs = [
                Tariff(tier_number=1, tier_name_ar="الشريحة الأولى (من 0 إلى 50 ك.و.س)", tier_name_en="Tier 1 (0 to 50 kWh)", min_kwh=0.0, max_kwh=50.0, price_per_kwh=0.68, service_fee=1.0, bracket_group=1, effective_date=date(2024, 8, 1), source="EgyptERA 2024/2025", is_active=True),
                Tariff(tier_number=2, tier_name_ar="الشريحة الثانية (من 51 إلى 100 ك.و.س)", tier_name_en="Tier 2 (51 to 100 kWh)", min_kwh=51.0, max_kwh=100.0, price_per_kwh=0.78, service_fee=2.0, bracket_group=1, effective_date=date(2024, 8, 1), source="EgyptERA 2024/2025", is_active=True),
                Tariff(tier_number=3, tier_name_ar="الشريحة الثالثة (من 0 إلى 200 ك.و.س بديل)", tier_name_en="Tier 3 (0 to 200 kWh)", min_kwh=0.0, max_kwh=200.0, price_per_kwh=0.95, service_fee=6.0, bracket_group=2, effective_date=date(2024, 8, 1), source="EgyptERA 2024/2025", is_active=True),
                Tariff(tier_number=4, tier_name_ar="الشريحة الرابعة (من 201 إلى 350 ك.و.س)", tier_name_en="Tier 4 (201 to 350 kWh)", min_kwh=201.0, max_kwh=350.0, price_per_kwh=1.55, service_fee=11.0, bracket_group=2, effective_date=date(2024, 8, 1), source="EgyptERA 2024/2025", is_active=True),
                Tariff(tier_number=5, tier_name_ar="الشريحة الخامسة (من 351 إلى 650 ك.و.س)", tier_name_en="Tier 5 (351 to 650 kWh)", min_kwh=351.0, max_kwh=650.0, price_per_kwh=1.95, service_fee=15.0, bracket_group=2, effective_date=date(2024, 8, 1), source="EgyptERA 2024/2025", is_active=True),
                Tariff(tier_number=6, tier_name_ar="الشريحة السادسة (من 0 إلى 1000 ك.و.س دون دعم)", tier_name_en="Tier 6 (0 to 1000 kWh)", min_kwh=0.0, max_kwh=1000.0, price_per_kwh=2.10, service_fee=25.0, bracket_group=3, effective_date=date(2024, 8, 1), source="EgyptERA 2024/2025", is_active=True),
                Tariff(tier_number=7, tier_name_ar="الشريحة السابعة (أكثر من 1000 ك.و.س)", tier_name_en="Tier 7 (More than 1000 kWh)", min_kwh=1001.0, max_kwh=999999.0, price_per_kwh=2.23, service_fee=40.0, bracket_group=4, effective_date=date(2024, 8, 1), source="EgyptERA 2024/2025", is_active=True),
            ]
            db.session.bulk_save_objects(tariffs)
            db.session.commit()

        # 2. التحقق من أنواع الأجهزة القياسية الـ 20
        if DeviceType.query.count() == 0:
            print("[*] جاري تغذية أنواع الأجهزة القياسية...")
            device_types = [
                DeviceType(id=1, name_ar="لمبة LED موفرة", name_en="LED Bulb", min_watts=5, max_watts=20, typical_watts=9, category="lighting", icon_svg_name="lightbulb", is_custom=False),
                DeviceType(id=2, name_ar="لمبة عادية متوهجة", name_en="Incandescent Bulb", min_watts=40, max_watts=100, typical_watts=60, category="lighting", icon_svg_name="bulb-vintage", is_custom=False),
                DeviceType(id=3, name_ar="شاحن هاتف محمول", name_en="Phone Charger", min_watts=5, max_watts=25, typical_watts=15, category="electronics", icon_svg_name="smartphone", is_custom=False),
                DeviceType(id=4, name_ar="شاحن لابتوب", name_en="Laptop Charger", min_watts=45, max_watts=120, typical_watts=65, category="electronics", icon_svg_name="laptop", is_custom=False),
                DeviceType(id=5, name_ar="مروحة سقف / مكتب", name_en="Fan", min_watts=40, max_watts=100, typical_watts=60, category="cooling", icon_svg_name="fan", is_custom=False),
                DeviceType(id=6, name_ar="شاشة تلفزيون (LED/LCD)", name_en="Television", min_watts=50, max_watts=250, typical_watts=100, category="entertainment", icon_svg_name="tv", is_custom=False),
                DeviceType(id=7, name_ar="ثلاجة منزلية (نوفروست)", name_en="Refrigerator", min_watts=100, max_watts=400, typical_watts=200, category="kitchen", icon_svg_name="fridge", is_custom=False),
                DeviceType(id=8, name_ar="غسالة ملابس أوتوماتيك", name_en="Washing Machine", min_watts=300, max_watts=2500, typical_watts=800, category="laundry", icon_svg_name="washer", is_custom=False),
                DeviceType(id=9, name_ar="تكييف سبليت (1.5 حصان)", name_en="Air Conditioner (1.5 HP)", min_watts=1000, max_watts=2200, typical_watts=1400, category="cooling", icon_svg_name="ac", is_custom=False),
                DeviceType(id=10, name_ar="سخان مياه كهربائي", name_en="Electric Water Heater", min_watts=1200, max_watts=3000, typical_watts=1800, category="heating", icon_svg_name="heater", is_custom=False),
                DeviceType(id=11, name_ar="مكواة ملابس بخار", name_en="Steam Iron", min_watts=1000, max_watts=2400, typical_watts=1500, category="laundry", icon_svg_name="iron", is_custom=False),
                DeviceType(id=12, name_ar="ميكروويف", name_en="Microwave", min_watts=700, max_watts=1500, typical_watts=1000, category="kitchen", icon_svg_name="microwave", is_custom=False),
                DeviceType(id=13, name_ar="غلاية مياه (كاتيل)", name_en="Electric Kettle", min_watts=1200, max_watts=2400, typical_watts=1800, category="kitchen", icon_svg_name="kettle", is_custom=False),
                DeviceType(id=14, name_ar="راوتر واي فاي منزلي", name_en="WiFi Router", min_watts=6, max_watts=15, typical_watts=10, category="network", icon_svg_name="wifi", is_custom=False),
                DeviceType(id=15, name_ar="كمبيوتر مكتبي (Desktop PC)", name_en="Desktop PC", min_watts=150, max_watts=600, typical_watts=300, category="electronics", icon_svg_name="pc", is_custom=False),
                DeviceType(id=16, name_ar="جهاز لابتوب للعمل", name_en="Laptop Computer", min_watts=40, max_watts=100, typical_watts=60, category="electronics", icon_svg_name="laptop", is_custom=False),
                DeviceType(id=17, name_ar="طلمبة مياه (موتور مياه)", name_en="Water Pump", min_watts=500, max_watts=1500, typical_watts=750, category="utility", icon_svg_name="pump", is_custom=False),
                DeviceType(id=18, name_ar="فرن كهربائي منزلي", name_en="Electric Oven", min_watts=1500, max_watts=3500, typical_watts=2000, category="kitchen", icon_svg_name="oven", is_custom=False),
                DeviceType(id=19, name_ar="بوتاجاز مسطح كهربائي", name_en="Electric Cooktop", min_watts=1200, max_watts=4000, typical_watts=2200, category="kitchen", icon_svg_name="cooktop", is_custom=False),
                DeviceType(id=20, name_ar="جهاز آخر (مخصص)", name_en="Other Device (Custom)", min_watts=1, max_watts=5000, typical_watts=100, category="other", icon_svg_name="custom-plug", is_custom=True),
            ]
            for dt in device_types:
                db.session.merge(dt)
            db.session.commit()

        # 3. التحقق من المستخدمين والعداد والأجهزة التجريبية
        if User.query.count() == 0:
            print("[*] جاري إنشاء الحسابات التجريبية والعداد...")
            admin = User(id=1, full_name="مسؤول النظام (Admin PowerWise)", email="admin@powerwise.eg", role="admin")
            admin.set_password("Admin@123456")
            db.session.add(admin)

            student = User(id=2, full_name="م. عمرو ضياء الدين حسن (طالب معهد طيبة)", email="student@powerwise.eg", role="user")
            student.set_password("Student@123456")
            db.session.add(student)
            db.session.commit()

            meter = Meter(id=1, user_id=2, meter_number="MTR-THEBES-2025-01", current_balance=145.75, tariff_category="residential")
            db.session.add(meter)
            db.session.commit()

            demo_devices = [
                Device(user_id=2, device_type_id=7, custom_name="ثلاجة المطبخ (نوفروست 16 قدم)", rated_watts=200, count=1, daily_hours=24.0, is_active=True),
                Device(user_id=2, device_type_id=9, custom_name="تكييف غرفة المعيشة 1.5 حصان", rated_watts=1400, count=1, daily_hours=6.0, is_active=True),
                Device(user_id=2, device_type_id=1, custom_name="إضاءة الصالة (لمبات ليد موفرة)", rated_watts=9, count=5, daily_hours=7.0, is_active=True),
                Device(user_id=2, device_type_id=14, custom_name="راوتر الإنترنت المنزلي", rated_watts=10, count=1, daily_hours=24.0, is_active=True),
                Device(user_id=2, device_type_id=6, custom_name="تلفزيون الريسبشن 50 بوصة", rated_watts=100, count=1, daily_hours=5.0, is_active=True),
                Device(user_id=2, device_type_id=8, custom_name="غسالة الملابس الأوتوماتيك", rated_watts=800, count=1, daily_hours=1.5, is_active=False),
                Device(user_id=2, device_type_id=13, custom_name="غلاية المياه (الكاتيل)", rated_watts=1800, count=1, daily_hours=0.4, is_active=False),
            ]
            db.session.bulk_save_objects(demo_devices)
            db.session.commit()

        # 4. تغذية الأسئلة الشائعة للشات بوت
        if FAQ.query.count() == 0:
            print("[*] جاري تغذية قاعدة المعرفة للشات بوت الذكي...")
            sample_faqs = [
                FAQ(category="tariffs", question_ar="ما هي شرائح الكهرباء في مصر وكيف تُحسب؟", question_en="What are electricity tiers in Egypt?", keywords="شرائح, تعرفة, حساب, فاتورة, كيلوواط", answer_ar="تنقسم شرائح الكهرباء المنزلية في مصر إلى 7 شرائح تصاعدية تبدأ من 68 قرشاً للشريحة الأولى وحتى 223 قرشاً للشريحة السابعة بحسب استهلاكك الشهري.", answer_en="Egypt residential electricity is divided into 7 cumulative tiers starting from 68 piasters up to 223 piasters."),
                FAQ(category="tariffs", question_ar="كم سعر الكيلوواط ساعة الآن؟", question_en="How much does one kWh cost right now?", keywords="سعر الكيلوواط, تكلفة الكيلو, قرش, جنيه", answer_ar="سعر الكيلوواط غير ثابت في مصر، بل يتحدد حسب شريحة استهلاكك التراكمية في الشهر الحالي، ويبدأ من 68 قرشاً في الشريحة الأولى ويصل إلى 223 قرشاً في الشريحة السابعة.", answer_en="The cost per kWh in Egypt varies by your active monthly tier from 0.68 EGP up to 2.23 EGP."),
                FAQ(category="tariffs", question_ar="لماذا يتم خصم مبالغ كبيرة عند الانتقال للشريحة الثالثة؟", question_en="Why is a large amount deducted when moving to Tier 3?", keywords="خصم, فرق شريحة, قفزة, الشريحة الثالثة, 100 كيلو", answer_ar="عندما يتجاوز استهلاكك 100 كيلوواط ساعة خلال الشهر، يتم إسقاط الدعم الممنوح للشريحتين الأولى والثانية، ويعاد احتساب كامل الـ 100 كيلو السابقة بسعر الشريحة الثالثة (95 قرشاً)، مما يؤدي لخصم فرق السعر مباشرة من رصيد الكارت (حوالي 22 إلى 28 جنيهاً بالإضافة لمقابل خدمة العملاء).", answer_en="When you exceed 100 kWh, tiers 1 & 2 subsidies are revoked and recalculated at tier 3 rate."),
                FAQ(category="recharge", question_ar="كام أشحن في العداد؟", question_en="How much should I recharge my meter?", keywords="كام اشحن, توصية الشحن, مبلغ الشحن, شحن كافي", answer_ar="يوفر لك تطبيق PowerWise أداة التوقع الذكي، حيث تحلل أجهزتك ومعدل استهلاكك التاريخي وتقترح عليك الشحن بمبلغ يضمن استمرار التيار بنسبة ثقة 80% للمدة التي تختارها (يوم، أسبوع، شهر).", answer_en="Use PowerWise recharge recommendation feature which calculates your optimal amount with 80% statistical confidence."),
                FAQ(category="devices", question_ar="ما هو أكثر جهاز يستهلك كهرباء في المنزل؟", question_en="Which home appliance consumes the most electricity?", keywords="اكتر جهاز, استهلاك عالي, التكييف, السخان, الغلاية", answer_ar="التكييفات وسخانات المياه وغلاية الشاي (الكاتيل) والمكواة هي أكثر الأجهزة استهلاكاً لأنها تحول الطاقة إلى حرارة أو تبريد بقدرات تتراوح بين 1000 و3000 وات.", answer_en="Air conditioners, water heaters, electric kettles, and irons consume the most electricity due to high thermal power."),
                FAQ(category="saving", question_ar="كيف أقلل فاتورة الكهرباء شهرياً؟", question_en="How can I reduce my monthly electricity bill?", keywords="توفير, ترشيد, تقليل الفاتورة, نصائح", answer_ar="1. اضبط التكييف على 24 أو 25 درجة.\n2. افصل شواحن الأجهزة من المقابس.\n3. استخدم لمبات LED موفرة.\n4. شغل السخان قبل الاستحمام بنصف ساعة فقط ثم افصله.", answer_en="Top tips: Set AC to 24C, unplug idle chargers, use LED bulbs, and turn water heater on only 30 min before use."),
                FAQ(category="app", question_ar="من قام بتطوير مشروع PowerWise Egypt؟", question_en="Who developed PowerWise Egypt project?", keywords="معهد طيبة, المطورين, الطلاب, مشروع التخرج", answer_ar="تم تطوير هذا المشروع كـ 'مشروع تخرج' متميز لطلبة قسم علوم الحاسب ونظم المعلومات بـ 'معهد طيبة العالي للتكنولوجيا والمعلومات' بإشراف أعضاء هيئة التدريس.", answer_en="Developed as a graduation project by students of Thebes Higher Institute for Technology and Information under faculty supervision.")
            ]
            db.session.bulk_save_objects(sample_faqs)
            db.session.commit()

        print("[+] تم فحص وتهيئة قاعدة البيانات بنجاح!")
    except Exception as e:
        db.session.rollback()
        print(f"[!] تنبيه أثناء تهيئة قاعدة البيانات: {e}")
