# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Prediction & Smart Recharge Routes
مسارات التنبؤ بالذكاء الاصطناعي، وتوصية الشحن "كام أشحن؟"، والرسوم البيانية
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

from flask import Blueprint, request, jsonify, session
from backend.services.prediction_service import (
    predict_daily_consumption,
    recommend_recharge,
    get_visual_charts_data
)
from backend.ml.model_trainer import (
    load_energy_models,
    train_and_save_energy_models
)

prediction_bp = Blueprint('predictions', __name__, url_prefix='/api/predictions')

def get_current_user_id() -> int:
    """استخلاص معرف المستخدم من الجلسة أو الترويسة"""
    if 'user_id' in session:
        return session['user_id']
    header_uid = request.headers.get('X-User-Id')
    if header_uid and header_uid.isdigit():
        return int(header_uid)
    return 2  # المعرف الافتراضي للطالب التجريبي


@prediction_bp.route('/forecast', methods=['GET'])
def handle_forecast():
    """
    استرجاع التوقعات اليومية للأيام القادمة مع نطاق الثقة
    معاملات الرابط: ?days=7 (الافتراضي 7 أيام)
    """
    user_id = get_current_user_id()
    days_arg = request.args.get('days', 7)
    try:
        days = int(days_arg)
    except (ValueError, TypeError):
        days = 7

    try:
        result = predict_daily_consumption(user_id, period_days=days)
        return jsonify({
            'success': True,
            'data': result
        }), 200
    except Exception as ex:
        return jsonify({'success': False, 'message': 'حدث خطأ أثناء حساب التوقعات.', 'error': str(ex)}), 500


@prediction_bp.route('/recommend-recharge', methods=['POST'])
def handle_recommend_recharge():
    """
    خاصية "كام أشحن؟":
    المدخل: JSON يحتوي على {"period_days": 7, "confidence": 0.80}
    المخرج: المبلغ المقترح بالجنيه، الحدين الأدنى والأقصى، والأيام المتبقية للرصيد
    """
    user_id = get_current_user_id()
    data = request.get_json() or {}
    period_days = int(data.get('period_days', 7))
    confidence = float(data.get('confidence', 0.80))

    try:
        result = recommend_recharge(user_id, period_days=period_days, confidence=confidence)
        return jsonify({
            'success': True,
            'data': result
        }), 200
    except Exception as ex:
        return jsonify({'success': False, 'message': 'حدث خطأ أثناء حساب توصية الشحن.', 'error': str(ex)}), 500


@prediction_bp.route('/charts', methods=['GET'])
def handle_charts_data():
    """استرجاع بيانات الرسوم البيانية التفاعلية (Line, Bar, Donut)"""
    user_id = get_current_user_id()
    try:
        charts_data = get_visual_charts_data(user_id)
        return jsonify({
            'success': True,
            'data': charts_data
        }), 200
    except Exception as ex:
        return jsonify({'success': False, 'message': 'تعذر استرجاع بيانات الرسوم البيانية.', 'error': str(ex)}), 500


@prediction_bp.route('/metrics', methods=['GET'])
def handle_model_metrics():
    """استرجاع مقاييس دقة النموذج الإحصائية (MAE, RMSE, R², 5-Fold Cross Validation)"""
    try:
        _, _, _, _, metrics = load_energy_models()
        return jsonify({
            'success': True,
            'data': metrics
        }), 200
    except Exception as ex:
        return jsonify({'success': False, 'message': 'تعذر استرجاع مقاييس النموذج.', 'error': str(ex)}), 500


@prediction_bp.route('/retrain', methods=['POST'])
def handle_retrain():
    """إعادة تدريب النموذج وتحديث الأوزان"""
    try:
        metrics = train_and_save_energy_models()
        return jsonify({
            'success': True,
            'message': 'تمت إعادة تدريب نموذج تعلم الآلة وحفظ الأوزان بنجاح.',
            'data': metrics
        }), 200
    except Exception as ex:
        return jsonify({'success': False, 'message': 'فشلت إعادة تدريب النموذج.', 'error': str(ex)}), 500
