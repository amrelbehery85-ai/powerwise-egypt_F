# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Authentication Routes
مسارات تسجيل الدخول والخروج وإنشاء الحساب
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

from flask import Blueprint, request, jsonify, session
from backend.services.auth_service import register_user, authenticate_user, get_user_profile

auth_bp = Blueprint('auth', __name__, url_prefix='/api/auth')

@auth_bp.route('/register', methods=['POST'])
def handle_register():
    """مسار إنشاء حساب جديد لمستخدم أو طالب"""
    data = request.get_json() or {}
    try:
        result = register_user(data)
        # تسجيل الدخول تلقائياً بعد إنشاء الحساب
        session['user_id'] = result['user']['id']
        session['role'] = result['user']['role']
        return jsonify({
            'success': True,
            'message': 'تم إنشاء الحساب وتفعيل العداد بنجاح!',
            'data': result
        }), 201
    except ValueError as e:
        return jsonify({'success': False, 'message': str(e)}), 400
    except Exception as ex:
        return jsonify({'success': False, 'message': 'حدث خطأ أثناء التسجيل.', 'error': str(ex)}), 500


@auth_bp.route('/login', methods=['POST'])
def handle_login():
    """مسار تسجيل الدخول"""
    data = request.get_json() or {}
    email = data.get('email', '')
    password = data.get('password', '')

    if not email or not password:
        return jsonify({'success': False, 'message': 'يرجى إدخال البريد الإلكتروني وكلمة المرور.'}), 400

    result = authenticate_user(email, password)
    if not result:
        return jsonify({'success': False, 'message': 'البريد الإلكتروني أو كلمة المرور غير صحيحة.'}), 401

    session['user_id'] = result['user']['id']
    session['role'] = result['user']['role']

    return jsonify({
        'success': True,
        'message': 'تم تسجيل الدخول بنجاح.',
        'data': result
    }), 200


@auth_bp.route('/me', methods=['GET'])
def handle_get_current_user():
    """استرجاع بيانات المستخدم الحالي المسجل بالـ Session"""
    user_id = session.get('user_id')
    if not user_id:
        # إذا لم يكن مسجل، نتحقق إن كان هناك رأس Authorization أو محاكاة للمستخدم التجريبي
        auth_header = request.headers.get('X-User-Id')
        if auth_header and auth_header.isdigit():
            user_id = int(auth_header)
        else:
            return jsonify({'success': False, 'message': 'غير مصرح - يرجى تسجيل الدخول أولاً.'}), 401

    profile = get_user_profile(user_id)
    if not profile:
        return jsonify({'success': False, 'message': 'لم يتم العثور على بيانات المستخدم.'}), 404

    return jsonify({
        'success': True,
        'data': profile
    }), 200


@auth_bp.route('/logout', methods=['POST'])
def handle_logout():
    """تسجيل الخروج ومسح الجلسة"""
    session.clear()
    return jsonify({
        'success': True,
        'message': 'تم تسجيل الخروج بنجاح.'
    }), 200
