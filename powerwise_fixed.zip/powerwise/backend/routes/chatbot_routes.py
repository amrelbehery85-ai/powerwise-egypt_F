# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Smart Chatbot Routes
مسارات المساعد الذكي، معالجة الأسئلة، واسترجاع سجل المحادثات
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

from flask import Blueprint, request, jsonify, session
from backend.services.chatbot_service import process_chatbot_message
from backend.models import ChatLog, FAQ

chat_bp = Blueprint('chat', __name__, url_prefix='/api/chat')

def get_current_user_id() -> int:
    if 'user_id' in session:
        return session['user_id']
    header_uid = request.headers.get('X-User-Id')
    if header_uid and header_uid.isdigit():
        return int(header_uid)
    return 2


@chat_bp.route('', methods=['POST'])
def handle_chat_message():
    """معالجة استفسار المستخدم والرد الذكي"""
    data = request.get_json() or {}
    message = str(data.get('message', '')).strip()
    user_id = get_current_user_id()

    if not message:
        return jsonify({'success': False, 'message': 'يرجى كتابة رسالة أو سؤال.'}), 400

    try:
        response = process_chatbot_message(message, user_id=user_id)
        return jsonify({
            'success': True,
            'data': response
        }), 200
    except Exception as ex:
        return jsonify({'success': False, 'message': 'حدث خطأ في المساعد الذكي.', 'error': str(ex)}), 500


@chat_bp.route('/history', methods=['GET'])
def get_chat_history():
    """استرجاع سجل المحادثة للمستخدم"""
    user_id = get_current_user_id()
    try:
        logs = ChatLog.query.filter_by(user_id=user_id).order_by(ChatLog.created_at.desc()).limit(20).all()
        return jsonify({
            'success': True,
            'count': len(logs),
            'data': [l.to_dict() for l in reversed(logs)]
        }), 200
    except Exception as ex:
        return jsonify({'success': False, 'message': 'تعذر استرجاع السجل.', 'error': str(ex)}), 500


@chat_bp.route('/faq-suggestions', methods=['GET'])
def get_popular_questions():
    """استرجاع عينة من الأسئلة الأكثر شيوعاً كأزرار سريعة"""
    return jsonify({
        'success': True,
        'suggestions': [
            "ما هي شرائح الكهرباء في مصر وكيف تُحسب؟",
            "كم رصيدي المتبقي في العداد؟",
            "ما هو أكثر جهاز يستهلك كهرباء في بيتي؟",
            "كام أشحن في العداد؟",
            "كيف أقلل استهلاك التكييف؟",
            "لماذا يخصم العداد مبالغ كبيرة عند الشريحة الثالثة؟"
        ]
    }), 200
