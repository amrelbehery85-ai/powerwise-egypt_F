# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Tariff Routes
مسارات حساب فاتورة الكهرباء وحساب التعرفة العكسية وتحديث الشرائح
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

from flask import Blueprint, request, jsonify, session
from backend.models import db, Tariff
from backend.services.tariff_service import (
    calculate_bill,
    calculate_inverse_tariff,
    get_active_tariffs_data
)

tariff_bp = Blueprint('tariffs', __name__, url_prefix='/api/tariffs')

@tariff_bp.route('', methods=['GET'])
def list_tariffs():
    """استرجاع كافة شرائح الكهرباء المصرية المسجلة مع تفاصيل الأسعار"""
    try:
        tariffs = Tariff.query.order_by(Tariff.tier_number.asc()).all()
        return jsonify({
            'success': True,
            'count': len(tariffs),
            'data': [t.to_dict() for t in tariffs],
            'notice': 'تحقق من التعرفة الرسمية الحالية (جهاز تنظيم مرفق الكهرباء - مصر).'
        }), 200
    except Exception as ex:
        # البديل الاحتياطي
        fallback = get_active_tariffs_data()
        return jsonify({
            'success': True,
            'count': len(fallback),
            'data': fallback,
            'notice': 'تحقق من التعرفة الرسمية الحالية (البيانات افتراضية تقديرية).'
        }), 200


@tariff_bp.route('/calculate', methods=['POST'])
def handle_calculate():
    """
    حساب تكلفة الاستهلاك التراكمي بالكيلوواط ساعة
    المدخل: JSON يحتوي على {"kwh": 150.5}
    المخرج: إجمالي التكلفة، تفصيل كل شريحة، متوسط السعر، والسعر الحدي
    """
    data = request.get_json() or {}
    kwh = data.get('kwh')

    if kwh is None:
        return jsonify({'success': False, 'message': 'يرجى تزويد كمية الاستهلاك بالكيلوواط ساعة (kwh).'}), 400

    try:
        kwh_float = float(kwh)
        if kwh_float < 0:
            return jsonify({'success': False, 'message': 'لا يمكن أن تكون قيمة الكيلوواط سالبة.'}), 400

        result = calculate_bill(kwh_float)
        return jsonify({
            'success': True,
            'data': result
        }), 200
    except ValueError as ve:
        return jsonify({'success': False, 'message': str(ve)}), 400
    except Exception as ex:
        return jsonify({'success': False, 'message': 'حدث خطأ أثناء حساب الفاتورة.', 'error': str(ex)}), 500


@tariff_bp.route('/inverse', methods=['POST'])
def handle_inverse_calculate():
    """
    التعرفة العكسية: بمعلومية مبلغ بالجنيه، كم كيلوواط ساعة أحصل عليها؟
    المدخل: JSON يحتوي على {"budget": 100.0}
    المخرج: الكيلوواط ساعة الدقيقة، الشريحة، ورسوم الخدمة المخصومة
    """
    data = request.get_json() or {}
    budget = data.get('budget')

    if budget is None:
        return jsonify({'success': False, 'message': 'يرجى تزويد المبلغ المالي بالجنيه (budget).'}), 400

    try:
        budget_float = float(budget)
        if budget_float < 0:
            return jsonify({'success': False, 'message': 'لا يمكن أن يكون المبلغ المالي سالباً.'}), 400

        result = calculate_inverse_tariff(budget_float)
        return jsonify({
            'success': True,
            'data': result
        }), 200
    except ValueError as ve:
        return jsonify({'success': False, 'message': str(ve)}), 400
    except Exception as ex:
        return jsonify({'success': False, 'message': 'حدث خطأ أثناء حساب التعرفة العكسية.', 'error': str(ex)}), 500


@tariff_bp.route('/admin/update/<int:tariff_id>', methods=['PUT'])
def admin_update_tariff(tariff_id: int):
    """
    تحديث سعر شريحة أو رسم خدمة عملاء من لوحة الإدارة (Admin Only)
    المدخلات: price_per_kwh, service_fee, source
    """
    # التحقق من صلاحية الإدارة
    role = session.get('role')
    user_header_role = request.headers.get('X-User-Role')
    if role != 'admin' and user_header_role != 'admin':
        return jsonify({'success': False, 'message': 'غير مصرح - هذه العملية تتطلب صلاحية مدير النظام (Admin).'}), 403

    tariff = db.session.get(Tariff, tariff_id)
    if not tariff:
        return jsonify({'success': False, 'message': 'لم يتم العثور على الشريحة المطلوبة.'}), 404

    data = request.get_json() or {}
    try:
        if 'price_per_kwh' in data:
            price = float(data['price_per_kwh'])
            if price <= 0:
                return jsonify({'success': False, 'message': 'سعر الكيلوواط يجب أن يكون أكبر من صفر.'}), 400
            tariff.price_per_kwh = price

        if 'service_fee' in data:
            fee = float(data['service_fee'])
            if fee < 0:
                return jsonify({'success': False, 'message': 'رسم الخدمة لا يمكن أن يكون سالباً.'}), 400
            tariff.service_fee = fee

        if 'source' in data and str(data['source']).strip():
            tariff.source = str(data['source']).strip()

        db.session.commit()
        return jsonify({
            'success': True,
            'message': f'تم تحديث بيانات {tariff.tier_name_ar} بنجاح.',
            'data': tariff.to_dict()
        }), 200

    except Exception as ex:
        db.session.rollback()
        return jsonify({'success': False, 'message': 'حدث خطأ أثناء تحديث الشريحة.', 'error': str(ex)}), 500
