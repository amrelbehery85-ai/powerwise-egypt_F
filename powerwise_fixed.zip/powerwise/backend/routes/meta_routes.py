# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Meta & Institutional Information Routes
مسارات معلومات المشروع والمعهد وهوية مشروع التخرج
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

from flask import Blueprint, jsonify
from backend.config import Config

meta_bp = Blueprint('meta', __name__, url_prefix='/api/meta')

@meta_bp.route('/info', methods=['GET'])
def get_meta_info():
    """استرجاع معلومات التوثيق الأكاديمي والمعهد والافتراضات"""
    return jsonify({
        'success': True,
        'data': {
            'institute_name_ar': Config.INSTITUTE_NAME_AR,
            'institute_name_en': Config.INSTITUTE_NAME_EN,
            'department_name_ar': Config.DEPARTMENT_NAME_AR,
            'department_name_en': Config.DEPARTMENT_NAME_EN,
            'project_name_ar': Config.PROJECT_NAME_AR,
            'project_name_en': Config.PROJECT_NAME_EN,
            'academic_year': Config.ACADEMIC_YEAR,
            'supervisor_name_ar': Config.SUPERVISOR_NAME_AR,
            'supervisor_name_en': Config.SUPERVISOR_NAME_EN,
            'student_names_ar': Config.STUDENT_NAMES_AR,
            'disclaimer_ar': Config.DATA_DISCLAIMER_AR,
            'disclaimer_en': Config.DATA_DISCLAIMER_EN,
            'tariff_notice': Config.TARIFF_OFFICIAL_NOTICE
        }
    }), 200
