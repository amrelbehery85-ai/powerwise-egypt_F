# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Device Routes
مسارات إدارة الأجهزة المنزلية، إضافة وتعديل وحذف، والتبديل اللحظي ON/OFF
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

from flask import Blueprint, request, jsonify, session
from backend.services.device_service import (
    get_all_device_types,
    get_user_devices,
    add_user_device,
    update_user_device,
    toggle_device_state,
    delete_user_device,
    calculate_live_power_summary
)

device_bp = Blueprint('devices', __name__, url_prefix='/api')

def get_current_user_id() -> int:
    """استخلاص معرف المستخدم من الجلسة أو ترويسة الطلب أو الافتراضي للطالب التجريبي"""
    if 'user_id' in session:
        return session['user_id']
    header_uid = request.headers.get('X-User-Id')
    if header_uid and header_uid.isdigit():
        return int(header_uid)
    return 2  # المعرف الافتراضي للطالب التجريبي للتجربة السلسة


@device_bp.route('/device-types', methods=['GET'])
def list_device_types():
    """استرجاع قائمة كافة أنواع الأجهزة القياسية الـ 20 مع حدود القدرة بالوات"""
    try:
        types = get_all_device_types()
        return jsonify({
            'success': True,
            'count': len(types),
            'data': types
        }), 200
    except Exception as ex:
        return jsonify({'success': False, 'message': 'تعذر استرجاع أنواع الأجهزة.', 'error': str(ex)}), 500


@device_bp.route('/devices', methods=['GET'])
def list_user_devices():
    """استرجاع الأجهزة المسجلة للمستخدم الحالي"""
    user_id = get_current_user_id()
    try:
        devices = get_user_devices(user_id)
        return jsonify({
            'success': True,
            'count': len(devices),
            'data': devices
        }), 200
    except Exception as ex:
        return jsonify({'success': False, 'message': 'تعذر استرجاع الأجهزة.', 'error': str(ex)}), 500


@device_bp.route('/devices', methods=['POST'])
def handle_add_device():
    """
    إضافة جهاز جديد بحساب المستخدم
    المدخلات: device_type_id, custom_name, rated_watts, count, daily_hours, is_active
    """
    user_id = get_current_user_id()
    data = request.get_json() or {}

    try:
        new_device = add_user_device(user_id, data)
        return jsonify({
            'success': True,
            'message': f'تمت إضافة جهاز "{new_device["custom_name"]}" بنجاح!',
            'data': new_device
        }), 201
    except ValueError as ve:
        return jsonify({'success': False, 'message': str(ve)}), 400
    except Exception as ex:
        return jsonify({'success': False, 'message': 'حدث خطأ أثناء إضافة الجهاز.', 'error': str(ex)}), 500


@device_bp.route('/devices/<int:device_id>', methods=['PUT'])
def handle_update_device(device_id: int):
    """تعديل بيانات جهاز مسجل"""
    user_id = get_current_user_id()
    data = request.get_json() or {}

    try:
        updated = update_user_device(user_id, device_id, data)
        return jsonify({
            'success': True,
            'message': 'تم تحديث بيانات الجهاز بنجاح.',
            'data': updated
        }), 200
    except ValueError as ve:
        return jsonify({'success': False, 'message': str(ve)}), 400
    except Exception as ex:
        return jsonify({'success': False, 'message': 'حدث خطأ أثناء تعديل الجهاز.', 'error': str(ex)}), 500


@device_bp.route('/devices/<int:device_id>/toggle', methods=['PATCH', 'POST'])
def handle_toggle_device(device_id: int):
    """تبديل حالة الجهاز (ON / OFF) لحظياً"""
    user_id = get_current_user_id()
    try:
        result = toggle_device_state(user_id, device_id)
        status_text = "تشغيل" if result["is_active"] else "إيقاف"
        return jsonify({
            'success': True,
            'message': f'تم {status_text} جهاز "{result["custom_name"]}" بنجاح.',
            'data': result
        }), 200
    except ValueError as ve:
        return jsonify({'success': False, 'message': str(ve)}), 400
    except Exception as ex:
        return jsonify({'success': False, 'message': 'حدث خطأ أثناء تبديل حالة الجهاز.', 'error': str(ex)}), 500


@device_bp.route('/devices/<int:device_id>', methods=['DELETE'])
def handle_delete_device(device_id: int):
    """حذف جهاز من حساب المستخدم"""
    user_id = get_current_user_id()
    try:
        delete_user_device(user_id, device_id)
        return jsonify({
            'success': True,
            'message': 'تم حذف الجهاز بنجاح.'
        }), 200
    except ValueError as ve:
        return jsonify({'success': False, 'message': str(ve)}), 400
    except Exception as ex:
        return jsonify({'success': False, 'message': 'حدث خطأ أثناء حذف الجهاز.', 'error': str(ex)}), 500


@device_bp.route('/devices/live-summary', methods=['GET'])
def handle_live_summary():
    """
    حساب استهلاك الأحمال اللحظية للأجهزة المشغلة (ON):
    - مجموع الوات
    - استهلاك الساعة واليوم والشهر بالكيلوواط ساعة
    - التكلفة بالجنيه المصري وفق الشرائح
    """
    user_id = get_current_user_id()
    try:
        summary = calculate_live_power_summary(user_id)
        return jsonify({
            'success': True,
            'data': summary
        }), 200
    except Exception as ex:
        return jsonify({'success': False, 'message': 'تعذر حساب ملخص الأحمال اللحظية.', 'error': str(ex)}), 500
