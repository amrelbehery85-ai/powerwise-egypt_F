# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Database Models (SQLAlchemy)
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

from datetime import datetime
from decimal import Decimal
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(db.Model):
    """جدول المستخدمين (المواطنين ومديري النظام)"""
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.Enum('user', 'admin', name='user_roles'), default='user', nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # العلاقات
    meters = db.relationship('Meter', backref='owner', cascade='all, delete-orphan', lazy=True)
    devices = db.relationship('Device', backref='owner', cascade='all, delete-orphan', lazy=True)
    usage_logs = db.relationship('UsageLog', backref='owner', cascade='all, delete-orphan', lazy=True)
    predictions = db.relationship('Prediction', backref='owner', cascade='all, delete-orphan', lazy=True)
    notifications = db.relationship('Notification', backref='recipient', cascade='all, delete-orphan', lazy=True)

    def set_password(self, password: str):
        """تشفير كلمة المرور بشكل آمن"""
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        """التحقق من صحة كلمة المرور"""
        return check_password_hash(self.password_hash, password)

    def to_dict(self):
        return {
            'id': self.id,
            'full_name': self.full_name,
            'email': self.email,
            'role': self.role,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class Meter(db.Model):
    """جدول عداد الكهرباء مسبق الدفع (كارت)"""
    __tablename__ = 'meters'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    meter_number = db.Column(db.String(50), unique=True, nullable=False, index=True)
    current_balance = db.Column(db.Numeric(10, 2), default=0.00, nullable=False)
    tariff_category = db.Column(db.String(50), default='residential', nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    recharges = db.relationship('Recharge', backref='meter', cascade='all, delete-orphan', lazy=True)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'meter_number': self.meter_number,
            'current_balance': float(self.current_balance),
            'tariff_category': self.tariff_category,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class DeviceType(db.Model):
    """جدول أنواع الأجهزة القياسية وحدود استهلاكها بالوات"""
    __tablename__ = 'device_types'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name_ar = db.Column(db.String(100), nullable=False)
    name_en = db.Column(db.String(100), nullable=False)
    min_watts = db.Column(db.Integer, nullable=False)
    max_watts = db.Column(db.Integer, nullable=False)
    typical_watts = db.Column(db.Integer, nullable=False)
    category = db.Column(db.String(50), default='general', nullable=False)
    icon_svg_name = db.Column(db.String(50), default='device-default', nullable=False)
    is_custom = db.Column(db.Boolean, default=False, nullable=False)

    devices = db.relationship('Device', backref='device_type', lazy=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name_ar': self.name_ar,
            'name_en': self.name_en,
            'min_watts': self.min_watts,
            'max_watts': self.max_watts,
            'typical_watts': self.typical_watts,
            'category': self.category,
            'icon_svg_name': self.icon_svg_name,
            'is_custom': bool(self.is_custom)
        }


class Device(db.Model):
    """الأجهزة الفعلية المضافة بحساب المستخدم مع حالة التشغيل"""
    __tablename__ = 'devices'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    device_type_id = db.Column(db.Integer, db.ForeignKey('device_types.id', ondelete='RESTRICT'), nullable=False)
    custom_name = db.Column(db.String(100), nullable=False)
    rated_watts = db.Column(db.Integer, nullable=False)
    count = db.Column(db.Integer, default=1, nullable=False)
    daily_hours = db.Column(db.Numeric(4, 2), default=1.00, nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        # حساب القدرة الإجمالية للجهاز (القدرة × العدد)
        total_watts = int(self.rated_watts) * int(self.count)
        # الاستهلاك اليومي بالكيلوواط ساعة = (القدرة الإجمالية × ساعات التشغيل) / 1000
        daily_kwh = (Decimal(str(total_watts)) * Decimal(str(self.daily_hours))) / Decimal('1000.0')

        return {
            'id': self.id,
            'user_id': self.user_id,
            'device_type_id': self.device_type_id,
            'custom_name': self.custom_name,
            'rated_watts': self.rated_watts,
            'count': self.count,
            'total_watts': total_watts,
            'daily_hours': float(self.daily_hours),
            'daily_kwh': round(float(daily_kwh), 4),
            'monthly_kwh': round(float(daily_kwh * 30), 4),
            'is_active': bool(self.is_active),
            'type_info': self.device_type.to_dict() if self.device_type else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class UsageLog(db.Model):
    """سجل الاستهلاك الفعلي والتاريخي"""
    __tablename__ = 'usage_logs'

    id = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    device_id = db.Column(db.Integer, db.ForeignKey('devices.id', ondelete='SET NULL'), nullable=True)
    timestamp = db.Column(db.DateTime, nullable=False, index=True)
    duration_hours = db.Column(db.Numeric(4, 2), default=1.00, nullable=False)
    energy_kwh = db.Column(db.Numeric(10, 4), nullable=False)
    calculated_cost = db.Column(db.Numeric(10, 4), default=0.0000, nullable=False)

    device = db.relationship('Device', backref='logs', lazy=True)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'device_id': self.device_id,
            'device_name': self.device.custom_name if self.device else 'إجمالي الاستهلاك المجمع',
            'timestamp': self.timestamp.isoformat(),
            'duration_hours': float(self.duration_hours),
            'energy_kwh': float(self.energy_kwh),
            'calculated_cost': float(self.calculated_cost)
        }


class Recharge(db.Model):
    """سجل عمليات شحن كارت العداد"""
    __tablename__ = 'recharges'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    meter_id = db.Column(db.Integer, db.ForeignKey('meters.id', ondelete='CASCADE'), nullable=False, index=True)
    amount_egp = db.Column(db.Numeric(10, 2), nullable=False)
    kwh_purchased = db.Column(db.Numeric(10, 2), nullable=False)
    balance_after = db.Column(db.Numeric(10, 2), default=0.00, nullable=False)
    recharge_date = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    notes = db.Column(db.String(255), nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'meter_id': self.meter_id,
            'amount_egp': float(self.amount_egp),
            'kwh_purchased': float(self.kwh_purchased),
            'balance_after': float(self.balance_after),
            'recharge_date': self.recharge_date.isoformat(),
            'notes': self.notes
        }


class Tariff(db.Model):
    """جدول شرائح التعرفة المصرية الرسمية"""
    __tablename__ = 'tariffs'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tier_number = db.Column(db.Integer, nullable=False)
    tier_name_ar = db.Column(db.String(100), nullable=False)
    tier_name_en = db.Column(db.String(100), nullable=False)
    min_kwh = db.Column(db.Numeric(10, 2), nullable=False)
    max_kwh = db.Column(db.Numeric(10, 2), nullable=False)
    price_per_kwh = db.Column(db.Numeric(10, 4), nullable=False)
    service_fee = db.Column(db.Numeric(10, 2), default=0.00, nullable=False)
    bracket_group = db.Column(db.Integer, default=1, nullable=False)
    effective_date = db.Column(db.Date, nullable=False)
    source = db.Column(db.String(255), nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'tier_number': self.tier_number,
            'tier_name_ar': self.tier_name_ar,
            'tier_name_en': self.tier_name_en,
            'min_kwh': float(self.min_kwh),
            'max_kwh': float(self.max_kwh),
            'price_per_kwh': float(self.price_per_kwh),
            'service_fee': float(self.service_fee),
            'bracket_group': self.bracket_group,
            'effective_date': self.effective_date.isoformat() if self.effective_date else None,
            'source': self.source,
            'is_active': bool(self.is_active)
        }


class Prediction(db.Model):
    """توقعات الذكاء الاصطناعي مع نطاقات الثقة"""
    __tablename__ = 'predictions'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    prediction_date = db.Column(db.Date, nullable=False)
    target_period_days = db.Column(db.Integer, nullable=False)
    predicted_kwh = db.Column(db.Numeric(10, 3), nullable=False)
    lower_bound_kwh = db.Column(db.Numeric(10, 3), nullable=False)
    upper_bound_kwh = db.Column(db.Numeric(10, 3), nullable=False)
    predicted_cost_egp = db.Column(db.Numeric(10, 2), nullable=False)
    model_version = db.Column(db.String(50), default='v1.0-rf', nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'prediction_date': self.prediction_date.isoformat(),
            'target_period_days': self.target_period_days,
            'predicted_kwh': float(self.predicted_kwh),
            'lower_bound_kwh': float(self.lower_bound_kwh),
            'upper_bound_kwh': float(self.upper_bound_kwh),
            'predicted_cost_egp': float(self.predicted_cost_egp),
            'model_version': self.model_version,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class Notification(db.Model):
    """تنبيهات النظام"""
    __tablename__ = 'notifications'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    title_ar = db.Column(db.String(150), nullable=False)
    title_en = db.Column(db.String(150), nullable=False)
    message_ar = db.Column(db.Text, nullable=False)
    message_en = db.Column(db.Text, nullable=False)
    type = db.Column(db.Enum('warning', 'danger', 'info', 'success', name='notif_types'), default='info', nullable=False)
    is_read = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'title_ar': self.title_ar,
            'title_en': self.title_en,
            'message_ar': self.message_ar,
            'message_en': self.message_en,
            'type': self.type,
            'is_read': bool(self.is_read),
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class FAQ(db.Model):
    """قاعدة المعرفة والأسئلة الشائعة للشات بوت"""
    __tablename__ = 'faq'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    category = db.Column(db.String(50), nullable=False)
    question_ar = db.Column(db.String(255), nullable=False)
    question_en = db.Column(db.String(255), nullable=False)
    keywords = db.Column(db.Text, nullable=False)
    answer_ar = db.Column(db.Text, nullable=False)
    answer_en = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'category': self.category,
            'question_ar': self.question_ar,
            'question_en': self.question_en,
            'keywords': self.keywords,
            'answer_ar': self.answer_ar,
            'answer_en': self.answer_en
        }


class ChatLog(db.Model):
    """سجلات استفسارات ومحادثات المساعد الذكي"""
    __tablename__ = 'chat_logs'

    id = db.Column(db.BigInteger, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='SET NULL'), nullable=True)
    user_message = db.Column(db.Text, nullable=False)
    bot_response = db.Column(db.Text, nullable=False)
    matched_faq_id = db.Column(db.Integer, db.ForeignKey('faq.id', ondelete='SET NULL'), nullable=True)
    confidence_score = db.Column(db.Numeric(5, 4), default=0.0000, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship('User', backref='chat_history', lazy=True)
    faq_item = db.relationship('FAQ', backref='logged_matches', lazy=True)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'user_message': self.user_message,
            'bot_response': self.bot_response,
            'matched_faq_id': self.matched_faq_id,
            'confidence_score': float(self.confidence_score),
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
