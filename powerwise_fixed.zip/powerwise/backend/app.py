# -*- coding: utf-8 -*-
"""
==============================================================================
PowerWise Egypt - Flask REST API Application Entrypoint
مراقب ذكي لاستهلاك الكهرباء للعدادات مسبقة الدفع في مصر
مشروع تخرج - معهد طيبة العالي للتكنولوجيا والمعلومات
==============================================================================
"""

import sys
import os
from pathlib import Path

# ضمان إضافة مسار المجلد الرئيسي للمشروع إلى مسارات بايثون (sys.path)
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from flask import Flask, jsonify, send_from_directory, request
from flask_cors import CORS

from backend.config import config_by_name
from backend.models import db
from backend.routes.auth_routes import auth_bp
from backend.routes.tariff_routes import tariff_bp
from backend.routes.device_routes import device_bp
from backend.routes.meta_routes import meta_bp
from backend.routes.prediction_routes import prediction_bp
from backend.routes.chatbot_routes import chat_bp

def create_app(config_name: str = None) -> Flask:
    """مصنع تطبيق Flask (Application Factory Pattern)"""
    if config_name is None:
        config_name = os.getenv("FLASK_ENV", "development")

    config_class = config_by_name.get(config_name, config_by_name["development"])

    # تحديد مسار مجلد الواجهة الأمامية frontend
    base_dir = Path(__file__).resolve().parent.parent
    frontend_dir = base_dir / "frontend"

    app = Flask(
        __name__,
        static_folder=str(frontend_dir),
        static_url_path=""
    )
    app.config.from_object(config_class)

    # تفعيل CORS للتطوير السلس
    CORS(app, supports_credentials=True)

    # تهيئة اتصال قاعدة البيانات
    db.init_app(app)

    # التحقق من وجود الجداول وتغذيتها بالبيانات التلقائية إذا لم تكن في وضع الاختبار
    if not app.config.get("TESTING"):
        with app.app_context():
            from backend.services.seed_data import seed_database_if_empty
            seed_database_if_empty()

    # تسجيل مسارات الـ Blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(tariff_bp)
    app.register_blueprint(device_bp)
    app.register_blueprint(meta_bp)
    app.register_blueprint(prediction_bp)
    app.register_blueprint(chat_bp)

    # -------------------------------------------------------------
    # مسارات خدمة الواجهة الأمامية (Frontend Serving)
    # -------------------------------------------------------------
    @app.route('/')
    def serve_index():
        """تقديم الصفحة الرئيسية لتطبيق الويب"""
        return send_from_directory(str(frontend_dir), 'index.html')

    @app.route('/<path:path>')
    def serve_static_files(path):
        """تقديم ملفات CSS و JS و Assets بشكل تلقائي"""
        target_path = frontend_dir / path
        if target_path.exists() and target_path.is_file():
            return send_from_directory(str(frontend_dir), path)
        return send_from_directory(str(frontend_dir), 'index.html')

    # -------------------------------------------------------------
    # معالجات الأخطاء الموحدة (Error Handlers)
    # -------------------------------------------------------------
    @app.errorhandler(404)
    def not_found_handler(e):
        if request.path.startswith('/api/'):
            return jsonify({'success': False, 'message': 'المسار المطلوب غير موجود في الـ API.'}), 404
        return send_from_directory(str(frontend_dir), 'index.html')

    @app.errorhandler(500)
    def internal_error_handler(e):
        return jsonify({'success': False, 'message': 'حدث خطأ داخلي في الخادم.', 'error': str(e)}), 500

    @app.errorhandler(400)
    def bad_request_handler(e):
        return jsonify({'success': False, 'message': 'طلب غير صالح.', 'error': str(e)}), 400

    return app


if __name__ == '__main__':
    app = create_app()
    port = int(os.getenv("PORT", 5000))
    print("=" * 65)
    print(" ⚡ PowerWise Egypt - السيرفر يعمل الآن")
    print(" معهد طيبة العالي للتكنولوجيا والمعلومات — مشروع تخرج")
    print(f" الرابط المحلي: http://localhost:{port}")
    print("=" * 65)
    app.run(host='0.0.0.0', port=port, debug=True)
