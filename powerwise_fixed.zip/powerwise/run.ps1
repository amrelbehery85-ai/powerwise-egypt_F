# PowerWise Egypt - PowerShell Launcher
$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Write-Host "==============================================================================" -ForegroundColor Cyan
Write-Host "  ⚡ PowerWise Egypt - مراقب ذكي لاستهلاك الكهرباء للعدادات مسبقة الدفع" -ForegroundColor Yellow
Write-Host "  معهد طيبة العالي للتكنولوجيا والمعلومات — مشروع تخرج 2024 / 2025" -ForegroundColor White
Write-Host "==============================================================================" -ForegroundColor Cyan
Write-Host ""

$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectDir

# 1. فحص Python
try {
    $pythonVersion = & python --version 2>&1
    Write-Host "[+] تم العثور على: $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "[X] خطأ: Python غير مثبت أو غير مضاف لـ PATH." -ForegroundColor Red
    pause
    exit 1
}

# 2. فحص وإنشاء البيئة الافتراضية
if (-not (Test-Path ".\venv\Scripts\Activate.ps1")) {
    Write-Host "[*] إنشاء البيئة الافتراضية venv..." -ForegroundColor Yellow
    & python -m venv venv
}

if (Test-Path ".\venv\Scripts\Activate.ps1") {
    & .\venv\Scripts\Activate.ps1
}

# 3. تثبيت المتطلبات
Write-Host "[*] التحقق من تثبيت المكتبات..." -ForegroundColor Yellow
& pip install -r requirements.txt --quiet

# 4. فتح المتصفح تلقائياً
Start-Job -ScriptBlock {
    Start-Sleep -Seconds 2
    Start-Process "http://localhost:5000"
} | Out-Null

# 5. تشغيل السيرفر
Write-Host ""
Write-Host "==============================================================================" -ForegroundColor Green
Write-Host "  ⚡ السيرفر يعمل الآن! يتم فتح المتصفح على: http://localhost:5000" -ForegroundColor White
Write-Host "  • حساب الطالب: student@powerwise.eg  | كلمة السر: Student@123456" -ForegroundColor Cyan
Write-Host "  • حساب الإدارة: admin@powerwise.eg    | كلمة السر: Admin@123456" -ForegroundColor Cyan
Write-Host "==============================================================================" -ForegroundColor Green
Write-Host "[!] لإيقاف السيرفر اضغط Ctrl + C" -ForegroundColor Yellow
Write-Host ""

& python backend\app.py
