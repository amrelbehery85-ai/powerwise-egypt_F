@echo off
chcp 65001 >nul
title PowerWise Egypt - Smart Electricity Monitor
color 0B

echo ==============================================================================
echo   ⚡ PowerWise Egypt - مراقب ذكي لاستهلاك الكهرباء للعدادات مسبقة الدفع
echo   معهد طيبة العالي للتكنولوجيا والمعلومات — مشروع تخرج 2024 / 2025
echo ==============================================================================
echo.

:: 1. التحقق من توفر بايثون
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [X] خطأ: لم يتم العثور على Python مثبت على جهازك!
    echo يرجى تحميل وتثبيت بايثون من: https://www.python.org/downloads/
    echo وتأكد من تفعيل خيار "Add python.exe to PATH" أثناء التثبيت.
    echo.
    pause
    exit /b 1
)

:: 2. التحقق من البيئة الافتراضية venv
if not exist "venv\Scripts\activate.bat" (
    echo [*] إنشاء البيئة الافتراضية (venv)...
    python -m venv venv
    if %errorlevel% neq 0 (
        echo [!] تعذر إنشاء venv، سيتم المتابعة باستخدام بايثون النظام مباشرة.
    )
)

:: تفعيل البيئة الافتراضية إن وجدت
if exist "venv\Scripts\activate.bat" (
    call venv\Scripts\activate.bat
)

:: 3. التحقق من تثبيت المكتبات
echo [*] فحص وتثبيت المكتبات المطلوبة...
pip install -r requirements.txt --quiet

:: 4. فتح المتصفح تلقائياً بعد ثانيتين
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://localhost:5000"

:: 5. تشغيل خادم Flask
echo.
echo ==============================================================================
echo   ⚡ السيرفر يعمل الآن بنجاح!
echo   افتح المتصفح على: http://localhost:5000
echo.
echo   بيانات الدخول التجريبية:
echo   • حساب الطالب: student@powerwise.eg  ^| كلمة السر: Student@123456
echo   • حساب الإدارة: admin@powerwise.eg    ^| كلمة السر: Admin@123456
echo ==============================================================================
echo [!] لإيقاف السيرفر اضغط Ctrl + C
echo.

python backend\app.py

pause
